#ifndef ONLINE_TEST_FORM_H
#define ONLINE_TEST_FORM_H

#include <QWidget>
#include <QUdpSocket>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QMediaPlayer>
#include <QAudioOutput>

class OnlineTestForm : public QWidget
{
    Q_OBJECT

public:
    OnlineTestForm(QWidget *parent = nullptr);

private slots:
    void sendPlay();
    void sendPause();
    void sendStop();
    void sendSync();
    void receiveMessage();
    void playSong();

private:
    QLineEdit* ipInput;
    QTextEdit* chatBox;
    QPushButton* playButton;
    QPushButton* pauseButton;
    QPushButton* stopButton;
    QPushButton* syncButton;
    QUdpSocket* udpSocket;
    QMediaPlayer* player;
    QAudioOutput* audioOutput;
    QString songPath();

    void sendMessage(const QString& msg);
};

#endif // ONLINE_TEST_FORM_H
