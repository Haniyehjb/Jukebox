// DashboardWindow.h - Modified Section
#ifndef DASHBOARDWINDOW_H
#define DASHBOARDWINDOW_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include "user.h" // برای انتقال User و QVector<User>

class DashboardWindow : public QWidget
{
    Q_OBJECT

public:
    explicit DashboardWindow(User* loggedUser, QVector<User>* allUsers, QWidget *parent = nullptr);
    ~DashboardWindow();

private slots:
    void openMediaPlayer(); // برای "Offline Music Player"
    void openOnlineMusicPlayer(); // ADD THIS LINE: اسلات جدید برای "Online Music Player"
    void openVideoPlayer();       // برای "Video Player"

private:
    User* m_loggedUser;
    QVector<User>* m_allUsers;

    QLabel *welcomeLabel;
    QPushButton *mediaPlayerButton;
    QPushButton *onlineMusicPlayerButton;
    QPushButton *videoPlayerButton;

    QVBoxLayout *mainLayout;
};

#endif // DASHBOARDWINDOW_H
