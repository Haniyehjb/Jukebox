#ifndef SONGSENDER_H
#define SONGSENDER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QFile>
#include <QObject>

class SongSender : public QObject
{
    Q_OBJECT

public:
    SongSender(QObject* parent = nullptr);
    void startSending(const QString& filePath);

private slots:
    void handleConnection();
    void sendData();

private:
    QTcpServer* tcpServer;
    QTcpSocket* clientSocket;
    QFile file;
};

#endif // SONGSENDER_H
