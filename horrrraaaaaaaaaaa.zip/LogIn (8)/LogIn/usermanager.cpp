#include "UserManager.h"
#include <QStringList>
#include <QDebug>
#include <QMessageBox>

UserManager* UserManager::instance = nullptr;

void UserManager::loadFromFile(const QString& path) {
    try{
    users.clear();

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.trimmed().isEmpty()) continue;

        QStringList parts = line.split(' ');
        if (parts.size() < 6) continue;

        User user(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);

        if (parts.size() > 6) {
            int playlistCount = parts[6].toInt();
            int index = 7;

            for (int i = 0; i < playlistCount; ++i) {
                QString playlistName = parts[index++];
                int songCount = parts[index++].toInt();
                Playlist pl(playlistName);

                for (int j = 0; j < songCount; ++j) {
                    QString songData = parts[index++];
                    QStringList songParts = songData.split('|');
                    if (songParts.size() == 2) {
                        Song s(songParts[0], songParts[1]);
                        pl.addSong(s);
                    }
                }

                user.addPlaylist(pl);
            }
        }

        users.append(user);
    }

    file.close();
    }catch (const std::exception& e) {
        qCritical() << "Error loading file:" << e.what();
        QMessageBox::critical(nullptr, "File Load Error", e.what());
    } catch (...) {
        qCritical() << "Unknown error loading file.";
        QMessageBox::critical(nullptr, "File Load Error", "An unknown error occurred while loading user data.");
    }
}


void UserManager::saveToFile(const QString& path) {
    try{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);

    for (const User& user : users) {
        out << user.username << " "
            << user.hashedPassword << " "
            << user.fullName << " "
            << user.email << " "
            << user.question << " "
            << user.answer << " "
            << user.playlists.size() << " ";

        for (const Playlist& pl : user.playlists) {
            out << pl.name << " " << pl.songs.size() << " ";
            for (const Song& song : pl.songs)
                out << song.title << "|" << song.artist << " ";
        }


        out << "\n";
    }

    file.close();
    }catch (const std::exception& e) {
        qCritical() << "Error saving file:" << e.what();
        QMessageBox::critical(nullptr, "File Save Error", e.what());
    } catch (...) {
        qCritical() << "Unknown error saving file.";
        QMessageBox::critical(nullptr, "File Save Error", "An unknown error occurred while saving user data.");
    }
}

bool UserManager::userExists(const QString& username) {
    for (const User& user : users) {
        if (user.username == username)
            return true;
    }
    return false;
}
