#include "mediaplayerwindow.h"

MediaPlayerWindow::MediaPlayerWindow() {}
