#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QString>
#include <QVector>

#include "Song.h"

class Playlist {
public:
    QString name;
    QVector<Song> songs;

    Playlist(QString n = "") : name(n) {}

    void addSong(const Song& song) {
        songs.append(song);
    }
};

#endif // PLAYLIST_H
