#include "mediaplayer.h"
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QUrl>
#include <QGraphicsLinearLayout>
#include <QRandomGenerator>
#include <QStandardPaths>
#include <QDateTime>
#include <algorithm> // For std::random_shuffle

MediaPlayer::MediaPlayer(QWidget *parent)
    : QWidget(parent),
    mediaPlayer(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentIndex(-1),
    isShuffled(false),
    repeatMode(0), // 0: No Repeat
    currentVisualizer(DEFAULT),
    randomGenerator(QDateTime::currentMSecsSinceEpoch())
{

    mediaPlayer->setAudioOutput(audioOutput);
    audioOutput->setVolume(50);

    // Equalizer setup
    equalizerScene = new QGraphicsScene(this);
    equalizerView = new QGraphicsView(equalizerScene, this);
    equalizerView->setFixedHeight(200);

    // Create rainbow bars (original left-aligned but will center in update)
    for (int i = 0; i < 16; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 0, 10, 2);
        bar->setPos(i * 15, 0); // Position in the scene
        bar->setBrush(QColor::fromHsv(i * 15, 255, 200));
        rainbowBars.append(bar);
        equalizerScene->addItem(bar);
    }

    // Create RANDOM bars (150 blue bars)
    for (int i = 0; i < 150; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 0, 3, 2);
        bar->setPos(i * 5, 0);
        bar->setBrush(QColor(100, 150, 255));
        bar->setVisible(false);
        randomBars.append(bar);
        equalizerScene->addItem(bar);
    }

    // 8 waves
    for (int i = 0; i < 6; i++) {
        QGraphicsLineItem* wave = new QGraphicsLineItem();
        wave->setPen(QPen(QColor::fromHsv(270 + i*5, 200, 220), 3.0f)); // Purple shades
        wave->setZValue(i);
        wave->setVisible(false);
        waveLines.append(wave);
        equalizerScene->addItem(wave);
    }

    // Animation timer - set to faster interval (20ms)
    equalizerTimer = new QTimer(this);
    connect(equalizerTimer, &QTimer::timeout, this, &MediaPlayer::updateEqualizer);
    equalizerTimer->start(20); // Always running timer

    openButton = new QPushButton("Open File(s)", this);
    playButton = new QPushButton("Play", this);
    pauseButton = new QPushButton("Pause", this);
    stopButton = new QPushButton("Stop", this);

    nextButton = new QPushButton("Next", this);
    previousButton = new QPushButton("Previous", this);
    shuffleButton = new QPushButton("Shuffle (Off)", this);
    repeatButton = new QPushButton("Repeat (Off)", this);
    clearPlaylistButton = new QPushButton("Clear Playlist", this);

    positionSlider = new QSlider(Qt::Horizontal, this);
    positionSlider->setRange(0, 0);
    volumeSlider = new QSlider(Qt::Horizontal, this);
    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(50);
    timeLabel = new QLabel("00:00 / 00:00", this);

    playlistWidget = new QListWidget(this);

    // Add visualizer button
    visualizerButton = new QPushButton("Visualizer (Default)", this);


    connect(openButton, &QPushButton::clicked, this, &MediaPlayer::addFilesToPlaylist);
    connect(playButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::play);
    connect(pauseButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::pause);
    connect(stopButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::stop);

    connect(nextButton, &QPushButton::clicked, this, &MediaPlayer::playNextSong);
    connect(previousButton, &QPushButton::clicked, this, &MediaPlayer::playPreviousSong);
    connect(shuffleButton, &QPushButton::clicked, this, &MediaPlayer::toggleShuffle);
    connect(repeatButton, &QPushButton::clicked, this, &MediaPlayer::toggleRepeat);
    connect(clearPlaylistButton, &QPushButton::clicked, this, &MediaPlayer::clearPlaylist);

    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::updatePosition);
    connect(mediaPlayer, &QMediaPlayer::durationChanged, this, &MediaPlayer::updateDuration);
    connect(positionSlider, &QSlider::sliderMoved, mediaPlayer, &QMediaPlayer::setPosition);
    connect(volumeSlider, &QSlider::valueChanged, this, &MediaPlayer::setVolume);

    connect(mediaPlayer, &QMediaPlayer::playbackStateChanged, this, &MediaPlayer::updateButtonsState);
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, &MediaPlayer::handleMediaStatusChanged);

    connect(playlistWidget, &QListWidget::itemDoubleClicked, this, &MediaPlayer::playSelectedSong);
    connect(visualizerButton, &QPushButton::clicked, this, &MediaPlayer::toggleVisualizer);


    mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(equalizerView);

    QHBoxLayout *controlButtonsLayout = new QHBoxLayout();
    controlButtonsLayout->addWidget(openButton);
    controlButtonsLayout->addWidget(previousButton);
    controlButtonsLayout->addWidget(playButton);
    controlButtonsLayout->addWidget(pauseButton);
    controlButtonsLayout->addWidget(stopButton);
    controlButtonsLayout->addWidget(nextButton);

    QHBoxLayout *modeButtonsLayout = new QHBoxLayout();
    modeButtonsLayout->addWidget(shuffleButton);
    modeButtonsLayout->addWidget(repeatButton);
    modeButtonsLayout->addWidget(clearPlaylistButton);

    mainLayout->addLayout(controlButtonsLayout);
    mainLayout->addLayout(modeButtonsLayout);
    mainLayout->addWidget(positionSlider);
    mainLayout->addWidget(timeLabel);

    QHBoxLayout *volumeLayout = new QHBoxLayout();
    volumeLayout->addWidget(new QLabel("Volume:", this));
    volumeLayout->addWidget(volumeSlider);
    mainLayout->addLayout(volumeLayout);

    mainLayout->addWidget(visualizerButton); // Add visualizer button to layout
    mainLayout->addWidget(playlistWidget);


    setLayout(mainLayout);

    updateButtonsState(QMediaPlayer::StoppedState);

    equalizerView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    equalizerView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}

MediaPlayer::~MediaPlayer()
{
    equalizerTimer->stop();
    qDeleteAll(rainbowBars); // Changed from equalizerBars to rainbowBars
    qDeleteAll(randomBars); // Also delete random bars
    delete mediaPlayer;
    delete audioOutput;
    qDeleteAll(waveLines);
}

void MediaPlayer::updateEqualizer()
{
    qint64 time = QDateTime::currentMSecsSinceEpoch();
    float intensity = 1.0f;

    // Adjust intensity based on playback state
    if (mediaPlayer->playbackState() == QMediaPlayer::StoppedState) {
        intensity = 0.1f;
    }
    else if (mediaPlayer->playbackState() == QMediaPlayer::PausedState) {
        intensity = 0.3f;
    }

    if (currentVisualizer == DEFAULT){
        for (auto wave : waveLines) wave->setVisible(false);
        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
    }
    else if (currentVisualizer == RAINBOW) {
        // Show rainbow bars
        for (int i = 0; i < 16; i++) {
            // Smooth animation with intensity control
            float height = 2 + intensity * qAbs(60 * sin(time/80.0 + i*0.3) * cos(time/120.0 + i*0.2));
            rainbowBars[i]->setRect(0, 100-height, 10, height); // Bars grow downward
            rainbowBars[i]->setVisible(true);
        }
        // Hide other visualizers
        for (auto wave : waveLines) wave->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
    }
    else if (currentVisualizer == RANDOM) {
        // Show random bars
        for (int i = 0; i < randomBars.size(); i++) {
            // Get random factor between 0.5 and 1.5
            float randomFactor = 0.5 + randomGenerator.generateDouble();
            float modifiedTime = time / 1.5;
            float height = 2 + intensity * 60 * fabs(
                                   sin(modifiedTime/(120.0 * (0.5 + randomFactor))) +
                                   cos(modifiedTime/(150.0 * (0.5 + i/75.0)))
                                   );

            randomBars[i]->setRect(0, 100-height, 3, height);
            randomBars[i]->setVisible(true);

            // Slight color variation
            int blueValue = 200 + 55 * sin(time/1000.0 + i/25.0);
            randomBars[i]->setBrush(QColor(100, 150, qBound(150, blueValue, 255)));
        }
        // Hide other visualizers
        for (auto wave : waveLines) wave->setVisible(false);
        for (auto bar : rainbowBars) bar->setVisible(false);
    }
    else if (currentVisualizer == WAVE) {
        // Hide other visualizers
        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);

        const int POINTS_PER_WAVE = 50; // Smooth curves
        float timeSec = QTime::currentTime().msecsSinceStartOfDay() / 1000.0f;
        float centerY = equalizerView->height() * 0.5f;

        // Create wave points if they don't exist
        if (wavePaths.isEmpty()) {
            for (int i = 0; i < 3; i++) { // 3 independent waves
                QPainterPath path;
                wavePaths.append(path);
            }
        }

        // Update each wave
        for (int waveIdx = 0; waveIdx < 3; waveIdx++) {
            QPainterPath path;
            float amplitude = 30.0f - waveIdx * 5.0f;
            float wavelength = 0.05f + waveIdx * 0.02f;
            float speed = 0.5f + waveIdx * 0.2f;

            path.moveTo(0, centerY);

            // Generate wave points
            for (int x = 0; x <= equalizerView->width(); x += equalizerView->width()/POINTS_PER_WAVE) {
                float phase = timeSec * speed - x * wavelength;
                float y = centerY + amplitude * sin(phase);

                // Add interference from other waves
                if (waveIdx > 0) {
                    y += 0.6f * amplitude * sin(timeSec * (speed-0.1f) - x * (wavelength+0.01f));
                }

                path.lineTo(x, y);
            }

            // Draw the wave
            if (waveItems.size() <= waveIdx) {
                QGraphicsPathItem* item = new QGraphicsPathItem();
                item->setPen(QPen(QColor::fromHsv(270 + waveIdx*30, 200, 220), 3));
                waveItems.append(item);
                equalizerScene->addItem(item);
            }

            waveItems[waveIdx]->setPath(path);
            waveItems[waveIdx]->setVisible(true);
        }
    }
}

void MediaPlayer::toggleVisualizer()
{
    currentVisualizer = static_cast<VisualizerMode>((currentVisualizer + 1) % 4);

    switch (currentVisualizer) {
    case DEFAULT:
        visualizerButton->setText("Visualizer (Default)");
        break;
    case RAINBOW:
        visualizerButton->setText("Visualizer (Rainbow)");
        break;
    case RANDOM:
        visualizerButton->setText("Visualizer (Random)");
        break;
    case WAVE:
        visualizerButton->setText("Visualizer (Wave)");
        break;
    }

    updateEqualizer();
}

void MediaPlayer::openFile() // This function is not connected to any button in the current setup.
{
    QString filePath = QFileDialog::getOpenFileName(this, "Open Media File",
                                                    QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                    "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");
    if (!filePath.isEmpty()) {
        playlist.clear();
        playlist.append(QUrl::fromLocalFile(filePath));
        currentIndex = 0;
        playlistWidget->clear();
        playlistWidget->addItem(QFileInfo(filePath).fileName());
        playCurrentSong();
    }
}

void MediaPlayer::setVolume(int volume)
{
    audioOutput->setVolume(volume / 100.0);
}

void MediaPlayer::updatePosition(qint64 position)
{
    positionSlider->setValue(static_cast<int>(position));
    updateTimeLabel(position, mediaPlayer->duration());
}

void MediaPlayer::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, static_cast<int>(duration));
    updateTimeLabel(mediaPlayer->position(), duration);
}

void MediaPlayer::updateTimeLabel(qint64 currentPos, qint64 totalDuration)
{
    qint64 currentSeconds = currentPos / 1000;
    qint64 totalSeconds = totalDuration / 1000;

    int currentMinutes = static_cast<int>(currentSeconds / 60);
    int currentSecs = static_cast<int>(currentSeconds % 60);
    int totalMinutes = static_cast<int>(totalSeconds / 60);
    int totalSecs = static_cast<int>(totalSeconds % 60);

    timeLabel->setText(QString("%1:%2 / %3:%4")
                           .arg(currentMinutes, 2, 10, QChar('0'))
                           .arg(currentSecs, 2, 10, QChar('0'))
                           .arg(totalMinutes, 2, 10, QChar('0'))
                           .arg(totalSecs, 2, 10, QChar('0')));
}

void MediaPlayer::updateButtonsState(QMediaPlayer::PlaybackState state)
{
    playButton->setEnabled(state != QMediaPlayer::PlayingState);
    pauseButton->setEnabled(state == QMediaPlayer::PlayingState);
    stopButton->setEnabled(state != QMediaPlayer::StoppedState);

    bool enablePlaylistControls = !playlist.isEmpty();
    nextButton->setEnabled(enablePlaylistControls);
    previousButton->setEnabled(enablePlaylistControls);
    shuffleButton->setEnabled(enablePlaylistControls);
    repeatButton->setEnabled(enablePlaylistControls);
    clearPlaylistButton->setEnabled(enablePlaylistControls);
}

void MediaPlayer::handleMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        qDebug() << "End of media reached. Playing next song.";
        playNextSong();
    } else if (status == QMediaPlayer::InvalidMedia) {
        qDebug() << "Invalid media source.";
        QMessageBox::warning(this, "Error", "Could not play media. Invalid format or corrupted file.");
        playNextSong();
    }
}

void MediaPlayer::playCurrentSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        qDebug() << "Playlist is empty. Cannot play song.";
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex < 0 || currentIndex >= playlist.size()) {
        qDebug() << "Current index out of bounds. Resetting to 0.";
        currentIndex = 0;
    }

    QUrl currentSource;
    if (isShuffled && !shuffledIndices.isEmpty()) {

        if (currentIndex < 0 || currentIndex >= shuffledIndices.size()) {
            qDebug() << "Shuffled index out of bounds. Resetting.";
            currentIndex = 0;
        }
        currentSource = playlist[shuffledIndices[currentIndex]];
    } else {

        currentSource = playlist[currentIndex];
    }

    mediaPlayer->setSource(currentSource);
    mediaPlayer->play();
    qDebug() << "Playing: " << currentSource.toLocalFile();
    updatePlaylistWidgetSelection();
}

void MediaPlayer::playNextSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    int nextIndex = currentIndex;

    if (repeatMode == 2) {

        qDebug() << "Repeat One: Replaying current song.";
    } else {
        nextIndex++;
        if (isShuffled) {
            if (nextIndex >= shuffledIndices.size()) {
                if (repeatMode == 1) {
                    nextIndex = 0;
                    qDebug() << "Repeat All (Shuffled): Wrapping around to first shuffled song.";
                } else {
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    qDebug() << "No Repeat (Shuffled): End of playlist reached.";
                    return;
                }
            }
        } else {
            if (nextIndex >= playlist.size()) {
                if (repeatMode == 1) {
                    nextIndex = 0;
                    qDebug() << "Repeat All: Wrapping around to first song.";
                } else {
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    qDebug() << "No Repeat: End of playlist reached.";
                    return;
                }
            }
        }
    }
    currentIndex = nextIndex;
    playCurrentSong();
}

void MediaPlayer::playPreviousSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex <= 0) {

        if (repeatMode == 1) { // Repeat All
            currentIndex = (isShuffled ? shuffledIndices.size() : playlist.size()) - 1;
            qDebug() << "Repeat All: Wrapping around to last song.";
        } else {
            currentIndex = 0;
            qDebug() << "Previous: Already at the first song.";
        }
    } else {
        currentIndex--;
    }
    playCurrentSong();
}

void MediaPlayer::toggleShuffle()
{
    isShuffled = !isShuffled;
    if (isShuffled) {
        shuffleButton->setText("Shuffle (On)");
        shuffledIndices.clear();
        for (int i = 0; i < playlist.size(); ++i) {
            shuffledIndices.append(i);
        }

        std::random_shuffle(shuffledIndices.begin(), shuffledIndices.end());
        qDebug() << "Shuffle On. Shuffled order: " << shuffledIndices;
    } else {
        shuffleButton->setText("Shuffle (Off)");
        shuffledIndices.clear();
        qDebug() << "Shuffle Off.";
    }
}

void MediaPlayer::toggleRepeat()
{
    repeatMode = (repeatMode + 1) % 3; // 0 -> 1 -> 2 -> 0
    switch (repeatMode) {
    case 0:
        repeatButton->setText("Repeat (Off)");
        qDebug() << "Repeat Off.";
        break;
    case 1:
        repeatButton->setText("Repeat (All)");
        qDebug() << "Repeat All.";
        break;
    case 2:
        repeatButton->setText("Repeat (One)");
        qDebug() << "Repeat One.";
        break;
    }
}

void MediaPlayer::addFilesToPlaylist()
{
    QStringList filePaths = QFileDialog::getOpenFileNames(this, "Add Media Files",
                                                          QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                          "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");

    if (!filePaths.isEmpty()) {
        for (const QString &filePath : filePaths) {
            QUrl url = QUrl::fromLocalFile(filePath);
            playlist.append(url);
            playlistWidget->addItem(QFileInfo(filePath).fileName());
        }

        if (currentIndex == -1 && !playlist.isEmpty()) {
            currentIndex = 0;
            playCurrentSong();
        }

        // Re-shuffle if shuffle is on and new songs are added
        if (isShuffled) {
            toggleShuffle(); // Turn off shuffle
            toggleShuffle(); // Turn on shuffle to re-shuffle with new songs
        }
        updateButtonsState(mediaPlayer->playbackState());
    }
}

void MediaPlayer::playSelectedSong(QListWidgetItem *item)
{
    if (!item) return;

    // Find the index of the selected item in the *original* playlist
    int originalPlaylistIndex = -1;
    QString fileNameToFind = item->text();

    for (int i = 0; i < playlist.size(); ++i) {
        if (QFileInfo(playlist[i].toLocalFile()).fileName() == fileNameToFind) {
            originalPlaylistIndex = i;
            break;
        }
    }

    if (originalPlaylistIndex != -1) {
        if (isShuffled) {
            // If shuffled, we need to find where this 'originalPlaylistIndex' is in our shuffled order
            // and set currentIndex to that position in shuffledIndices.
            for (int i = 0; i < shuffledIndices.size(); ++i) {
                if (shuffledIndices[i] == originalPlaylistIndex) {
                    currentIndex = i;
                    break;
                }
            }
        } else {
            currentIndex = originalPlaylistIndex;
        }
        playCurrentSong();
    }
}

void MediaPlayer::clearPlaylist()
{
    mediaPlayer->stop();
    playlist.clear();
    shuffledIndices.clear();
    currentIndex = -1;
    playlistWidget->clear();
    qDebug() << "Playlist cleared.";
    updateButtonsState(QMediaPlayer::StoppedState);
    updateTimeLabel(0,0);
}

void MediaPlayer::updatePlaylistWidgetSelection()
{
    playlistWidget->clearSelection();

    if (currentIndex != -1 && !playlist.isEmpty()) {
        int actualSongIndex = currentIndex;
        if (isShuffled && !shuffledIndices.isEmpty() && currentIndex < shuffledIndices.size()) {
            actualSongIndex = shuffledIndices[currentIndex];
        }

        if (actualSongIndex >= 0 && actualSongIndex < playlistWidget->count()) {
            QListWidgetItem *item = playlistWidget->item(actualSongIndex);
            if (item) {
                item->setSelected(true);
                playlistWidget->scrollToItem(item);
            }
        }
    }
}
