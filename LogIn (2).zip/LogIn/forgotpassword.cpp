#include "forgotpassword.h"
#include <QFile>
#include <QTextStream>
#include <QCryptographicHash>
#include <QMessageBox>
#include <QTimer>
#include "mainwindow.h"
#include "utils.h"

ForgotPassword::ForgotPassword(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(600, 450);

    backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 450);
    backgroundLabel->setPixmap(QPixmap(":/images/logo.jpg"));
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("Username"); // نام کاربری
    usernameEdit->setGeometry(100, 20, 200, 30);

    questionCombo = new QComboBox(this);
    questionCombo->setGeometry(100, 60, 200, 30);
    questionCombo->addItems({
        "Your best friend's name",
        "Your first pet's name",
        "Your favorite movie",
        "Your dream job"
    }); // سوال امنیتی انتخابی

    securityAnswerEdit = new QLineEdit(this);
    securityAnswerEdit->setPlaceholderText("Answer to security question"); // پاسخ سوال امنیتی
    securityAnswerEdit->setGeometry(100, 100, 200, 30);

    verifyButton = new QPushButton("Verify", this);
    verifyButton->setGeometry(320, 100, 80, 30);

    newPasswordEdit = new QLineEdit(this);
    newPasswordEdit->setPlaceholderText("New Password"); // رمز جدید
    newPasswordEdit->setEchoMode(QLineEdit::Password);
    newPasswordEdit->setGeometry(100, 140, 200, 30);
    newPasswordEdit->setEnabled(false);

    resetButton = new QPushButton("Reset Password", this); // دکمه تغییر رمز
    resetButton->setGeometry(150, 190, 150, 40);
    resetButton->setEnabled(false);

    messageLabel = new QLabel(this);
    messageLabel->setGeometry(50, 240, 400, 30);
    messageLabel->setStyleSheet("color: red;");

    connect(verifyButton, &QPushButton::clicked, this, &ForgotPassword::verifyUser);
    connect(resetButton, &QPushButton::clicked, this, &ForgotPassword::resetPassword);
}

void ForgotPassword::verifyUser()
{
    QString username = usernameEdit->text().trimmed();
    QString selectedQuestion = questionCombo->currentText();
    QString inputAnswer = securityAnswerEdit->text().trimmed();

    if (username.isEmpty() || selectedQuestion.isEmpty() || inputAnswer.isEmpty()) {
        messageLabel->setText("Please fill all fields"); // هشدار پر کردن همه‌ی فیلدها
        return;
    }

    QFile file("users.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        messageLabel->setText("Error opening user file");
        return;
    }

    QTextStream in(&file);
    bool foundUser = false;
    QString savedEncryptedQuestion;
    QString savedEncryptedAnswer;

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(" ");
        if (parts.size() >= 6) {
            QString savedUsername = parts[0];
            if (savedUsername == username) {
                foundUser = true;
                savedEncryptedQuestion = parts[4];
                savedEncryptedAnswer = parts[5];
                break;
            }
        }
    }

    file.close();

    if (!foundUser) {
        messageLabel->setText("Username not found");
        return;
    }

    QString decryptedQuestion = decrypt(savedEncryptedQuestion);
    QString encryptedAnswer = encrypt(inputAnswer);

    if (decryptedQuestion == selectedQuestion && encryptedAnswer == savedEncryptedAnswer) {
        messageLabel->setStyleSheet("color: green;");
        messageLabel->setText("Verified. Please enter your new password."); // تایید موفق
        newPasswordEdit->setEnabled(true);
        resetButton->setEnabled(true);
        userVerified = true;
    } else {
        messageLabel->setStyleSheet("color: red;");
        messageLabel->setText("Security question or answer is incorrect!"); // خطا در سوال یا جواب
        userVerified = false;
    }
}

void ForgotPassword::resetPassword()
{
    if (!userVerified) {
        messageLabel->setText("Please verify your identity first");
        return;
    }

    QString username = usernameEdit->text().trimmed();
    QString newPassword = newPasswordEdit->text().trimmed();
    if (newPassword.isEmpty()) {
        messageLabel->setText("Please enter new password");
        return;
    }

    QByteArray hashedNewPassword = QCryptographicHash::hash(newPassword.toUtf8(), QCryptographicHash::Sha256);
    QString hashedNewPasswordHex = hashedNewPassword.toHex();

    QFile file("users.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        messageLabel->setText("Error opening user file");
        return;
    }

    QStringList lines;
    QTextStream in(&file);
    while (!in.atEnd()) {
        lines.append(in.readLine());
    }
    file.close();

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        messageLabel->setText("Error writing to user file");
        return;
    }

    QTextStream out(&file);
    bool updated = false;

    for (QString &line : lines) {
        QStringList parts = line.split(" ");
        if (parts.size() >= 6) {
            QString savedUsername = parts[0];
            if (savedUsername == username) {
                parts[1] = hashedNewPasswordHex;
                line = parts.join(" ");
                updated = true;
            }
        }
        out << line << "\n";
    }

    file.close();

    if (updated) {
        messageLabel->setStyleSheet("color: green;");
        messageLabel->setText("Password reset successful!");

        QTimer::singleShot(2000, [this]() {
            MainWindow *mainWin = new MainWindow();
            mainWin->show();
            this->close();
        });

    } else {
        messageLabel->setStyleSheet("color: red;");
        messageLabel->setText("Error updating password!");
    }
}
