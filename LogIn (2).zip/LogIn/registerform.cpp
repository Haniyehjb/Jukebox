#include "registerform.h"
#include "mainwindow.h"
#include <QCryptographicHash>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QPixmap>
#include <QDir>
#include <QTimer>
#include "utils.h"

RegisterForm::RegisterForm(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(600, 450);

    backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 450);
    backgroundLabel->setPixmap(QPixmap(":/images/logo.jpg"));
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("Username");
    usernameEdit->setGeometry(100, 20, 200, 30);

    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("Password");
    passwordEdit->setEchoMode(QLineEdit::Password);
    passwordEdit->setGeometry(100, 60, 200, 30);

    firstNameEdit = new QLineEdit(this);
    firstNameEdit->setPlaceholderText("First Name");
    firstNameEdit->setGeometry(100, 100, 200, 30);

    lastNameEdit = new QLineEdit(this);
    lastNameEdit->setPlaceholderText("Last Name");
    lastNameEdit->setGeometry(100, 140, 200, 30);

    emailEdit = new QLineEdit(this);
    emailEdit->setPlaceholderText("Email");
    emailEdit->setGeometry(100, 180, 200, 30);

    securityQuestionCombo = new QComboBox(this);
    securityQuestionCombo->setGeometry(100, 220, 200, 30);
    securityQuestionCombo->addItems({
        "Your best friend's name",
        "Your first pet's name",
        "Your favorite movie",
        "Your dream job"
    });

    securityAnswerEdit = new QLineEdit(this);
    securityAnswerEdit->setPlaceholderText("Answer");
    securityAnswerEdit->setGeometry(100, 260, 200, 30);

    registerButton = new QPushButton("Register", this);
    registerButton->setGeometry(150, 310, 100, 40);

    messageLabel = new QLabel(this);
    messageLabel->setGeometry(50, 360, 400, 30);
    messageLabel->setStyleSheet("color: red;");

    connect(registerButton, &QPushButton::clicked, this, &RegisterForm::registerUser);
}

void RegisterForm::registerUser()
{
    QString username = usernameEdit->text().trimmed();
    QString password = passwordEdit->text().trimmed();
    QString firstName = firstNameEdit->text().trimmed();
    QString lastName = lastNameEdit->text().trimmed();
    QString email = emailEdit->text().trimmed();
    QString question = securityQuestionCombo->currentText();
    QString answer = securityAnswerEdit->text().trimmed();

    if (username.isEmpty() || password.isEmpty() || firstName.isEmpty()
        || lastName.isEmpty() || email.isEmpty() || answer.isEmpty()) {
        messageLabel->setText("Please fill in all fields.");
        messageLabel->setStyleSheet("color: red;");
        return;
    }

    QByteArray hashedPassword = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedPasswordHex = hashedPassword.toHex();

    QString encryptedFullName = encrypt(firstName + " " + lastName);
    QString encryptedEmail = encrypt(email);
    QString encryptedQuestion = encrypt(question);
    QString encryptedAnswer = encrypt(answer);

    // QDir dir("data");
    // if (!dir.exists()) dir.mkpath(".");

    QFile file("users.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        messageLabel->setText("Error opening file!");
        messageLabel->setStyleSheet("color: red;");
        return;
    }

    QTextStream out(&file);
    out << username << " "
        << hashedPasswordHex << " "
        << encryptedFullName << " "
        << encryptedEmail << " "
        << encryptedQuestion << " "
        << encryptedAnswer << "\n";

    file.close();

    messageLabel->setText("Registration successful!");
    messageLabel->setStyleSheet("color: green;");

    usernameEdit->clear();
    passwordEdit->clear();
    firstNameEdit->clear();
    lastNameEdit->clear();
    emailEdit->clear();
    securityAnswerEdit->clear();
    securityQuestionCombo->setCurrentIndex(0);

    // MainWindow *mainWin = new MainWindow();
    // mainWin->show();
    // this->close();

    QTimer::singleShot(2000, [this]() {
        MainWindow *mainWin = new MainWindow();
        mainWin->show();
        this->close();
    });

}
