#include "login.h"
#include "mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QCryptographicHash>
#include <QDir>
#include <QTimer>

Login::Login(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(400, 250);
    setWindowTitle("Login");

    auto *layout = new QVBoxLayout(this);

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("Username");

    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("Password");
    passwordEdit->setEchoMode(QLineEdit::Password);

    loginButton = new QPushButton("Login", this);
    messageLabel = new QLabel(this);
    messageLabel->setStyleSheet("color: red;");

    layout->addWidget(usernameEdit);
    layout->addWidget(passwordEdit);
    layout->addWidget(loginButton);
    layout->addWidget(messageLabel);

    connect(loginButton, &QPushButton::clicked, this, &Login::loginUser);

    forgotPasswordBtn = new QPushButton("Forgot Password?", this);
    forgotPasswordBtn->setGeometry(250, 140, 120, 30);
    connect(forgotPasswordBtn, &QPushButton::clicked, this, &Login::showForgotPassword);
}

void Login::loginUser()
{
    QString username = usernameEdit->text().trimmed();
    QString password = passwordEdit->text().trimmed();

    if (username.isEmpty() || password.isEmpty()) {
        messageLabel->setText("Please enter both fields.");
        messageLabel->setStyleSheet("color: red;");
        return;
    }

    // QDir dir("data");
    // if (!dir.exists()) {
    //     messageLabel->setText("No users registered yet.");
    //     messageLabel->setStyleSheet("color: red;");
    //     return;
    // }

    QFile file("users.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        messageLabel->setText("Accounts file not found.");
        messageLabel->setStyleSheet("color: red;");
        return;
    }

    QTextStream in(&file);
    QByteArray enteredHash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex();

    bool success = false;
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(" ");
        if (parts.size() < 6) continue; // حداقل 6 قسمت (username, hashedPass, fullname, email, question, answer)

        if (parts[0] == username && parts[1] == enteredHash) {
            success = true;
            break;
        }
    }

    // file.close();

    if (success) {
        messageLabel->setStyleSheet("color: green;");
        messageLabel->setText("Login successful!");
        // اینجا می‌تونی پنجره اصلی رو باز کنی یا کاربر رو وارد برنامه کنی
        // MainWindow *mainWin = new MainWindow();
        // mainWin->show();
        // this->close();
        QTimer::singleShot(2000, [this]() {
            MainWindow *mainWin = new MainWindow();
            mainWin->show();
            this->close();
        });
    } else {
        messageLabel->setStyleSheet("color: red;");
        messageLabel->setText("Invalid username or password.");
    }
}

void Login::showForgotPassword()
{
    if (!forgotPasswordWindow) {
        forgotPasswordWindow = new ForgotPassword();
    }
    forgotPasswordWindow->show();
    forgotPasswordWindow->raise();
    forgotPasswordWindow->activateWindow();
}
