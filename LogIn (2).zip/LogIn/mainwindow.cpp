#include "mainwindow.h"
#include "login.h"
#include "registerform.h"
#include "forgotpassword.h"

#include <QPixmap>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(600, 400);

    backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 400);
    backgroundLabel->setPixmap(QPixmap(":/images/logo.jpg"));
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();

    loginButton = new QPushButton("Login", this);
    loginButton->setGeometry(100, 120, 180, 50);

    registerButton = new QPushButton("Register", this);
    registerButton->setGeometry(100, 190, 180, 50);

    forgotPasswordButton = new QPushButton("Forgot Password", this);
    forgotPasswordButton->setGeometry(100, 260, 180, 50);

    connect(loginButton, &QPushButton::clicked, this, &MainWindow::openLogIn);
    connect(registerButton, &QPushButton::clicked, this, &MainWindow::openRegister);
    connect(forgotPasswordButton, &QPushButton::clicked, this, &MainWindow::openForgotPassword);
}

void MainWindow::openLogIn()
{
    Login *loginWindow = new Login();
    loginWindow->show();
    this->close();
}

void MainWindow::openRegister()
{
    RegisterForm *registerForm = new RegisterForm();
    registerForm->show();
    this->close();
}

void MainWindow::openForgotPassword()
{
    ForgotPassword *forgotForm = new ForgotPassword();
    forgotForm->show();
    this->close();
}
