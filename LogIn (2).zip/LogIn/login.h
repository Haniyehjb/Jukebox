#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include "forgotpassword.h"

class QLineEdit;
class QPushButton;
class QLabel;

class Login : public QWidget
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);

private slots:
    void loginUser();
    void showForgotPassword();

private:
    QLineEdit *usernameEdit;
    QLineEdit *passwordEdit;
    QLabel    *messageLabel;
    QPushButton *loginButton;
    QPushButton *forgotPasswordBtn;
    ForgotPassword *forgotPasswordWindow = nullptr;
};

#endif // LOGIN_H
