#include "onlinetestform.h"
#include "songsender.h"
#include "songreciever.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHostAddress>
#include <QDir>
#include <QFile>
#include <QDebug>
#include <QMediaPlayer>
#include <QAudioOutput>

OnlineTestForm::OnlineTestForm(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(500, 400);

    ipInput = new QLineEdit(this);
    ipInput->setPlaceholderText("Enter friend's IP address");

    playButton = new QPushButton("▶ Play", this);
    pauseButton = new QPushButton("⏸ Pause", this);
    stopButton = new QPushButton("⏹ Stop", this);
    syncButton = new QPushButton("⏱ Sync", this);

    chatBox = new QTextEdit(this);
    chatBox->setReadOnly(true);

    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addWidget(playButton);
    buttonLayout->addWidget(pauseButton);
    buttonLayout->addWidget(stopButton);
    buttonLayout->addWidget(syncButton);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->addWidget(ipInput);
    layout->addLayout(buttonLayout);
    layout->addWidget(chatBox);
    setLayout(layout);

    udpSocket = new QUdpSocket(this);
    udpSocket->bind(QHostAddress::AnyIPv4, 45454, QUdpSocket::ShareAddress);

    connect(playButton, &QPushButton::clicked, this, &OnlineTestForm::sendPlay);
    connect(pauseButton, &QPushButton::clicked, this, &OnlineTestForm::sendPause);
    connect(stopButton, &QPushButton::clicked, this, &OnlineTestForm::sendStop);
    connect(syncButton, &QPushButton::clicked, this, &OnlineTestForm::sendSync);

    connect(udpSocket, &QUdpSocket::readyRead, this, &OnlineTestForm::receiveMessage);

    player = new QMediaPlayer(this);
    audioOutput = new QAudioOutput(this);
    audioOutput->setVolume(0.7);
    player->setAudioOutput(audioOutput);

    connect(player, &QMediaPlayer::errorOccurred, this, [](QMediaPlayer::Error error, const QString &errorString){
        qDebug() << "MediaPlayer Error:" << error << errorString;
    });
}

void OnlineTestForm::sendMessage(const QString& msg)
{
    QString ip = ipInput->text();
    udpSocket->writeDatagram(msg.toUtf8(), QHostAddress(ip), 45454);
    chatBox->append("[YOU]: " + msg);
}

void OnlineTestForm::sendPlay() {
    sendMessage("PLAY");

    // بررسی اینکه آهنگ داریم یا نه
    QString path = songPath();
    if (!QFile::exists(path)) {
        chatBox->append("[INFO] You don’t have the song.");
        return;
    }

    playSong();
}

void OnlineTestForm::sendPause() {
    sendMessage("PAUSE");
    player->pause();
}

void OnlineTestForm::sendStop() {
    sendMessage("STOP");
    player->stop();
}

void OnlineTestForm::sendSync() {
    qint64 syncPos = 45000;
    sendMessage("SYNC:" + QString::number(syncPos));
    player->setPosition(syncPos);
}

void OnlineTestForm::receiveMessage()
{
    while (udpSocket->hasPendingDatagrams()) {
        QByteArray buffer;
        buffer.resize(udpSocket->pendingDatagramSize());
        QHostAddress sender;
        quint16 senderPort;

        udpSocket->readDatagram(buffer.data(), buffer.size(), &sender, &senderPort);
        QString received = QString::fromUtf8(buffer);

        if (received == "PLAY") {
            QString path = songPath();
            if (!QFile::exists(path)) {
                sendMessage("I_DONT_HAVE:Coldplay_Yellow.mp3");

                // آماده دریافت فایل از طرف مقابل
                auto receiver = new SongReceiver(this);
                receiver->startReceiving(path, sender.toString());
                chatBox->append("[INFO] Waiting to receive song...");
                return;
            }

            chatBox->append("[ACTION] Playing...");
            playSong();

        } else if (received == "PAUSE") {
            chatBox->append("[ACTION] Paused");
            player->pause();

        } else if (received == "STOP") {
            chatBox->append("[ACTION] Stopped");
            player->stop();

        } else if (received.startsWith("SYNC:")) {
            qint64 pos = received.section(':', 1).toLongLong();
            chatBox->append("[SYNC] Jumped to: " + QString::number(pos / 1000.0) + " sec");
            player->setPosition(pos);

        } else if (received.startsWith("I_DONT_HAVE:")) {
            QString songName = received.section(':', 1);
            QString fullPath = QDir::currentPath() + "/songs/" + songName;

            auto sender = new SongSender(this);
            sender->startSending(fullPath);
            chatBox->append("[INFO] Sending song to friend...");

        } else {
            chatBox->append("[FRIEND]: " + received);
        }
    }
}

QString OnlineTestForm::songPath()
{
    return "C:/Users/User/Documents/online2/songs/Coldplay_Yellow.mp3";
}

void OnlineTestForm::playSong()
{
    QString path = songPath();
    if (!QFile::exists(path)) {
        chatBox->append("[ERROR] Song file not found: " + path);
        return;
    }

    player->setSource(QUrl::fromLocalFile(path));
    player->play();
}
