#include "songsender.h"
#include <QDebug>
#include <QFileInfo>

SongSender::SongSender(QObject* parent)
    : QObject(parent), tcpServer(new QTcpServer(this)), clientSocket(nullptr)
{
    connect(tcpServer, &QTcpServer::newConnection, this, &SongSender::handleConnection);
}

void SongSender::startSending(const QString& filePath)
{
    QFileInfo checkFile(filePath);
    if (!checkFile.exists() || !checkFile.isFile()) {
        qDebug() << "[Sender] File does not exist:" << filePath;
        return;
    }

    file.setFileName(filePath);
    qDebug() << "[Sender] File size to send:" << checkFile.size();  // ✅ لاگ برای بررسی

    if (!tcpServer->listen(QHostAddress::AnyIPv4, 45454)) {
        qDebug() << "[Sender] Unable to start TCP server!";
        return;
    }

    qDebug() << "[Sender] Waiting for receiver to connect on port 45454...";
}

void SongSender::handleConnection()
{
    clientSocket = tcpServer->nextPendingConnection();

    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "[Sender] Could not open file after connection!";
        return;
    }

    connect(clientSocket, &QTcpSocket::bytesWritten, this, &SongSender::sendData);
    sendData();
}

void SongSender::sendData()
{
    if (!file.atEnd()) {
        QByteArray chunk = file.read(4096);
        qDebug() << "[Sender] Sending chunk of size:" << chunk.size();  // ✅ لاگ
        clientSocket->write(chunk);
    } else {
        qDebug() << "[Sender] File sent successfully!";
        clientSocket->disconnectFromHost();
        file.close();
        tcpServer->close();
    }
}
