#include "songreciever.h"
#include <QDebug>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QFileInfo>
#include <QDir>

SongReceiver::SongReceiver(QObject* parent)
    : QObject(parent), socket(new QTcpSocket(this))
{
    connect(socket, &QTcpSocket::readyRead, this, &SongReceiver::readData);
    connect(socket, &QTcpSocket::disconnected, this, &SongReceiver::finalizeReceiving);  // ✅ اتصال برای بستن فایل بعد از دریافت
}

void SongReceiver::startReceiving(const QString& savePath, const QString& senderIP)
{
    // ایجاد مسیر فایل خروجی اگر وجود ندارد
    QDir().mkpath(QFileInfo(savePath).absolutePath());

    file.setFileName(savePath);
    if (!file.open(QIODevice::WriteOnly)) {
        qDebug() << "[Receiver] Could not create file!";
        return;
    }

    socket->connectToHost(senderIP, 45454);
    qDebug() << "[Receiver] Connecting to sender at" << senderIP << ":45454...";
}

void SongReceiver::readData()
{
    QByteArray chunk = socket->readAll();
    qDebug() << "[Receiver] Received chunk of size:" << chunk.size();  // ✅ بررسی سایز داده
    file.write(chunk);
}

void SongReceiver::finalizeReceiving()
{
    file.close();
    qDebug() << "[Receiver] File received and saved!";

    QString finalPath = file.fileName();
    QFileInfo checkFile(finalPath);
    if (!checkFile.exists() || checkFile.size() == 0) {
        qDebug() << "[Receiver] Error: received file not found or empty!";
        return;
    }

    // پخش موسیقی پس از دریافت کامل
    QMediaPlayer* player = new QMediaPlayer(this);
    QAudioOutput* audioOutput = new QAudioOutput(this);
    audioOutput->setVolume(0.7);
    player->setAudioOutput(audioOutput);
    player->setSource(QUrl::fromLocalFile(finalPath));
    player->play();
}
