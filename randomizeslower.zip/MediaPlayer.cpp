#include "mediaplayer.h"
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QUrl>
#include <QGraphicsLinearLayout>
#include <QRandomGenerator>
#include <QStandardPaths>
#include <QDateTime>
#include <algorithm> // For std::random_shuffle

MediaPlayer::MediaPlayer(QWidget *parent)
    : QWidget(parent),
    mediaPlayer(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentIndex(-1),
    isShuffled(false),
    repeatMode(0), // 0: No Repeat
    currentVisualizer(DEFAULT),
    randomGenerator(QDateTime::currentMSecsSinceEpoch())
{

    mediaPlayer->setAudioOutput(audioOutput);
    audioOutput->setVolume(50);

    // Equalizer setup
    equalizerScene = new QGraphicsScene(this);
    equalizerView = new QGraphicsView(equalizerScene, this);
    equalizerView->setFixedHeight(200);

    // Create rainbow bars (original left-aligned but will center in update)
    for (int i = 0; i < 16; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 0, 10, 2);
        bar->setPos(i * 15, 0); // Position in the scene
        bar->setBrush(QColor::fromHsv(i * 15, 255, 200));
        rainbowBars.append(bar);
        equalizerScene->addItem(bar);
    }

    // Create RANDOM bars (150 blue bars)
    for (int i = 0; i < 150; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 0, 3, 2);
        bar->setPos(i * 5, 0);
        bar->setBrush(QColor(100, 150, 255));
        bar->setVisible(false);
        randomBars.append(bar);
        equalizerScene->addItem(bar);
    }

    // Initialize 3 waves
    for (int i = 0; i < 3; i++) {
        QGraphicsPathItem* wave = new QGraphicsPathItem();
        wave->setPen(QPen(QColor::fromHsv(270 + i*30, 200, 220, 200), 3.0f));
        wave->setVisible(false);
        waveItems.append(wave);
        equalizerScene->addItem(wave);
        waveTimers.append(i * 1000.0f); // Offset start times
    }

    // Animation timer - set to faster interval (20ms)
    equalizerTimer = new QTimer(this);
    connect(equalizerTimer, &QTimer::timeout, this, &MediaPlayer::updateEqualizer);
    equalizerTimer->start(20); // Always running timer

    openButton = new QPushButton("Open File(s)", this);
    playButton = new QPushButton("Play", this);
    pauseButton = new QPushButton("Pause", this);
    stopButton = new QPushButton("Stop", this);

    nextButton = new QPushButton("Next", this);
    previousButton = new QPushButton("Previous", this);
    shuffleButton = new QPushButton("Shuffle (Off)", this);
    repeatButton = new QPushButton("Repeat (Off)", this);
    clearPlaylistButton = new QPushButton("Clear Playlist", this);

    positionSlider = new QSlider(Qt::Horizontal, this);
    positionSlider->setRange(0, 0);
    volumeSlider = new QSlider(Qt::Horizontal, this);
    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(50);
    timeLabel = new QLabel("00:00 / 00:00", this);

    playlistWidget = new QListWidget(this);

    // Add visualizer button
    visualizerButton = new QPushButton("Visualizer (Default)", this);

    // Big Gray Play Triangle
    QPolygonF triangle;
    triangle << QPointF(0, 0) << QPointF(0, 100) << QPointF(87, 50);
    playSymbolItem = new QGraphicsPolygonItem(triangle);
    playSymbolItem->setBrush(QColor(150, 150, 150, 220));  // Medium gray
    playSymbolItem->setPen(QPen(QColor(100, 100, 100, 220), 2.5f));  // Dark border
    playSymbolItem->setVisible(false);
    playSymbolItem->setPos(
        equalizerView->width()/2 - 43,  // Perfectly centered
        equalizerView->height()/2 - 50
        );
    playSymbolItem->setZValue(1);
    equalizerScene->addItem(playSymbolItem);

    // Cover Art Item
    coverArtItem = new QGraphicsPixmapItem();
    coverArtItem->setVisible(false);
    coverArtItem->setZValue(2);  // Above triangle
    equalizerScene->addItem(coverArtItem);


    connect(openButton, &QPushButton::clicked, this, &MediaPlayer::addFilesToPlaylist);
    connect(playButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::play);
    connect(pauseButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::pause);
    connect(stopButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::stop);

    connect(nextButton, &QPushButton::clicked, this, &MediaPlayer::playNextSong);
    connect(previousButton, &QPushButton::clicked, this, &MediaPlayer::playPreviousSong);
    connect(shuffleButton, &QPushButton::clicked, this, &MediaPlayer::toggleShuffle);
    connect(repeatButton, &QPushButton::clicked, this, &MediaPlayer::toggleRepeat);
    connect(clearPlaylistButton, &QPushButton::clicked, this, &MediaPlayer::clearPlaylist);

    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::updatePosition);
    connect(mediaPlayer, &QMediaPlayer::durationChanged, this, &MediaPlayer::updateDuration);
    connect(positionSlider, &QSlider::sliderMoved, mediaPlayer, &QMediaPlayer::setPosition);
    connect(volumeSlider, &QSlider::valueChanged, this, &MediaPlayer::setVolume);

    connect(mediaPlayer, &QMediaPlayer::playbackStateChanged, this, &MediaPlayer::updateButtonsState);
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, &MediaPlayer::handleMediaStatusChanged);

    connect(playlistWidget, &QListWidget::itemDoubleClicked, this, &MediaPlayer::playSelectedSong);
    connect(visualizerButton, &QPushButton::clicked, this, &MediaPlayer::toggleVisualizer);
    //default
    //connect(mediaPlayer, &QMediaPlayer::metaDataChanged, this, &MediaPlayer::updateDefaultVisualizer);

    mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(equalizerView);

    QHBoxLayout *controlButtonsLayout = new QHBoxLayout();
    controlButtonsLayout->addWidget(openButton);
    controlButtonsLayout->addWidget(previousButton);
    controlButtonsLayout->addWidget(playButton);
    controlButtonsLayout->addWidget(pauseButton);
    controlButtonsLayout->addWidget(stopButton);
    controlButtonsLayout->addWidget(nextButton);

    QHBoxLayout *modeButtonsLayout = new QHBoxLayout();
    modeButtonsLayout->addWidget(shuffleButton);
    modeButtonsLayout->addWidget(repeatButton);
    modeButtonsLayout->addWidget(clearPlaylistButton);

    mainLayout->addLayout(controlButtonsLayout);
    mainLayout->addLayout(modeButtonsLayout);
    mainLayout->addWidget(positionSlider);
    mainLayout->addWidget(timeLabel);

    QHBoxLayout *volumeLayout = new QHBoxLayout();
    volumeLayout->addWidget(new QLabel("Volume:", this));
    volumeLayout->addWidget(volumeSlider);
    mainLayout->addLayout(volumeLayout);

    mainLayout->addWidget(visualizerButton); // Add visualizer button to layout
    mainLayout->addWidget(playlistWidget);


    setLayout(mainLayout);

    updateButtonsState(QMediaPlayer::StoppedState);

    equalizerView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    equalizerView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}

MediaPlayer::~MediaPlayer()
{
    equalizerTimer->stop();
    qDeleteAll(rainbowBars); // Changed from equalizerBars to rainbowBars
    qDeleteAll(randomBars); // Also delete random bars
    delete mediaPlayer;
    delete audioOutput;
    qDeleteAll(waveLines);
    delete coverArtItem;
    delete playSymbolItem;
}

void MediaPlayer::updateEqualizer()
{
    qint64 time = QDateTime::currentMSecsSinceEpoch();
    float intensity = 1.0f;

    // Adjust intensity based on playback state
    if (mediaPlayer->playbackState() == QMediaPlayer::StoppedState) {
        intensity = 0.1f;
    }
    else if (mediaPlayer->playbackState() == QMediaPlayer::PausedState) {
        intensity = 0.3f;
    }

    if (currentVisualizer == DEFAULT) {
        // Hide all other visual elements
        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
        for (auto wave : waveItems) wave->setVisible(false);

        updateDefaultVisualizer(); // Handles showing either cover or triangle
    }
    else if (currentVisualizer == RAINBOW) {
        // Show rainbow bars
        for (int i = 0; i < 16; i++) {
            // Smooth animation with intensity control
            float height = 2 + intensity * qAbs(60 * sin(time/80.0 + i*0.3) * cos(time/120.0 + i*0.2));
            rainbowBars[i]->setRect(0, 100-height, 10, height); // Bars grow downward
            rainbowBars[i]->setVisible(true);
        }
        // Hide other visualizers
        for (auto wave : waveLines) wave->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);  // Hide the triangle
    }
    else if (currentVisualizer == RANDOM) {
        // Only update every N frames (0 = update every frame)
        m_randomUpdateCounter = (m_randomUpdateCounter + 1) % (RANDOM_SKIP_FRAMES + 1);

        if (m_randomUpdateCounter == 0) {
            // Original random bars code (unchanged!)
            for (int i = 0; i < randomBars.size(); i++) {
                float randomFactor = 0.5 + randomGenerator.generateDouble();
                float height = 2 + intensity * 60 * fabs(
                                       sin(time/(120.0 * (0.5 + randomFactor))) +
                                       cos(time/(150.0 * (0.5 + i/75.0)))
                                       );

                randomBars[i]->setRect(0, 100-height, 3, height);
                randomBars[i]->setVisible(true);

                int blueValue = 200 + 55 * sin(time/1000.0 + i/25.0);
                randomBars[i]->setBrush(QColor(100, 150, qBound(150, blueValue, 255)));
            }
        }

        // Hide other visualizers
        for (auto wave : waveLines) wave->setVisible(false);
        for (auto bar : rainbowBars) bar->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);
    }
    else if (currentVisualizer == WAVE) {
        // Hide other visualizers
        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);  // Hide the triangle

        // Enhanced state parameters
        float intensity, spacing, speedFactor, widthMultiplier;

        switch(mediaPlayer->playbackState()) {
        case QMediaPlayer::PlayingState:
            intensity = 1.0f;
            spacing = 1.6f;  // Wider spacing
            speedFactor = qMin(m_waveSpeedMultiplier + 0.005f, 1.8f); // Faster
            widthMultiplier = 1.3f; // Wider waves
            break;
        case QMediaPlayer::PausedState:
            intensity = 0.8f;  // Stronger presence
            spacing = 1.3f;
            speedFactor = 0.7f;
            widthMultiplier = 1.2f;
            break;
        case QMediaPlayer::StoppedState:
            intensity = 0.6f;  // More visible than before
            spacing = 1.1f;
            speedFactor = 0.5f;
            widthMultiplier = 1.1f;
            break;
        }

        // Update all timers (continuous movement)
        for (int i = 0; i < waveTimers.size(); i++) {
            waveTimers[i] += 20 * (0.7f + i*0.15f) * speedFactor;
        }
        m_waveSpeedMultiplier = speedFactor;

        // Wave drawing with enhanced presence
        const int SEGMENTS = 120; // More segments for wider waves
        float centerY = equalizerView->height() * 0.5f;
        float width = equalizerView->width() * widthMultiplier; // Wider base

        for (int waveIdx = 0; waveIdx < waveItems.size(); waveIdx++) {
            QPainterPath path;
            float verticalOffset = waveIdx * 25 * (spacing-1); // More spacing
            path.moveTo(-width*0.15f, centerY + verticalOffset); // Start off-screen

            float amplitude = (30.0f - waveIdx*4.0f) * intensity; // Taller waves
            float wavelength = width / (1.8f + waveIdx*0.25f); // Longer waves

            for (int x = 0; x <= width*1.15f; x += width/SEGMENTS) {
                float wavePos = x - width*0.15f; // Center the waves

                // Core wave with enhanced physics
                float y = amplitude * (
                              sin(waveTimers[waveIdx]*0.0008f - wavePos/wavelength) +
                              0.3f * cos(waveTimers[waveIdx]*0.0015f - wavePos/(wavelength*0.7f))
                              );

                // Interactions
                if (intensity > 0.5f) {
                    for (int otherIdx = 0; otherIdx < waveItems.size(); otherIdx++) {
                        if (otherIdx != waveIdx) {
                            float influence = 0.5f * intensity;
                            y += influence * amplitude * 0.3f *
                                 sin(waveTimers[otherIdx]*0.001f - wavePos/(wavelength*1.1f));
                        }
                    }
                }

                path.lineTo(wavePos, centerY + y + verticalOffset);
            }

            // Enhanced visual styling
            QColor waveColor = QColor::fromHsv(
                270 + waveIdx*25,
                190 + 50 * intensity,
                220 + 35 * intensity
                );
            waveColor.setAlpha(200 + 55 * intensity);

            waveItems[waveIdx]->setPen(QPen(waveColor,
                                            3.0f + 2.0f * intensity)); // Much thicker lines
            waveItems[waveIdx]->setPath(path);
            waveItems[waveIdx]->setVisible(true);
        }
    }
}

void MediaPlayer::toggleVisualizer()
{
    currentVisualizer = static_cast<VisualizerMode>((currentVisualizer + 1) % 4);

    switch (currentVisualizer) {
    case DEFAULT:
        visualizerButton->setText("Visualizer (Default)");
        break;
    case RAINBOW:
        visualizerButton->setText("Visualizer (Rainbow)");
        break;
    case RANDOM:
        visualizerButton->setText("Visualizer (Random)");
        break;
    case WAVE:
        visualizerButton->setText("Visualizer (Wave)");
        break;
    }

    updateEqualizer();
}



void MediaPlayer::updateDefaultVisualizer() {
    // Always hide both first
    coverArtItem->setVisible(false);
    playSymbolItem->setVisible(false);

    // Try to get cover art from current media (path-based fallback)
    QUrl mediaUrl = mediaPlayer->source();
    if (mediaUrl.isLocalFile()) {
        QString filePath = mediaUrl.toLocalFile();
        QImage coverImage;

// First try reading embedded cover art
#ifdef TAGLIB_FOUND  // If you have taglib support
        coverImage = AudioTagReader::extractCoverArt(filePath);
#endif

        // If no embedded art, look for cover.jpg/png in same directory
        if (coverImage.isNull()) {
            QFileInfo fi(filePath);
            QString dir = fi.path();
            QStringList possibleCovers = {
                dir + "/cover.jpg",
                dir + "/cover.png",
                dir + "/" + fi.completeBaseName() + ".jpg"
            };

            foreach (QString path, possibleCovers) {
                if (QFile::exists(path)) {
                    coverImage.load(path);
                    if (!coverImage.isNull()) break;
                }
            }
        }

        // If we found cover art, display it
        if (!coverImage.isNull()) {
            QPixmap coverPixmap = QPixmap::fromImage(coverImage.scaled(
                equalizerView->width() * 0.75,
                equalizerView->height() * 0.75,
                Qt::KeepAspectRatio,
                Qt::SmoothTransformation
                ));

            coverArtItem->setPixmap(coverPixmap);
            coverArtItem->setPos(
                (equalizerView->width() - coverPixmap.width())/2,
                (equalizerView->height() - coverPixmap.height())/2
                );
            coverArtItem->setVisible(true);
            return;
        }
    }

    // If no cover art found, show play symbol in DEFAULT mode
    if (currentVisualizer == DEFAULT) {
        playSymbolItem->setVisible(true);
    }
}

void MediaPlayer::openFile() // This function is not connected to any button in the current setup.
{
    QString filePath = QFileDialog::getOpenFileName(this, "Open Media File",
                                                    QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                    "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");
    if (!filePath.isEmpty()) {
        playlist.clear();
        playlist.append(QUrl::fromLocalFile(filePath));
        currentIndex = 0;
        playlistWidget->clear();
        playlistWidget->addItem(QFileInfo(filePath).fileName());
        playCurrentSong();
    }
}

void MediaPlayer::setVolume(int volume)
{
    audioOutput->setVolume(volume / 100.0);
}

void MediaPlayer::updatePosition(qint64 position)
{
    positionSlider->setValue(static_cast<int>(position));
    updateTimeLabel(position, mediaPlayer->duration());
}

void MediaPlayer::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, static_cast<int>(duration));
    updateTimeLabel(mediaPlayer->position(), duration);
}

void MediaPlayer::updateTimeLabel(qint64 currentPos, qint64 totalDuration)
{
    qint64 currentSeconds = currentPos / 1000;
    qint64 totalSeconds = totalDuration / 1000;

    int currentMinutes = static_cast<int>(currentSeconds / 60);
    int currentSecs = static_cast<int>(currentSeconds % 60);
    int totalMinutes = static_cast<int>(totalSeconds / 60);
    int totalSecs = static_cast<int>(totalSeconds % 60);

    timeLabel->setText(QString("%1:%2 / %3:%4")
                           .arg(currentMinutes, 2, 10, QChar('0'))
                           .arg(currentSecs, 2, 10, QChar('0'))
                           .arg(totalMinutes, 2, 10, QChar('0'))
                           .arg(totalSecs, 2, 10, QChar('0')));
}

void MediaPlayer::updateButtonsState(QMediaPlayer::PlaybackState state)
{
    playButton->setEnabled(state != QMediaPlayer::PlayingState);
    pauseButton->setEnabled(state == QMediaPlayer::PlayingState);
    stopButton->setEnabled(state != QMediaPlayer::StoppedState);

    bool enablePlaylistControls = !playlist.isEmpty();
    nextButton->setEnabled(enablePlaylistControls);
    previousButton->setEnabled(enablePlaylistControls);
    shuffleButton->setEnabled(enablePlaylistControls);
    repeatButton->setEnabled(enablePlaylistControls);
    clearPlaylistButton->setEnabled(enablePlaylistControls);
}

void MediaPlayer::handleMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        qDebug() << "End of media reached. Playing next song.";
        playNextSong();
    } else if (status == QMediaPlayer::InvalidMedia) {
        qDebug() << "Invalid media source.";
        QMessageBox::warning(this, "Error", "Could not play media. Invalid format or corrupted file.");
        playNextSong();
    }
}

void MediaPlayer::playCurrentSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        qDebug() << "Playlist is empty. Cannot play song.";
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex < 0 || currentIndex >= playlist.size()) {
        qDebug() << "Current index out of bounds. Resetting to 0.";
        currentIndex = 0;
    }

    QUrl currentSource;
    if (isShuffled && !shuffledIndices.isEmpty()) {

        if (currentIndex < 0 || currentIndex >= shuffledIndices.size()) {
            qDebug() << "Shuffled index out of bounds. Resetting.";
            currentIndex = 0;
        }
        currentSource = playlist[shuffledIndices[currentIndex]];
    } else {

        currentSource = playlist[currentIndex];
    }

    mediaPlayer->setSource(currentSource);
    mediaPlayer->play();
    qDebug() << "Playing: " << currentSource.toLocalFile();
    updatePlaylistWidgetSelection();
}

void MediaPlayer::playNextSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    int nextIndex = currentIndex;

    if (repeatMode == 2) {

        qDebug() << "Repeat One: Replaying current song.";
    } else {
        nextIndex++;
        if (isShuffled) {
            if (nextIndex >= shuffledIndices.size()) {
                if (repeatMode == 1) {
                    nextIndex = 0;
                    qDebug() << "Repeat All (Shuffled): Wrapping around to first shuffled song.";
                } else {
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    qDebug() << "No Repeat (Shuffled): End of playlist reached.";
                    return;
                }
            }
        } else {
            if (nextIndex >= playlist.size()) {
                if (repeatMode == 1) {
                    nextIndex = 0;
                    qDebug() << "Repeat All: Wrapping around to first song.";
                } else {
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    qDebug() << "No Repeat: End of playlist reached.";
                    return;
                }
            }
        }
    }
    currentIndex = nextIndex;
    playCurrentSong();
}

void MediaPlayer::playPreviousSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex <= 0) {

        if (repeatMode == 1) { // Repeat All
            currentIndex = (isShuffled ? shuffledIndices.size() : playlist.size()) - 1;
            qDebug() << "Repeat All: Wrapping around to last song.";
        } else {
            currentIndex = 0;
            qDebug() << "Previous: Already at the first song.";
        }
    } else {
        currentIndex--;
    }
    playCurrentSong();
}

void MediaPlayer::toggleShuffle()
{
    isShuffled = !isShuffled;
    if (isShuffled) {
        shuffleButton->setText("Shuffle (On)");
        shuffledIndices.clear();
        for (int i = 0; i < playlist.size(); ++i) {
            shuffledIndices.append(i);
        }

        std::random_shuffle(shuffledIndices.begin(), shuffledIndices.end());
        qDebug() << "Shuffle On. Shuffled order: " << shuffledIndices;
    } else {
        shuffleButton->setText("Shuffle (Off)");
        shuffledIndices.clear();
        qDebug() << "Shuffle Off.";
    }
}

void MediaPlayer::toggleRepeat()
{
    repeatMode = (repeatMode + 1) % 3; // 0 -> 1 -> 2 -> 0
    switch (repeatMode) {
    case 0:
        repeatButton->setText("Repeat (Off)");
        qDebug() << "Repeat Off.";
        break;
    case 1:
        repeatButton->setText("Repeat (All)");
        qDebug() << "Repeat All.";
        break;
    case 2:
        repeatButton->setText("Repeat (One)");
        qDebug() << "Repeat One.";
        break;
    }
}

void MediaPlayer::addFilesToPlaylist()
{
    QStringList filePaths = QFileDialog::getOpenFileNames(this, "Add Media Files",
                                                          QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                          "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");

    if (!filePaths.isEmpty()) {
        for (const QString &filePath : filePaths) {
            QUrl url = QUrl::fromLocalFile(filePath);
            playlist.append(url);
            playlistWidget->addItem(QFileInfo(filePath).fileName());
        }

        if (currentIndex == -1 && !playlist.isEmpty()) {
            currentIndex = 0;
            playCurrentSong();
        }

        // Re-shuffle if shuffle is on and new songs are added
        if (isShuffled) {
            toggleShuffle(); // Turn off shuffle
            toggleShuffle(); // Turn on shuffle to re-shuffle with new songs
        }
        updateButtonsState(mediaPlayer->playbackState());
    }
}

void MediaPlayer::playSelectedSong(QListWidgetItem *item)
{
    if (!item) return;

    // Find the index of the selected item in the *original* playlist
    int originalPlaylistIndex = -1;
    QString fileNameToFind = item->text();

    for (int i = 0; i < playlist.size(); ++i) {
        if (QFileInfo(playlist[i].toLocalFile()).fileName() == fileNameToFind) {
            originalPlaylistIndex = i;
            break;
        }
    }

    if (originalPlaylistIndex != -1) {
        if (isShuffled) {
            // If shuffled, we need to find where this 'originalPlaylistIndex' is in our shuffled order
            // and set currentIndex to that position in shuffledIndices.
            for (int i = 0; i < shuffledIndices.size(); ++i) {
                if (shuffledIndices[i] == originalPlaylistIndex) {
                    currentIndex = i;
                    break;
                }
            }
        } else {
            currentIndex = originalPlaylistIndex;
        }
        playCurrentSong();
    }
}

void MediaPlayer::clearPlaylist()
{
    mediaPlayer->stop();
    playlist.clear();
    shuffledIndices.clear();
    currentIndex = -1;
    playlistWidget->clear();
    qDebug() << "Playlist cleared.";
    updateButtonsState(QMediaPlayer::StoppedState);
    updateTimeLabel(0,0);
}

void MediaPlayer::updatePlaylistWidgetSelection()
{
    playlistWidget->clearSelection();

    if (currentIndex != -1 && !playlist.isEmpty()) {
        int actualSongIndex = currentIndex;
        if (isShuffled && !shuffledIndices.isEmpty() && currentIndex < shuffledIndices.size()) {
            actualSongIndex = shuffledIndices[currentIndex];
        }

        if (actualSongIndex >= 0 && actualSongIndex < playlistWidget->count()) {
            QListWidgetItem *item = playlistWidget->item(actualSongIndex);
            if (item) {
                item->setSelected(true);
                playlistWidget->scrollToItem(item);
            }
        }
    }
}
