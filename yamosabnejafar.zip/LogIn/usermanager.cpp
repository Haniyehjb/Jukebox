// usermanager.cpp
#include "UserManager.h"
#include <QStringList>
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include "Song.h" // Ensure Song.h is included for Song class definition
#include "User.h"
#include "Playlist.h"

UserManager* UserManager::instance = nullptr;

UserManager* UserManager::getInstance() {
    if (!instance)
        instance = new UserManager;
    return instance;
}

void UserManager::loadFromFile(const QString& path) {
    try {
        users.clear(); // Clear existing user data

        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qWarning() << "Error opening file for reading:" << file.errorString();
            return;
        }

        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();
            if (line.trimmed().isEmpty()) continue;

            QStringList parts = line.split(' ');
            // Minimum parts for user data: username, password, fullName, email, question, answer
            if (parts.size() < 6) {
                qWarning() << "Skipping malformed user line (too few parts):" << line;
                continue;
            }

            User user(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);

            if (parts.size() > 6) { // Check if playlist data exists
                int playlistCount = parts[6].toInt();
                int index = 7;

                for (int i = 0; i < playlistCount; ++i) {
                    if (index >= parts.size()) {
                        qWarning() << "Malformed playlist data: missing playlist name or song count. Line:" << line;
                        break;
                    }
                    QString playlistName = parts[index++];
                    int songCount = parts[index++].toInt();
                    Playlist pl(playlistName);

                    for (int j = 0; j < songCount; ++j) {
                        if (index >= parts.size()) {
                            qWarning() << "Malformed song data: missing song filePath. Line:" << line;
                            break;
                        }
                        QString songFilePath = parts[index++]; // This should now only be the file path
                        // *** KEY CHANGE: Create Song object using only filePath ***
                        Song s(songFilePath); // The Song constructor now only takes filePath
                        pl.addSong(s);
                    }
                    user.addPlaylist(pl);
                }
            }
            users.append(user);
        }
        file.close();
    } catch (const std::exception& e) {
        qCritical() << "Error loading file:" << e.what();
        QMessageBox::critical(nullptr, "File Load Error", e.what());
    } catch (...) {
        qCritical() << "Unknown error loading file.";
        QMessageBox::critical(nullptr, "File Load Error", "An unknown error occurred while loading user data.");
    }
}

void UserManager::saveToFile(const QString& path) {
    try {
        QFile file(path);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            qWarning() << "Error opening file for writing:" << file.errorString();
            return;
        }

        QTextStream out(&file);

        for (const User& user : users) {
            out << user.username << " "
                << user.hashedPassword << " "
                << user.fullName << " "
                << user.email << " "
                << user.question << " "
                << user.answer << " "
                << user.playlists.size() << " ";

            for (const Playlist& pl : user.playlists) {
                out << pl.name << " " << pl.songs.size() << " ";
                for (const Song& song : pl.songs)
                    // *** KEY CHANGE: Only save filePath ***
                    out << song.filePath << " "; // Only save the file path now
            }
            out << "\n"; // Newline after each user's data
        }
        file.close();
    } catch (const std::exception& e) {
        qCritical() << "Error saving file:" << e.what();
        QMessageBox::critical(nullptr, "File Save Error", e.what());
    } catch (...) {
        qCritical() << "Unknown error saving file.";
        QMessageBox::critical(nullptr, "File Save Error", "An unknown error occurred while saving user data.");
    }
}

bool UserManager::userExists(const QString& username) {
    for (const User& user : users) {
        if (user.username == username)
            return true;
    }
    return false;
}
