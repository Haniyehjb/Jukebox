#include "mediaplayer.h"
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QUrl>
#include <QGraphicsLinearLayout>
#include <QRandomGenerator>
#include <QStandardPaths>
#include <QDateTime>
#include <algorithm> // For std::random_shuffle
#include <QDir>
#include <QPainterPath> // For QPainterPath
#include <QVBoxLayout> // Explicitly include for member layouts
#include <QHBoxLayout> // Explicitly include for member layouts
// #include "user.h" // Already included via mediaplayer.h, so not strictly needed here again but doesn't hurt.

// Constructor 1: Original (no user data)
MediaPlayer::MediaPlayer(QWidget *parent)
    : QWidget(parent),
    mediaPlayer(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentIndex(-1),
    isShuffled(false),
    repeatMode(0),
    currentVisualizer(DEFAULT),
    randomGenerator(QDateTime::currentMSecsSinceEpoch()),
    m_loggedUser(nullptr), // Initialize new members
    m_allUsers(nullptr) // Initialize new members
{
    commonInitialization();
    loadMusicOnStartup(); // Load general music on startup
}

// Constructor 2: NEW (with user data) - Matches the call in login.cpp
MediaPlayer::MediaPlayer(User* loggedUser, QVector<User>* allUsers, QWidget *parent)
    : QWidget(parent),
    mediaPlayer(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentIndex(-1),
    isShuffled(false),
    repeatMode(0),
    currentVisualizer(DEFAULT),
    randomGenerator(QDateTime::currentMSecsSinceEpoch()),
    m_loggedUser(loggedUser), // Assign logged user
    m_allUsers(allUsers) // Assign all users
{
    commonInitialization();
    // Here you might want to load music specific to the logged-in user's playlists
    // For now, let's call the general loadMusicOnStartup, but you could add
    // logic like: loadUserPlaylists(m_loggedUser->playlists);
    loadMusicOnStartup();
}

// Common initialization for both constructors
void MediaPlayer::commonInitialization()
{
    mediaPlayer->setAudioOutput(audioOutput);
    audioOutput->setVolume(50);

    equalizerScene = new QGraphicsScene(this);
    equalizerView = new QGraphicsView(equalizerScene, this);
    equalizerView->setFixedHeight(200);

    for (int i = 0; i < 16; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 0, 10, 2);
        bar->setPos(i * 15, 0);
        bar->setBrush(QColor::fromHsv(i * 15, 255, 200));
        rainbowBars.append(bar);
        equalizerScene->addItem(bar);
    }

    for (int i = 0; i < 150; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 0, 3, 2);
        bar->setPos(i * 5, 0);
        bar->setBrush(QColor(100, 150, 255));
        bar->setVisible(false);
        randomBars.append(bar);
        equalizerScene->addItem(bar);
    }

    for (int i = 0; i < 3; i++) {
        QGraphicsPathItem* wave = new QGraphicsPathItem();
        wave->setPen(QPen(QColor::fromHsv(270 + i*30, 200, 220, 200), 3.0f));
        wave->setVisible(false);
        waveItems.append(wave);
        equalizerScene->addItem(wave);
        waveTimers.append(i * 1000.0f);
    }

    gravityBarStates.resize(randomBars.size());
    for (int i = 0; i < gravityBarStates.size(); i++) {
        gravityBarStates[i] = {2.0f, 2.0f, 0.0f, 0.0f, false}; // Added smoothTarget and isPopping init
        randomBars[i]->setRect(0, 100-2, 3, 2);
    }
    lastGravityRandomizeTime = QTime::currentTime();

    equalizerTimer = new QTimer(this);
    connect(equalizerTimer, &QTimer::timeout, this, &MediaPlayer::updateEqualizer);
    equalizerTimer->start(20);

    openButton = new QPushButton("Open File(s)", this);
    playButton = new QPushButton("Play", this);
    pauseButton = new QPushButton("Pause", this);
    stopButton = new QPushButton("Stop", this);

    nextButton = new QPushButton("Next", this);
    previousButton = new QPushButton("Previous", this);
    shuffleButton = new QPushButton("Shuffle (Off)", this);
    repeatButton = new QPushButton("Repeat (Off)", this);
    clearPlaylistButton = new QPushButton("Clear Playlist", this);

    positionSlider = new QSlider(Qt::Horizontal, this);
    positionSlider->setRange(0, 0);
    volumeSlider = new QSlider(Qt::Horizontal, this);
    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(50);
    timeLabel = new QLabel("00:00 / 00:00", this);

    playlistWidget = new QListWidget(this);

    visualizerButton = new QPushButton("Visualizer (Default)", this);

    QPolygonF triangle;
    triangle << QPointF(0, 0) << QPointF(0, 100) << QPointF(87, 50);
    playSymbolItem = new QGraphicsPolygonItem(triangle);
    playSymbolItem->setBrush(QColor(150, 150, 150, 220));
    playSymbolItem->setPen(QPen(QColor(100, 100, 100, 220), 2.5f));
    playSymbolItem->setVisible(false);
    // Adjusted initial position calculation based on current dimensions, will be correct on resize.
    playSymbolItem->setPos(equalizerView->width()/2 - playSymbolItem->boundingRect().width()/2,
                           equalizerView->height()/2 - playSymbolItem->boundingRect().height()/2);
    playSymbolItem->setZValue(1);
    equalizerScene->addItem(playSymbolItem);

    coverArtItem = new QGraphicsPixmapItem();
    coverArtItem->setVisible(false);
    coverArtItem->setZValue(2);
    equalizerScene->addItem(coverArtItem);


    connect(openButton, &QPushButton::clicked, this, &MediaPlayer::addFilesToPlaylist);
    connect(playButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::play);
    connect(pauseButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::pause);
    connect(stopButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::stop);

    connect(nextButton, &QPushButton::clicked, this, &MediaPlayer::playNextSong);
    connect(previousButton, &QPushButton::clicked, this, &MediaPlayer::playPreviousSong);
    connect(shuffleButton, &QPushButton::clicked, this, &MediaPlayer::toggleShuffle);
    connect(repeatButton, &QPushButton::clicked, this, &MediaPlayer::toggleRepeat);
    connect(clearPlaylistButton, &QPushButton::clicked, this, &MediaPlayer::clearPlaylist);

    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::updatePosition);
    connect(mediaPlayer, &QMediaPlayer::durationChanged, this, &MediaPlayer::updateDuration);
    connect(positionSlider, &QSlider::sliderMoved, mediaPlayer, &QMediaPlayer::setPosition);
    connect(volumeSlider, &QSlider::valueChanged, this, &MediaPlayer::setVolume);

    connect(mediaPlayer, &QMediaPlayer::playbackStateChanged, this, &MediaPlayer::updateButtonsState);
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, &MediaPlayer::handleMediaStatusChanged);

    connect(playlistWidget, &QListWidget::itemDoubleClicked, this, &MediaPlayer::playSelectedSong);
    connect(visualizerButton, &QPushButton::clicked, this, &MediaPlayer::toggleVisualizer);

    // LAYOUT INITIALIZATION - Assign to member variables
    mainLayout = new QVBoxLayout(this);

    controlButtonsLayout = new QHBoxLayout(); // Corrected: assign to member, not local variable
    controlButtonsLayout->addWidget(openButton);
    controlButtonsLayout->addWidget(previousButton);
    controlButtonsLayout->addWidget(playButton);
    controlButtonsLayout->addWidget(pauseButton);
    controlButtonsLayout->addWidget(stopButton);
    controlButtonsLayout->addWidget(nextButton);

    modeButtonsLayout = new QHBoxLayout(); // Corrected: assign to member, not local variable
    modeButtonsLayout->addWidget(shuffleButton);
    modeButtonsLayout->addWidget(repeatButton);
    modeButtonsLayout->addWidget(clearPlaylistButton);

    mainLayout->addLayout(controlButtonsLayout);
    mainLayout->addLayout(modeButtonsLayout);
    mainLayout->addWidget(positionSlider);
    mainLayout->addWidget(timeLabel);

    volumeLayout = new QHBoxLayout(); // Corrected: assign to member, not local variable
    volumeLayout->addWidget(new QLabel("Volume:", this));
    volumeLayout->addWidget(volumeSlider);
    mainLayout->addLayout(volumeLayout);

    mainLayout->addWidget(visualizerButton);
    mainLayout->addWidget(playlistWidget);


    setLayout(mainLayout);

    updateButtonsState(QMediaPlayer::StoppedState);

    equalizerView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    equalizerView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // No loadMusicOnStartup here. It's called from the constructors.
}

MediaPlayer::~MediaPlayer()
{
    equalizerTimer->stop();
    qDeleteAll(rainbowBars);
    qDeleteAll(randomBars);
    delete mediaPlayer;
    delete audioOutput;
    qDeleteAll(waveItems);
    delete coverArtItem;
    delete playSymbolItem;
    // Do NOT delete m_loggedUser or m_allUsers here as they are owned by UserManager.
}

void MediaPlayer::updateEqualizer()
{
    qint64 time = QDateTime::currentMSecsSinceEpoch();
    float intensity = 1.0f;

    if (mediaPlayer->playbackState() == QMediaPlayer::StoppedState) {
        intensity = 0.1f;
    }
    else if (mediaPlayer->playbackState() == QMediaPlayer::PausedState) {
        intensity = 0.3f;
    }

    if (currentVisualizer == DEFAULT) {
        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
        for (auto wave : waveItems) wave->setVisible(false);

        updateDefaultVisualizer();
    }
    else if (currentVisualizer == RAINBOW) {
        for (int i = 0; i < 16; i++) {
            float height = 2 + intensity * qAbs(60 * sin(time/80.0 + i*0.3) * cos(time/120.0 + i*0.2));
            rainbowBars[i]->setRect(0, 100-height, 10, height);
            rainbowBars[i]->setVisible(true);
        }
        for (auto wave : waveItems) wave->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);
    }
    else if (currentVisualizer == RANDOM) {
        m_randomUpdateCounter = (m_randomUpdateCounter + 1) % (RANDOM_SKIP_FRAMES + 1);

        if (m_randomUpdateCounter == 0) {
            for (int i = 0; i < randomBars.size(); i++) {float randomFactor = 0.5 + randomGenerator.generateDouble();
                float height = 2 + intensity * 60 * fabs(
                                       sin(time/(120.0 * (0.5 + randomFactor))) +
                                       cos(time/(150.0 * (0.5 + i/75.0)))
                                       );

                randomBars[i]->setRect(0, 100-height, 3, height);
                randomBars[i]->setVisible(true);

                int blueValue = 200 + 55 * sin(time/1000.0 + i/25.0);
                randomBars[i]->setBrush(QColor(100, 150, qBound(150, blueValue, 255)));
            }
        }

        for (auto wave : waveItems) wave->setVisible(false);
        for (auto bar : rainbowBars) bar->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);
    }
    else if (currentVisualizer == WAVE) {
        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto bar : randomBars) bar->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);

        float intensity_local, spacing, speedFactor, widthMultiplier; // Renamed intensity to intensity_local to avoid shadowing

        switch(mediaPlayer->playbackState()) {
        case QMediaPlayer::PlayingState:
            intensity_local = 1.0f;
            spacing = 1.6f;
            speedFactor = qMin(m_waveSpeedMultiplier + 0.005f, 1.8f);
            widthMultiplier = 1.3f;
            break;
        case QMediaPlayer::PausedState:
            intensity_local = 0.8f;
            spacing = 1.3f;
            speedFactor = 0.7f;
            widthMultiplier = 1.2f;
            break;
        case QMediaPlayer::StoppedState:
            intensity_local = 0.6f;
            spacing = 1.1f;
            speedFactor = 0.5f;
            widthMultiplier = 1.1f;
            break;
        default: // Handle other states or just set defaults
            intensity_local = 0.0f; spacing = 1.0f; speedFactor = 0.0f; widthMultiplier = 1.0f;
            break;
        }

        for (int waveIdx = 0; waveIdx < waveTimers.size(); waveIdx++) { // Corrected: loop variable to waveIdx
            waveTimers[waveIdx] += 20 * (0.7f + waveIdx*0.15f) * speedFactor;
        }
        m_waveSpeedMultiplier = speedFactor;

        const int SEGMENTS = 120;
        float centerY = equalizerView->height() * 0.5f;
        float width = equalizerView->width() * widthMultiplier;

        for (int waveIdx = 0; waveIdx < waveItems.size(); waveIdx++) {
            QPainterPath path;
            float verticalOffset = waveIdx * 25 * (spacing-1);
            path.moveTo(-width*0.15f, centerY + verticalOffset);

            float amplitude = (30.0f - waveIdx*4.0f) * intensity_local;
            float wavelength = width / (1.8f + waveIdx*0.25f);

            for (int x = 0; x <= width*1.15f; x += width/SEGMENTS) {
                float wavePos = x - width*0.15f;

                float y = amplitude * (
                              sin(waveTimers[waveIdx]*0.0008f - wavePos/wavelength) +
                              0.3f * cos(waveTimers[waveIdx]*0.0015f - wavePos/(wavelength*0.7f))
                              );

                if (intensity_local > 0.5f) {
                    for (int otherIdx = 0; otherIdx < waveItems.size(); otherIdx++) {
                        if (otherIdx != waveIdx) {
                            float influence = 0.5f * intensity_local;
                            y += influence * amplitude * 0.3f *
                                 sin(waveTimers[otherIdx]*0.001f - wavePos/(wavelength*1.1f));
                        }
                    }
                }

                path.lineTo(wavePos, centerY + y + verticalOffset);
            }

            QColor waveColor = QColor::fromHsv(
                270 + waveIdx*25,
                static_cast<int>(190 + 50 * intensity_local), // Cast to int for Hsv
                static_cast<int>(220 + 35 * intensity_local)  // Cast to int for Hsv
                );
            waveColor.setAlpha(static_cast<int>(200 + 55 * intensity_local)); // Cast to int for setAlpha

            waveItems[waveIdx]->setPen(QPen(waveColor,
                                            3.0f + 2.0f * intensity_local));
            waveItems[waveIdx]->setPath(path);
            waveItems[waveIdx]->setVisible(true);
        }
    }
    else if (currentVisualizer == GRAVITY) {
        const float current_intensity = mediaPlayer->playbackState() == QMediaPlayer::StoppedState ? 0.3f :mediaPlayer->playbackState() == QMediaPlayer::PausedState ? 0.6f : 1.0f;
        const float deltaTime = 0.016f;

        if (current_intensity == 1.0f && lastGravityRandomizeTime.msecsTo(QTime::currentTime()) > 3000) {
            lastGravityRandomizeTime = QTime::currentTime();

            for (auto& bar : gravityBarStates) {
                bar.targetHeight = 2.0f;
                bar.isPopping = false;
            }

            QTimer::singleShot(800, this, [this]() {
                for (auto& bar : gravityBarStates) {
                    if (randomGenerator.generateDouble() < 0.4f) {
                        bar.targetHeight = 2.0f + 100.0f * randomGenerator.generateDouble();
                        bar.isPopping = true;
                    } else {
                        bar.targetHeight = 2.0f + 30.0f * randomGenerator.generateDouble();
                    }
                }
            });
        }

        for (int i = 0; i < gravityBarStates.size(); i++) {
            auto& bar = gravityBarStates[i];

            float modifiedTarget = 2.0f + (bar.targetHeight - 2.0f) * current_intensity;

            bar.smoothTarget += (modifiedTarget - bar.smoothTarget) * 0.1f;
            bar.velocity += (bar.smoothTarget - bar.currentHeight) * 0.2f;
            bar.velocity *= 0.88f + (0.07f * current_intensity);
            bar.currentHeight = qMax(2.0f, bar.currentHeight + bar.velocity * deltaTime * 60.0f);

            randomBars[i]->setRect(0, 100 - bar.currentHeight, 3, bar.currentHeight);
            randomBars[i]->setBrush(QColor::fromHsv(
                220 + static_cast<int>(bar.currentHeight * 0.3f), // Cast to int
                200,
                160 + randomGenerator.bounded(60)
                ));
            randomBars[i]->setVisible(true);
        }

        for (auto bar : rainbowBars) bar->setVisible(false);
        for (auto wave : waveItems) wave->setVisible(false);
        coverArtItem->setVisible(false);
        playSymbolItem->setVisible(false);
    }
}

void MediaPlayer::toggleVisualizer()
{
    currentVisualizer = static_cast<VisualizerMode>((currentVisualizer + 1) % 5);

    switch (currentVisualizer) {
    case DEFAULT:
        visualizerButton->setText("Visualizer (Default)");
        break;
    case RAINBOW:
        visualizerButton->setText("Visualizer (Rainbow)");
        break;
    case RANDOM:
        visualizerButton->setText("Visualizer (Random)");
        break;
    case WAVE:
        visualizerButton->setText("Visualizer (Wave)");
        break;
    case GRAVITY:
        visualizerButton->setText("Visualizer (Gravity)");
        break;
    }

    updateEqualizer();
}

void MediaPlayer::updateDefaultVisualizer() {
    coverArtItem->setVisible(false);
    playSymbolItem->setVisible(false);

    QUrl mediaUrl = mediaPlayer->source();
    if (mediaUrl.isLocalFile()) {
        QString filePath = mediaUrl.toLocalFile();
        QImage coverImage;

#ifdef TAGLIB_FOUND
        // coverImage = AudioTagReader::extractCoverArt(filePath);
#endif

        if (coverImage.isNull()) {
            QFileInfo fi(filePath);
            QString dir = fi.path();
            QStringList possibleCovers = {
                dir + "/cover.jpg",
                dir + "/cover.png",
                dir + "/" + fi.completeBaseName() + ".jpg"
            };

            foreach (QString path, possibleCovers) {
                if (QFile::exists(path)) {
                    coverImage.load(path);
                    if (!coverImage.isNull()) break;
                }
            }
        }

        if (!coverImage.isNull()) {
            QPixmap coverPixmap = QPixmap::fromImage(coverImage.scaled(
                equalizerView->width() * 0.75,
                equalizerView->height() * 0.75,
                Qt::KeepAspectRatio,
                Qt::SmoothTransformation
                ));

            coverArtItem->setPixmap(coverPixmap);
            coverArtItem->setPos(
                (equalizerView->width() - coverPixmap.width())/2,
                (equalizerView->height() - coverPixmap.height())/2
                );
            coverArtItem->setVisible(true);
            return;
        }
    }

    if (currentVisualizer == DEFAULT) { // Only show play symbol if it's the default visualizer
        playSymbolItem->setVisible(true);
    }
}

void MediaPlayer::openFile()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Open Media File",
                                                    QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                    "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");
    if (!filePath.isEmpty()) {
        playlist.clear();
        playlist.append(QUrl::fromLocalFile(filePath));
        currentIndex = 0;
        playlistWidget->clear();
        playlistWidget->addItem(QFileInfo(filePath).fileName());
        playCurrentSong();
    }
}

void MediaPlayer::setVolume(int volume)
{
    audioOutput->setVolume(volume / 100.0);
}

void MediaPlayer::updatePosition(qint64 position)
{
    positionSlider->setValue(static_cast<int>(position));
    updateTimeLabel(position, mediaPlayer->duration());
}

void MediaPlayer::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, static_cast<int>(duration));
    updateTimeLabel(mediaPlayer->position(), duration);
}

void MediaPlayer::updateTimeLabel(qint64 currentPos, qint64 totalDuration)
{
    qint64 currentSeconds = currentPos / 1000;
    qint64 totalSeconds = totalDuration / 1000;

    int currentMinutes = static_cast<int>(currentSeconds / 60);
    int currentSecs = static_cast<int>(currentSeconds % 60);
    int totalMinutes = static_cast<int>(totalSeconds / 60);
    int totalSecs = static_cast<int>(totalSeconds % 60);

    timeLabel->setText(QString("%1:%2 / %3:%4")
                           .arg(currentMinutes, 2, 10, QChar('0'))
                           .arg(currentSecs, 2, 10, QChar('0'))
                           .arg(totalMinutes, 2, 10, QChar('0'))
                           .arg(totalSecs, 2, 10, QChar('0')));
}

void MediaPlayer::updateButtonsState(QMediaPlayer::PlaybackState state)
{
    playButton->setEnabled(state != QMediaPlayer::PlayingState);
    pauseButton->setEnabled(state == QMediaPlayer::PlayingState);
    stopButton->setEnabled(state != QMediaPlayer::StoppedState);

    bool enablePlaylistControls = !playlist.isEmpty();
    nextButton->setEnabled(enablePlaylistControls);
    previousButton->setEnabled(enablePlaylistControls);
    shuffleButton->setEnabled(enablePlaylistControls);
    repeatButton->setEnabled(enablePlaylistControls);
    clearPlaylistButton->setEnabled(enablePlaylistControls);
}

void MediaPlayer::handleMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        qDebug() << "Media playback ended.";
        playNextSong();
    } else if (status == QMediaPlayer::InvalidMedia) {
        qDebug() << "Invalid media detected!";
        QMessageBox::warning(this, "Error", "Could not play media. Invalid format or corrupted file.");
        playNextSong();
    }
}

void MediaPlayer::playCurrentSong()
{
    if (playlist.isEmpty()) {
        qDebug() << "Playlist is empty, cannot play song.";
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex < 0 || currentIndex >= playlist.size()) {
        qDebug() << "Invalid currentIndex, resetting to 0.";
        currentIndex = 0;
    }

    QUrl currentSource;
    if (isShuffled && !shuffledIndices.isEmpty()) {
        if (currentIndex < 0 || currentIndex >= shuffledIndices.size()) {
            currentIndex = 0;
        }
        currentSource = playlist[shuffledIndices[currentIndex]];
    } else {
        currentSource = playlist[currentIndex];
    }

    qDebug() << "Attempting to play: " << currentSource.toLocalFile();
    mediaPlayer->setSource(currentSource);
    mediaPlayer->play();
    updatePlaylistWidgetSelection();
}

void MediaPlayer::playNextSong()
{
    if (playlist.isEmpty()) {
        qDebug() << "Playlist is empty, cannot play next song.";
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    int nextIndex = currentIndex;

    if (repeatMode == 2) {
        qDebug() << "Repeat One mode: staying on current song.";
    } else {
        nextIndex++;
        if (isShuffled) {
            if (nextIndex >= shuffledIndices.size()) {
                if (repeatMode == 1) {
                    qDebug() << "Repeat All mode (Shuffled): wrapping to beginning.";
                    nextIndex = 0;
                } else {
                    qDebug() << "End of shuffled playlist. Stopping playback.";
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    return;
                }
            }
        } else {
            if (nextIndex >= playlist.size()) {
                if (repeatMode == 1) {
                    qDebug() << "Repeat All mode: wrapping to beginning.";
                    nextIndex = 0;
                } else {
                    qDebug() << "End of playlist. Stopping playback.";
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    return;
                }
            }
        }
    }
    currentIndex = nextIndex;
    playCurrentSong();
}

void MediaPlayer::playPreviousSong()
{
    if (playlist.isEmpty()) {
        qDebug() << "Playlist is empty, cannot play previous song.";
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex <= 0) {
        if (repeatMode == 1) {
            qDebug() << "Repeat All mode: wrapping to end of playlist.";
            currentIndex = (isShuffled ? shuffledIndices.size() : playlist.size()) - 1;
        } else {
            qDebug() << "At beginning of playlist. Staying on first song.";
            currentIndex = 0;
        }
    } else {
        currentIndex--;
    }
    playCurrentSong();
}

void MediaPlayer::toggleShuffle()
{
    isShuffled = !isShuffled;
    if (isShuffled) {
        shuffleButton->setText("Shuffle (On)");
        shuffledIndices.clear();
        for (int i = 0; i < playlist.size(); ++i) {
            shuffledIndices.append(i);
        }
        std::random_shuffle(shuffledIndices.begin(), shuffledIndices.end());
        qDebug() << "Shuffle ON. Playlist shuffled.";
    } else {
        shuffleButton->setText("Shuffle (Off)");
        shuffledIndices.clear();
        qDebug() << "Shuffle OFF.";
    }
}

void MediaPlayer::toggleRepeat()
{
    repeatMode = (repeatMode + 1) % 3;
    switch (repeatMode) {
    case 0:
        repeatButton->setText("Repeat (Off)");
        qDebug() << "Repeat Off.";
        break;
    case 1:
        repeatButton->setText("Repeat (All)");
        qDebug() << "Repeat All.";
        break;
    case 2:
        repeatButton->setText("Repeat (One)");
        qDebug() << "Repeat One.";
        break;
    }
}

void MediaPlayer::addFilesToPlaylist()
{
    QStringList filePaths = QFileDialog::getOpenFileNames(this, "Add Media Files",
                                                          QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                          "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");

    if (!filePaths.isEmpty()) {
        for (const QString &filePath : filePaths) {
            QUrl url = QUrl::fromLocalFile(filePath);
            playlist.append(url);
            playlistWidget->addItem(QFileInfo(filePath).fileName());
            qDebug() << "Added to playlist: " << QFileInfo(filePath).fileName();
        }

        if (currentIndex == -1 && !playlist.isEmpty()) {
            currentIndex = 0;
            qDebug() << "First song added, playing automatically.";
            playCurrentSong();
        }

        if (isShuffled) {
            toggleShuffle();
            toggleShuffle();
        }
        updateButtonsState(mediaPlayer->playbackState());
    }
}

void MediaPlayer::playSelectedSong(QListWidgetItem *item)
{
    if (!item) return;

    int originalPlaylistIndex = -1;
    QString fileNameToFind = item->text();

    for (int i = 0; i < playlist.size(); ++i) {
        if (QFileInfo(playlist[i].toLocalFile()).fileName() == fileNameToFind) {
            originalPlaylistIndex = i;
            break;
        }
    }

    if (originalPlaylistIndex != -1) {
        if (isShuffled) {
            for (int i = 0; i < shuffledIndices.size(); ++i) {
                if (shuffledIndices[i] == originalPlaylistIndex) {
                    currentIndex = i;
                    break;
                }
            }
        } else {
            currentIndex = originalPlaylistIndex;
        }
        qDebug() << "Playing selected song: " << fileNameToFind;
        playCurrentSong();
    }
}

void MediaPlayer::clearPlaylist()
{
    mediaPlayer->stop();
    playlist.clear();
    shuffledIndices.clear();
    currentIndex = -1;
    playlistWidget->clear();
    updateButtonsState(QMediaPlayer::StoppedState);
    updateTimeLabel(0,0);
    qDebug() << "Playlist cleared.";
}

void MediaPlayer::updatePlaylistWidgetSelection()
{
    playlistWidget->clearSelection();

    if (currentIndex != -1 && !playlist.isEmpty()) {
        int actualSongIndex = currentIndex;
        if (isShuffled && !shuffledIndices.isEmpty() && currentIndex < shuffledIndices.size()) {
            actualSongIndex = shuffledIndices[currentIndex];
        }

        if (actualSongIndex >= 0 && actualSongIndex < playlistWidget->count()) {
            QListWidgetItem *item = playlistWidget->item(actualSongIndex);
            if (item) {
                item->setSelected(true);
                playlistWidget->scrollToItem(item);
                qDebug() << "Playlist widget selection updated to: " << item->text();
            }
        }
    }
}

void MediaPlayer::loadMusicOnStartup()
{
    QString musicLocation = QStandardPaths::writableLocation(QStandardPaths::MusicLocation);
    QDir musicDir(musicLocation);
    qDebug() << "Searching for music in: " << musicLocation;

    QStringList nameFilters;
    nameFilters << "*.mp3" << "*.wav" << "*.ogg" << "*.flac" << "*.mp4" << "*.avi" << "*.mkv" << "*.mpeg";

    QFileInfoList files = musicDir.entryInfoList(nameFilters, QDir::Files | QDir::NoDotAndDotDot);

    if (!files.isEmpty()) {
        qDebug() << "Found " << files.size() << " media files.";
        for (const QFileInfo &fileInfo : files) {
            QUrl url = QUrl::fromLocalFile(fileInfo.absoluteFilePath());
            playlist.append(url);
            playlistWidget->addItem(fileInfo.fileName());
        }

        if (currentIndex == -1 && !playlist.isEmpty()) {
            currentIndex = 0;
            qDebug() << "Loading first song from startup list.";
            // playCurrentSong(); // Do not play automatically on startup, just load.
        }

        if (isShuffled) {
            toggleShuffle();
        }
        updateButtonsState(mediaPlayer->playbackState());
    } else {
        qDebug() << "No media files found in " << musicLocation << " with specified filters.";
    }
    // If you intend to load user-specific playlists here,
    // you would use 'm_loggedUser' and 'm_allUsers' members.
    // Example (conceptual):
    // if (m_loggedUser) {
    //     for (const Playlist& p : m_loggedUser->playlists) {
    //         // Add songs from user's playlists
    //     }
    // }
}
