// song.h
#ifndef SONG_H
#define SONG_H

#include <QString>

class Song {
public:
    QString filePath;   // The only attribute, full path to the audio file

    // Constructor to initialize with file path
    // Default constructor is also handled by making path an optional parameter
    Song(QString path = "") : filePath(path) {}
};

#endif // SONG_H
