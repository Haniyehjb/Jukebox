#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QSlider>
#include <QPushButton>
#include <QListWidget>
#include <QLabel>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsPathItem>
#include <QGraphicsPolygonItem>
#include <QTimer>
#include <QVector>
#include <QTime>
#include <QRandomGenerator>
#include "user.h" // Add this include for the User class

// Forward declarations for Qt classes used as member pointers
// These are included in the .cpp file, but forward declared here for member pointers.
class QVBoxLayout;
class QHBoxLayout;

class MediaPlayer : public QWidget
{
    Q_OBJECT

public:
    // Original constructor (if still needed)
    explicit MediaPlayer(QWidget *parent = nullptr);
    // NEW constructor for login integration, matches the call in login.cpp
    explicit MediaPlayer(User* loggedUser, QVector<User>* allUsers, QWidget *parent = nullptr);

    ~MediaPlayer();

private slots:
    void addFilesToPlaylist();
    void playSelectedSong(QListWidgetItem *item);
    void updatePosition(qint64 position);
    void updateDuration(qint64 duration);
    void updateButtonsState(QMediaPlayer::PlaybackState state);
    void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);
    void playNextSong();     // Declared here
    void playPreviousSong(); // Declared here
    void playCurrentSong();  // Declared here
    void toggleShuffle();
    void toggleRepeat();
    void clearPlaylist();
    void setVolume(int volume);
    void updateEqualizer();
    void toggleVisualizer();
    void updateDefaultVisualizer();
    void updatePlaylistWidgetSelection();
    void loadMusicOnStartup(); // Function to load music on startup
    void openFile(); // Simplified open file - addFilesToPlaylist is generally more useful

private:
    void commonInitialization(); // Helper for common constructor code
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration); // Private helper function

    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;
    QVector<QUrl> playlist;
    int currentIndex;

    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;

    QPushButton *openButton;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QPushButton *stopButton;
    QPushButton *nextButton;
    QPushButton *previousButton;
    QPushButton *shuffleButton;
    QPushButton *repeatButton;
    QPushButton *clearPlaylistButton;
    QPushButton *visualizerButton;

    QListWidget *playlistWidget;

    // Layout pointers - declared as members
    QVBoxLayout *mainLayout;
    QHBoxLayout *controlButtonsLayout;
    QHBoxLayout *modeButtonsLayout;
    QHBoxLayout *volumeLayout;

    bool isShuffled;
    QVector<int> shuffledIndices; // Stores original indices when shuffled
    int repeatMode; // 0: Off, 1: Repeat All, 2: Repeat One

    // Equalizer/Visualizer
    QGraphicsScene *equalizerScene;
    QGraphicsView *equalizerView;
    QVector<QGraphicsRectItem*> rainbowBars;
    QVector<QGraphicsRectItem*> randomBars; // For the second visualizer
    QVector<QGraphicsPathItem*> waveItems; // For wave visualizer
    QVector<float> waveTimers;
    QGraphicsPolygonItem *playSymbolItem; // Play symbol for default visualizer
    QGraphicsPixmapItem *coverArtItem; // For album cover
    QTimer *equalizerTimer;
    QRandomGenerator randomGenerator;

    enum VisualizerMode {
        DEFAULT,
        RAINBOW,
        RANDOM,
        WAVE,
        GRAVITY
    };
    VisualizerMode currentVisualizer;

    // For RANDOM visualizer performance
    int m_randomUpdateCounter = 0;
    const int RANDOM_SKIP_FRAMES = 2; // Update random bars every N frames

    // For WAVE visualizer animation
    float m_waveSpeedMultiplier = 1.0f;

    // For GRAVITY visualizer
    struct GravityBarState {
        float currentHeight;
        float velocity;
        float targetHeight;
        float smoothTarget;
        bool isPopping; // New field for pop effect
    };
    QVector<GravityBarState> gravityBarStates;
    QTime lastGravityRandomizeTime;

    // User Management members, matched with login.cpp and user.h
    User* m_loggedUser;
    QVector<User>* m_allUsers;
};

#endif // MEDIAPLAYER_H
