// usermanager.h
#ifndef USERMANAGER_H
#define USERMANAGER_H

#include "User.h" // Make sure User.h is included
#include <QVector>
#include <QString>
#include <QFile>
#include <QTextStream>

class UserManager {
private:
    QVector<User> users;
    User* loggedInUser = nullptr;
    static UserManager* instance;

    UserManager() {} // Private constructor for Singleton pattern

public:
    static UserManager* getInstance(); // Public static method to get the instance

    void loadFromFile(const QString& path);
    void saveToFile(const QString& path);
    bool userExists(const QString& username);
    QVector<User>& getUsers() { return users; }

    void setLoggedInUser(User* user) { loggedInUser = user; }
    User* getLoggedInUser() { return loggedInUser; }

    void addUser(const User& user) {
        users.append(user);
    }
};

#endif // USERMANAGER_H
