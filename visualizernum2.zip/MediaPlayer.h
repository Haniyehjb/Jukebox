#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <QTimer>
#include <QDateTime>

class MediaPlayer : public QWidget
{
    Q_OBJECT

public:
    explicit MediaPlayer(QWidget *parent = nullptr);
    ~MediaPlayer();

private slots:
    void openFile();
    void setVolume(int volume);
    void updatePosition(qint64 position);
    void updateDuration(qint64 duration);
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration);
    void updateButtonsState();
    void updateEqualizer();

private:
    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;
    QPushButton *openButton;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QPushButton *stopButton;
    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;
    QVBoxLayout *mainLayout;
    
    // Equalizer members
    QGraphicsScene *equalizerScene;
    QGraphicsView *equalizerView;
    QVector<QGraphicsRectItem*> equalizerBars;
    QTimer *equalizerTimer;
};

#endif // MEDIAPLAYER_H