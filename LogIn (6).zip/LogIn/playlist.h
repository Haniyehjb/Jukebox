#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QString>
#include <QVector>

class Playlist {
public:
    QString name;
    QVector<QString> songTitles; // فقط عنوان آهنگ‌ها، چون آهنگ‌ها تکراری نیستن

    Playlist(const QString& name = "") : name(name) {}

    void addSong(const QString& title) {
        if (!songTitles.contains(title))
            songTitles.append(title);
    }
};

#endif // PLAYLIST_H
