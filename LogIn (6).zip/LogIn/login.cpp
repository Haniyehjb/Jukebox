#include "login.h"
#include "mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QCryptographicHash>
#include <QDir>
#include <QTimer>
#include "UserManager.h" // اضافه کن

Login::Login(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(600, 400);

    backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 400);
    backgroundLabel->setPixmap(QPixmap("1.jpg"));
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();
    setWindowTitle("Login");

    auto *layout = new QVBoxLayout(this);

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("Username");

    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("Password");
    passwordEdit->setEchoMode(QLineEdit::Password);

    loginButton = new QPushButton("Login", this);
    messageLabel = new QLabel(this);
    messageLabel->setStyleSheet("color: red;");

    layout->addWidget(usernameEdit);
    layout->addWidget(passwordEdit);
    layout->addWidget(loginButton);
    layout->addWidget(messageLabel);

    connect(loginButton, &QPushButton::clicked, this, &Login::loginUser);

    forgotPasswordBtn = new QPushButton("Forgot Password?", this);
    forgotPasswordBtn->setGeometry(250, 140, 120, 30);
    connect(forgotPasswordBtn, &QPushButton::clicked, this, &Login::showForgotPassword);
}

void Login::loginUser()
{
    QString username = usernameEdit->text().trimmed();
    QString password = passwordEdit->text().trimmed();

    if (username.isEmpty() || password.isEmpty()) {
        messageLabel->setText("Please enter both fields.");
        return;
    }

    QByteArray enteredHash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex();
    QString enteredHashHex = enteredHash;

    QVector<User>& users = UserManager::getInstance()->getUsers();
    bool success = false;

    for (User& user : users) {
        if (user.username == username && user.hashedPassword == enteredHashHex) {
            UserManager::getInstance()->setLoggedInUser(&user);
            success = true;
            break;
        }
    }

    if (success) {
        messageLabel->setStyleSheet("color: green;");
        messageLabel->setText("Login successful!");
        QTimer::singleShot(1500, [this]() {
            MainWindow *mainWin = new MainWindow();
            mainWin->show();
            this->close();
        });
    } else {
        messageLabel->setStyleSheet("color: red;");
        messageLabel->setText("Invalid username or password.");
    }
}


void Login::showForgotPassword()
{
    if (!forgotPasswordWindow) {
        forgotPasswordWindow = new ForgotPassword();
    }
    forgotPasswordWindow->show();
    forgotPasswordWindow->raise();
    forgotPasswordWindow->activateWindow();
}
