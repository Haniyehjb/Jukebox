#include "UserManager.h"
#include <QStringList>

UserManager* UserManager::instance = nullptr;

void UserManager::loadFromFile(const QString& path) {
    users.clear();

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.trimmed().isEmpty()) continue;

        QStringList parts = line.split(' ');
        if (parts.size() < 6) continue;

        User user(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);

        if (parts.size() > 6) {
            int playlistCount = parts[6].toInt();
            int index = 7;
            for (int i = 0; i < playlistCount; ++i) {
                QString playlistName = parts[index++];
                int songCount = parts[index++].toInt();
                Playlist pl(playlistName);
                for (int j = 0; j < songCount; ++j)
                    pl.addSong(parts[index++]);
                user.addPlaylist(pl);
            }
        }

        users.append(user);
    }

    file.close();
}

void UserManager::saveToFile(const QString& path) {
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);

    for (const User& user : users) {
        out << user.username << " "
            << user.hashedPassword << " "
            << user.fullName << " "
            << user.email << " "
            << user.question << " "
            << user.answer << " "
            << user.playlists.size() << " ";

        for (const Playlist& pl : user.playlists) {
            out << pl.name << " " << pl.songTitles.size() << " ";
            for (const QString& s : pl.songTitles)
                out << s << " ";
        }

        out << "\n";
    }

    file.close();
}
