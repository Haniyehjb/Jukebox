#include "networkmanager.h"
#include <QDataStream>
#include <QFile>
#include <QFileInfo>
#include <QDir>

NetworkManager::NetworkManager(Mode mode, QObject *parent)
    : QObject(parent), mode(mode), tcpServer(nullptr), socket(nullptr)
{
}

void NetworkManager::startServer(quint16 port)
{
    tcpServer = new QTcpServer(this);
    connect(tcpServer, &QTcpServer::newConnection, this, &NetworkManager::onNewConnection);
    tcpServer->listen(QHostAddress::Any, port);
}

void NetworkManager::connectToServer(const QString &host, quint16 port)
{
    socket = new QTcpSocket(this);
    connect(socket, &QTcpSocket::readyRead, this, &NetworkManager::onReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &NetworkManager::onDisconnected);
    socket->connectToHost(host, port);
}

void NetworkManager::onNewConnection()
{
    socket = tcpServer->nextPendingConnection();
    connect(socket, &QTcpSocket::readyRead, this, &NetworkManager::onReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &NetworkManager::onDisconnected);
}

void NetworkManager::sendSongNameToClient(const QString &songName)
{
    if (!socket) return;
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out << QString("SONG_NAME") << songName;
    socket->write(block);
    pendingSongName = songName;
}

void NetworkManager::sendSongDataToClient(const QByteArray &data, const QString &songName)
{
    if (!socket) return;
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out << QString("SONG_DATA") << songName << data;
    socket->write(block);
}

void NetworkManager::onReadyRead()
{
    while (socket->bytesAvailable()) {
        QByteArray data = socket->readAll();
        processIncomingData(data);
    }
}

void NetworkManager::processIncomingData(const QByteArray &data)
{
    QDataStream in(data);
    QString header;
    in >> header;

    if (header == "SONG_NAME") {
        QString songName;
        in >> songName;

        QString filePath = "C:/music/" + songName;
        QFileInfo fi(filePath);
        bool exists = fi.exists() && fi.isFile();

        // پاسخ به سرور
        QByteArray reply;
        QDataStream out(&reply, QIODevice::WriteOnly);
        out << QString("HAS_SONG") << exists;
        socket->write(reply);

        if (exists) {
            // اگر آهنگ هست، پخش کن
            QFile file(filePath);
            if (file.open(QIODevice::ReadOnly)) {
                QByteArray data = file.readAll();
                emit receivedSong(data, songName); // پخش بدون ارسال
            }
        }
    }
    else if (header == "HAS_SONG") {
        bool has;
        in >> has;
        emit clientHasSong(has);
    }
    else if (header == "SONG_DATA") {
        QString songName;
        QByteArray fileData;
        in >> songName >> fileData;
        emit receivedSong(fileData, songName);
    }
}

void NetworkManager::onDisconnected()
{
    socket->deleteLater();
    socket = nullptr;
}
