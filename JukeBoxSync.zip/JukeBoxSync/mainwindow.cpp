#include "mainwindow.h"
#include  "ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QInputDialog>
#include <QDir>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , player(new MusicPlayer(this))
{
    ui->setupUi(this);
    setWindowTitle("JukeBox Network");

    // سوال: سرور یا کلاینت؟
    isServer = QMessageBox::question(this, "حالت اجرا",
                                     "آیا می‌خواهید به عنوان سرور اجرا شوید؟",
                                     QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes;

    network = new NetworkManager(isServer ? NetworkManager::Server : NetworkManager::Client, this);

    if (isServer) {
        network->startServer(12345);
        ui->selectSongButton->setEnabled(true);
    } else {
        QString ip = QInputDialog::getText(this, "اتصال", "IP سرور را وارد کنید:", QLineEdit::Normal, "127.0.0.1");
        network->connectToServer(ip, 12345);
        ui->selectSongButton->setEnabled(false);
    }

    setupConnections();
}
void MainWindow::setupConnections()
{
    connect(ui->playButton, &QPushButton::clicked, this, &MainWindow::onPlayClicked);
    connect(ui->pauseButton, &QPushButton::clicked, this, &MainWindow::onPauseClicked);
    connect(ui->seekSlider, &QSlider::sliderMoved, this, &MainWindow::onSeekSliderMoved);
    connect(ui->selectSongButton, &QPushButton::clicked, this, &MainWindow::onSelectSongClicked);

    connect(player, &MusicPlayer::positionChanged, this, &MainWindow::onPositionChanged);
    connect(player, &MusicPlayer::durationChanged, this, &MainWindow::onDurationChanged);

    connect(network, &NetworkManager::receivedSong, this, &MainWindow::handleIncomingSong);
    connect(network, &NetworkManager::clientHasSong, this, &MainWindow::handleHasSongResponse);
}

void MainWindow::onPlayClicked()
{
    player->play();
}

void MainWindow::onPauseClicked()
{
    player->pause();
}

void MainWindow::onSeekSliderMoved(int value)
{
    player->setPosition(value);
}

// void MainWindow::onSelectSongClicked()
// {
//     QString path = QFileDialog::getOpenFileName(this, "انتخاب آهنگ", "C:/music", "Audio Files (*.mp3 *.wav)");
//     if (path.isEmpty()) return;

//     QFileInfo info(path);
//     currentSongName = info.fileName();
//     currentSongPath = path;

//     network->sendSongNameToClient(currentSongName);
//     log("ارسال نام آهنگ: " + currentSongName);
// }
void MainWindow::onSelectSongClicked()
{
    QString path = QFileDialog::getOpenFileName(this, "انتخاب آهنگ", "C:/music", "Audio Files (*.mp3 *.wav)");
    if (path.isEmpty()) return;

    QFileInfo info(path);
    currentSongName = info.fileName();
    currentSongPath = path;

    // 💡 این خط رو اضافه کن:
    player->setSource(currentSongPath);  // بدون این خط، play کار نمی‌کنه

    network->sendSongNameToClient(currentSongName);
    log("ارسال نام آهنگ: " + currentSongName);
}

void MainWindow::handleHasSongResponse(bool hasSong)
{
    if (!hasSong) {
        QFile file(currentSongPath);
        if (!file.open(QIODevice::ReadOnly)) {
            log("خطا در باز کردن فایل.");
            return;
        }
        QByteArray data = file.readAll();
        network->sendSongDataToClient(data, currentSongName);
        log("ارسال آهنگ به کلاینت.");
    }
}

void MainWindow::handleIncomingSong(const QByteArray &data, const QString &name)
{
    QString path = "C:/music/" + name;
    QFile file(path);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(data);
        file.close();
        log("آهنگ دریافت و ذخیره شد.");
    } else {
        log("ذخیره آهنگ ناموفق بود.");
        return;
    }

    currentSongPath = path;
    player->setSource(path);
    player->play();
}

void MainWindow::onPositionChanged(qint64 pos)
{
    ui->seekSlider->setValue(static_cast<int>(pos));
}

void MainWindow::onDurationChanged(qint64 dur)
{
    ui->seekSlider->setMaximum(static_cast<int>(dur));
}

void MainWindow::log(const QString &message)
{
    ui->logBox->append(message);
}

MainWindow::~MainWindow()
{
    delete ui;
}



