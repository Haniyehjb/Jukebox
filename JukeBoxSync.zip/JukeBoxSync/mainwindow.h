#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "networkmanager.h"
#include "musicplayer.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onPlayClicked();
    void onPauseClicked();
    void onSeekSliderMoved(int value);
    void onSelectSongClicked();

    void handleIncomingSong(const QByteArray &data, const QString &songName);
    void handleHasSongResponse(bool hasSong);
    void onPositionChanged(qint64 pos);
    void onDurationChanged(qint64 dur);

    void on_playButton_clicked();

    void on_selectSongButton_clicked();

private:
    Ui::MainWindow *ui;
    NetworkManager *network;
    MusicPlayer *player;

    QString currentSongPath;
    QString currentSongName;
    bool isServer;

    void setupConnections();
    void log(const QString &message);
};

#endif // MAINWINDOW_H
