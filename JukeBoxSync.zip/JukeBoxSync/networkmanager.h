#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

class NetworkManager : public QObject
{
    Q_OBJECT

public:
    enum Mode { Server, Client };

    explicit NetworkManager(Mode mode, QObject *parent = nullptr);

    void startServer(quint16 port);
    void connectToServer(const QString &host, quint16 port);

    void sendSongNameToClient(const QString &songName);
    void sendSongDataToClient(const QByteArray &data, const QString &songName);

signals:
    void clientHasSong(bool hasSong);
    void receivedSong(const QByteArray &data, const QString &name);

private slots:
    void onNewConnection();
    void onReadyRead();
    void onDisconnected();

private:
    Mode mode;
    QTcpServer *tcpServer;
    QTcpSocket *socket;

    QString pendingSongName;

    void processIncomingData(const QByteArray &data);
};

#endif // NETWORKMANAGER_H
