#include "musicplayer.h"

MusicPlayer::MusicPlayer(QObject *parent)
    : QObject(parent)
{
    audio = new QAudioOutput(this);
    player = new QMediaPlayer(this);
    player->setAudioOutput(audio);

    connect(player, &QMediaPlayer::positionChanged, this, &MusicPlayer::positionChanged);
    connect(player, &QMediaPlayer::durationChanged, this, &MusicPlayer::durationChanged);
}

void MusicPlayer::setSource(const QString &filePath)
{
    player->setSource(QUrl::fromLocalFile(filePath));
}

void MusicPlayer::play()
{
    player->play();
}

void MusicPlayer::pause()
{
    player->pause();
}

void MusicPlayer::setPosition(qint64 pos)
{
    player->setPosition(pos);
}
