#ifndef MUSICPLAYER_H
#define MUSICPLAYER_H

#include <QObject>
#include <QMediaPlayer>
#include <QAudioOutput>

class MusicPlayer : public QObject
{
    Q_OBJECT

public:
    explicit MusicPlayer(QObject *parent = nullptr);

    void setSource(const QString &filePath);
    void play();
    void pause();
    void setPosition(qint64 pos);

signals:
    void positionChanged(qint64 pos);
    void durationChanged(qint64 dur);

private:
    QMediaPlayer *player;
    QAudioOutput *audio;
};

#endif // MUSICPLAYER_H
