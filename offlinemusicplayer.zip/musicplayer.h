#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget> 
#include <QMediaPlayer> 
#include <QAudioOutput> 
// #include <QVideoWidget> 
#include <QPushButton>
#include <QSlider> 
#include <QLabel> 
#include <QVBoxLayout> 

class MediaPlayer : public QWidget
{
    Q_OBJECT 

public:
    
    explicit MediaPlayer(QWidget *parent = nullptr);
    ~MediaPlayer();

private slots:
    void openFile(); 
    void setVolume(int volume); 
    void updatePosition(qint64 position); 
    void updateDuration(qint64 duration); 
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration); 
    void updateButtonsState(QMediaPlayer::PlaybackState state); 

private:
 
    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;
    //QVideoWidget *videoWidget;
    QPushButton *openButton;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QPushButton *stopButton;
    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;
    QVBoxLayout *mainLayout;
};

#endif 
