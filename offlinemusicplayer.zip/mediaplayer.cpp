#include "MediaPlayer.h"
#include <QFileDialog>
#include <QUrl>
#include <QDebug>


MediaPlayer::MediaPlayer(QWidget *parent) : QWidget(parent)
{

    mediaPlayer = new QMediaPlayer(this); 
    audioOutput = new QAudioOutput(this);
    mediaPlayer->setAudioOutput(audioOutput); 
    audioOutput->setVolume(0.5); 

  
    openButton = new QPushButton("Open File", this);
    playButton = new QPushButton("Play", this);
    pauseButton = new QPushButton("Pause", this);
    stopButton = new QPushButton("Stop", this);
    positionSlider = new QSlider(Qt::Horizontal, this); 
    volumeSlider = new QSlider(Qt::Horizontal, this); 
    timeLabel = new QLabel("00:00 / 00:00", this); 

    volumeSlider->setRange(0, 100); 
    volumeSlider->setValue(50); 
    positionSlider->setRange(0, 0); 

  
    QVBoxLayout *controlLayout = new QVBoxLayout(); 
    controlLayout->addWidget(openButton);
    controlLayout->addWidget(playButton);
    controlLayout->addWidget(pauseButton);
    controlLayout->addWidget(stopButton);
    controlLayout->addWidget(new QLabel("Volume:", this));
    controlLayout->addWidget(volumeSlider);
    controlLayout->addWidget(new QLabel("Position:", this));
    controlLayout->addWidget(positionSlider);
    controlLayout->addWidget(timeLabel);

    mainLayout = new QVBoxLayout(this); 
    mainLayout->addLayout(controlLayout); 
    setLayout(mainLayout); 

 
    connect(openButton, &QPushButton::clicked, this, &MediaPlayer::openFile);
    connect(playButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::play);
    connect(pauseButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::pause);
    connect(stopButton, &QPushButton::clicked, mediaPlayer, &QMediaPlayer::stop);
    connect(volumeSlider, &QSlider::valueChanged, this, &MediaPlayer::setVolume);
    connect(positionSlider, &QSlider::sliderMoved, mediaPlayer, &QMediaPlayer::setPosition);
    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::updatePosition);
    connect(mediaPlayer, &QMediaPlayer::durationChanged, this, &MediaPlayer::updateDuration);
    connect(mediaPlayer, &QMediaPlayer::playbackStateChanged, this, &MediaPlayer::updateButtonsState);
    updateButtonsState(mediaPlayer->playbackState());
}
MediaPlayer::~MediaPlayer(){}

void MediaPlayer::openFile()
{
    QString fileName = QFileDialog::getOpenFileName(this,tr("Open Media"), "", tr("Media Files (*.mp3 *.mp4 *.avi *.wav);;All Files (*.*)")); // فیلتر فایل

    if (!fileName.isEmpty()) { 
        mediaPlayer->setSource(QUrl::fromLocalFile(fileName)); 
        mediaPlayer->play();}
}
void MediaPlayer::setVolume(int volume)
{audioOutput->setVolume(static_cast<qreal>(volume) / 100.0);}

void MediaPlayer::updatePosition(qint64 position){
    positionSlider->setValue(static_cast<int>(position));
    updateTimeLabel(position, mediaPlayer->duration());
}


void MediaPlayer::updateDuration(qint64 duration){
    positionSlider->setRange(0, static_cast<int>(duration));
    updateTimeLabel(mediaPlayer->position(), duration);
}


void MediaPlayer::updateTimeLabel(qint64 currentPos, qint64 totalDuration){
    qint64 currentMinutes = (currentPos / 1000) / 60;
    qint64 currentSeconds = (currentPos / 1000) % 60;
    qint64 totalMinutes = (totalDuration / 1000) / 60;
    qint64 totalSeconds = (totalDuration / 1000) % 60;

    timeLabel->setText(QString("%1:%2 / %3:%4").arg(currentMinutes, 2, 10, QChar('0')).arg(currentSeconds, 2, 10, QChar('0')).arg(totalMinutes, 2, 10, QChar('0')).arg(totalSeconds, 2, 10, QChar('0')));
}


void MediaPlayer::updateButtonsState(QMediaPlayer::PlaybackState state){
    openButton->setEnabled(true);
    if (state == QMediaPlayer::PlayingState) {
        
        playButton->setEnabled(false); 
        pauseButton->setEnabled(true);  
        stopButton->setEnabled(true);   
    }
    else if (state == QMediaPlayer::PausedState) {
        
        playButton->setEnabled(true);   
        pauseButton->setEnabled(false); 
        stopButton->setEnabled(true);   
    }
    else if (state == QMediaPlayer::StoppedState) {
        
        playButton->setEnabled(true);  
        pauseButton->setEnabled(false); 
        stopButton->setEnabled(false);  
    } 
    else { 
        
        playButton->setEnabled(false);
        pauseButton->setEnabled(false);
        stopButton->setEnabled(false);
    }
}
