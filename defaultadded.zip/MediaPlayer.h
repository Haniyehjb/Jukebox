#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <QTimer>
#include <QDateTime>
#include <QHBoxLayout>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QFileDialog>
#include <QStandardPaths>
#include <QRandomGenerator>
#include <QVector>
#include <QUrl>
#include <QMediaMetaData>

enum VisualizerMode {
    DEFAULT,
    RAINBOW,
    RANDOM,
    WAVE
};

class MediaPlayer : public QWidget
{
    Q_OBJECT

public:
    explicit MediaPlayer(QWidget *parent = nullptr);
    ~MediaPlayer();

private slots:
    void openFile();
    void setVolume(int volume);
    void updatePosition(qint64 position);
    void updateDuration(qint64 duration);
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration);
    void updateButtonsState(QMediaPlayer::PlaybackState state);
    void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);
    void updateEqualizer();
    void playNextSong();
    void playPreviousSong();
    void toggleShuffle();
    void toggleRepeat();
    void addFilesToPlaylist();
    void playSelectedSong(QListWidgetItem *item);
    void clearPlaylist();


private:
    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;
    QVector<QUrl> playlist;
    int currentIndex;
    QVector<int> shuffledIndices;
    bool isShuffled;
    QPushButton *openButton;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QPushButton *stopButton;
    QPushButton *nextButton;
    QPushButton *previousButton;
    QPushButton *shuffleButton;
    QPushButton *repeatButton;
    QPushButton *clearPlaylistButton;
    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;
    QListWidget *playlistWidget;
    QVBoxLayout *mainLayout;

    // Equalizer members
    QGraphicsScene *equalizerScene;
    QGraphicsView *equalizerView;
    QList<QGraphicsRectItem*> rainbowBars;
    QList<QGraphicsRectItem*> randomBars;
    QList<QGraphicsLineItem*> waveLines;
    QList<QPainterPath> wavePaths;
    QList<QGraphicsPathItem*> waveItems;
    QList<float> waveTimers; // Individual wave timers
    float m_waveSpeedMultiplier = 1.0f;
    QRandomGenerator randomGenerator;
    QGraphicsPixmapItem* coverArtItem;
    QGraphicsPolygonItem* playSymbolItem;
    void updateDefaultVisualizer();
    QVector<QGraphicsRectItem*> equalizerBars;
    QTimer *equalizerTimer;

    int repeatMode; // 0: No Repeat, 1: Repeat All, 2: Repeat One

    void playCurrentSong();
    void updatePlaylistWidgetSelection();
    void toggleVisualizer();

    VisualizerMode currentVisualizer;
    QPushButton* visualizerButton;
};

#endif // MEDIAPLAYER_H
