#ifndef SONG_H
#define SONG_H

#include <QString>

class Song {
public:
    QString title;
    QString artist;

    Song(QString title = "", QString artist = "") : title(title), artist(artist) {}
};

#endif // SONG_H
