#ifndef USERMANAGER_H
#define USERMANAGER_H

#include "User.h"
#include <QVector>
#include <QString>
#include <QFile>
#include <QTextStream>

class UserManager {
private:
    QVector<User> users;
    User* loggedInUser = nullptr;
    static UserManager* instance;

    UserManager() {}

public:
    static UserManager* getInstance() {
        if (!instance)
            instance = new UserManager;
        return instance;
    }

    void loadFromFile(const QString& path);
    void saveToFile(const QString& path);

    QVector<User>& getUsers() { return users; }

    void setLoggedInUser(User* user) { loggedInUser = user; }
    User* getLoggedInUser() { return loggedInUser; }

    void addUser(const User& user) {
        users.append(user);
    }
};

#endif // USERMANAGER_H
