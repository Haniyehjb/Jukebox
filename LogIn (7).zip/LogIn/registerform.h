#ifndef REGISTERFORM_H
#define REGISTERFORM_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QComboBox>

class RegisterForm : public QWidget
{
    Q_OBJECT
public:
    explicit RegisterForm(QWidget *parent = nullptr);

private slots:
    void registerUser();

private:
    QLabel *backgroundLabel;
    QLineEdit *usernameEdit;
    QLineEdit *passwordEdit;
    QLineEdit *firstNameEdit;
    QLineEdit *lastNameEdit;
    QLineEdit *emailEdit;
    QComboBox *securityQuestionCombo;
    QLineEdit *securityAnswerEdit;

    QPushButton *registerButton;
    QLabel *messageLabel;
};

#endif // REGISTERFORM_H
