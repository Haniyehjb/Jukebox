#include "mediaplayer.h"
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QRandomGenerator> // For std::shuffle with modern C++
#include <QDir>
#include <algorithm>        // Required for std::shuffle
#include <QIcon>            // Needed for QIcon
#include <QStyle>           // For getting standard pixmaps if needed, though custom icons are preferred
#include <QFileInfo>        // For QFileInfo::fileName()



MediaPlayer::MediaPlayer(User* user, QVector<User>* allUsers, QWidget *parent)
    : QWidget(parent), currentUser(user), users(allUsers),
    mediaPlayer(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentIndex(-1),
    isShuffled(false),
    repeatMode(0) // 0: No Repeat
{
    setWindowTitle("Media Player - " + user->username); // مثلا عنوان رو شخصی‌سازی کن
    mediaPlayer->setAudioOutput(audioOutput);
    audioOutput->setVolume(0.5); // Set initial volume (0.0 to 1.0)

    // --- Main Widget Styling (Dark Background) ---
    this->setStyleSheet("background-color: #1A1A1A; color: #E0E0E0; font-family: Segoe UI, sans-serif; font-size: 14px;");

    // --- Control Buttons ---
    // Make sure these object names are unique if you target them with specific CSS
    playButton = new QToolButton(this);
    playButton->setIcon(QIcon(":/icons/play.png"));
    playButton->setIconSize(QSize(48, 48)); // Icon size
    playButton->setFixedSize(80, 80);      // Button fixed size (makes it circular with radius)
    playButton->setToolTip("Play");
    playButton->setObjectName("playButton"); // Object name for specific styling

    pauseButton = new QToolButton(this);
    pauseButton->setIcon(QIcon(":/icons/pause.png"));
    pauseButton->setIconSize(QSize(36, 36));
    pauseButton->setFixedSize(60, 60);
    pauseButton->setToolTip("Pause");

    stopButton = new QToolButton(this);
    stopButton->setIcon(QIcon(":/icons/stop.png"));
    stopButton->setIconSize(QSize(36, 36));
    stopButton->setFixedSize(60, 60);
    stopButton->setToolTip("Stop");

    nextButton = new QToolButton(this);
    nextButton->setIcon(QIcon(":/icons/next.png"));
    nextButton->setIconSize(QSize(36, 36));
    nextButton->setFixedSize(60, 60);
    nextButton->setToolTip("Next Song");

    previousButton = new QToolButton(this);
    previousButton->setIcon(QIcon(":/icons/previous.png"));
    previousButton->setIconSize(QSize(36, 36));
    previousButton->setFixedSize(60, 60);
    previousButton->setToolTip("Previous Song");

    // --- Mode Buttons ---
    shuffleButton = new QToolButton(this);
    shuffleButton->setIcon(QIcon(":/icons/shuffle_off.png")); // Initial state
    shuffleButton->setIconSize(QSize(24, 24));
    shuffleButton->setFixedSize(36, 36);
    shuffleButton->setToolTip("Toggle Shuffle");

    repeatButton = new QToolButton(this);
    repeatButton->setIcon(QIcon(":/icons/repeat_off.png")); // Initial state
    repeatButton->setIconSize(QSize(24, 24));
    repeatButton->setFixedSize(36, 36);
    repeatButton->setToolTip("Toggle Repeat Mode");

    clearPlaylistButton = new QToolButton(this);
    clearPlaylistButton->setIcon(QIcon(":/icons/clear_playlist.png"));
    clearPlaylistButton->setIconSize(QSize(24, 24));
    clearPlaylistButton->setFixedSize(36, 36);
    clearPlaylistButton->setToolTip("Clear Playlist");

    loadAllMusicButton = new QToolButton(this);
    loadAllMusicButton->setIcon(QIcon(":/icons/add_music.png")); // An icon for loading all music
    loadAllMusicButton->setIconSize(QSize(24, 24));
    loadAllMusicButton->setFixedSize(36, 36);
    loadAllMusicButton->setToolTip("Load All Music");

    // --- Top-Left/Right Buttons (from image) ---
    likeButton = new QToolButton(this);
    likeButton->setIcon(QIcon(":/icons/like.png")); // Assuming this icon
    likeButton->setIconSize(QSize(24, 24));
    likeButton->setFixedSize(36, 36);
    likeButton->setToolTip("Like Song");
    likeButton->setObjectName("likeButton"); // For specific styling (red heart)

    optionsButton = new QToolButton(this);
    optionsButton->setIcon(QIcon(":/icons/options.png")); // Assuming a menu/options icon
    optionsButton->setIconSize(QSize(24, 24));
    optionsButton->setFixedSize(36, 36);
    optionsButton->setToolTip("Options");

    addToPlaylistButton = new QToolButton(this);
    addToPlaylistButton->setIcon(QIcon(":/icons/add_to_playlist.png")); // Assuming a plus icon
    addToPlaylistButton->setIconSize(QSize(24, 24));
    addToPlaylistButton->setFixedSize(36, 36);
    addToPlaylistButton->setToolTip("Add to Playlist");


    // --- Sliders and Labels ---
    positionSlider = new QSlider(Qt::Horizontal, this);
    positionSlider->setRange(0, 0); // Will be set by durationChanged
    positionSlider->setTracking(true); // Update position while dragging
    positionSlider->setToolTip("Seek Position");

    volumeSlider = new QSlider(Qt::Horizontal, this);
    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(static_cast<int>(audioOutput->volume() * 100)); // Initialize slider with current volume
    volumeSlider->setToolTip("Volume");

    timeLabel = new QLabel("00:00 / 00:00", this);
    timeLabel->setAlignment(Qt::AlignCenter); // Center the time text

    playlistWidget = new QListWidget(this);
    playlistWidget->setAlternatingRowColors(true); // Optional: for visual separation of rows
    playlistWidget->setToolTip("Double-click to play");


    // --- Global Style for QToolButton (common for most buttons) ---
    // Apply this to all QToolButtons first, then override specific ones.
    this->setStyleSheet(this->styleSheet() +
                        "QToolButton {"
                        "   border: none;"
                        "   background-color: transparent;"
                        "   color: #E0E0E0;" // Default text color for tooltips/etc if any
                        "   padding: 5px;" // Some padding around icon
                        "}"
                        "QToolButton:hover {"
                        "   background-color: #333333;" // Darker on hover
                        "   border-radius: 5px;" // Slightly rounded hover effect
                        "}"
                        "QToolButton:pressed {"
                        "   background-color: #555555;" // Even darker on press
                        "}"
                        "QToolButton:disabled {"
                        "   opacity: 0.5;" // Slightly transparent when disabled
                        "}"
                        );

    // --- Specific Styling for the main play button ---
    playButton->setStyleSheet(
        "QToolButton#playButton {" // Target by object name
        "   border: 4px solid;"
        "   border-radius: 40px;" // Half of its fixed size (80/2) for perfect circle
        "   background-color: transparent;"
        "   border-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #FF0000, stop:1 #FF6600);" // Red-orange gradient border
        "}"
        "QToolButton#playButton:hover {"
        "   background-color: #333333;"
        "}"
        "QToolButton#playButton:pressed {"
        "   background-color: #555555;"
        "}"
        "QToolButton#playButton:disabled {"
        "   opacity: 0.5;"
        "   border-color: #888888;" // Grey border when disabled
        "}"
        );

    // --- Specific Styling for the like button (red heart) ---
    likeButton->setStyleSheet(
        "QToolButton#likeButton {"
        "   border: none;"
        "   background-color: transparent;"
        "}"
        "QToolButton#likeButton:hover {"
        "   background-color: #333333;"
        "   border-radius: 5px;"
        "}"
        "QToolButton#likeButton:pressed {"
        "   background-color: #555555;"
        "}"
        "QToolButton#likeButton:disabled {"
        "   opacity: 0.5;"
        "}"
        );

    // --- Slider Styling ---
    positionSlider->setStyleSheet(
        "QSlider::groove:horizontal {"
        "   height: 8px;"
        "   background: #555555;" // Darker background for the groove
        "   margin: 2px 0;"
        "   border-radius: 4px;"
        "}"
        "QSlider::handle:horizontal {"
        "   background: #FF0000;" // Red handle
        "   border: 1px solid #FF0000;"
        "   width: 18px;"
        "   height: 18px;"
        "   margin: -5px 0;" // Center the handle vertically
        "   border-radius: 9px;" // Make it round
        "}"
        "QSlider::add-page:horizontal {"
        "   background: #888888;" // Color for the part after the handle (lighter grey)
        "   border-radius: 4px;"
        "}"
        "QSlider::sub-page:horizontal {"
        "   background: #FF0000;" // Red for the filled part (before the handle)
        "   border-radius: 4px;"
        "}"
        );

    volumeSlider->setStyleSheet(
        "QSlider::groove:horizontal {"
        "   height: 6px;"
        "   background: #555555;"
        "   margin: 2px 0;"
        "   border-radius: 3px;"
        "}"
        "QSlider::handle:horizontal {"
        "   background: #FFFFFF;" // White handle
        "   border: 1px solid #FFFFFF;"
        "   width: 14px;"
        "   height: 14px;"
        "   margin: -4px 0;"
        "   border-radius: 7px;"
        "}"
        "QSlider::add-page:horizontal {"
        "   background: #888888;"
        "   border-radius: 3px;"
        "}"
        "QSlider::sub-page:horizontal {"
        "   background: #007BFF;" // A blue color for volume fill
        "   border-radius: 3px;"
        "}"
        );

    // --- Label Styling ---
    timeLabel->setStyleSheet("color: #AAAAAA; font-size: 14px;"); // Light grey text

    // --- Playlist Widget Styling ---
    playlistWidget->setStyleSheet(
        "QListWidget {"
        "   background-color: #282828;" // Darker background for playlist
        "   color: #E0E0E0;" // Light text color
        "   border: 1px solid #444444;"
        "   selection-background-color: #007BFF;" // Blue for selected item (consistent with volume)
        "   selection-color: #FFFFFF;" // White text on selection
        "   outline: none; /* Remove dotted outline on focus */"
        "   border-radius: 5px;"
        "}"
        "QListWidget::item {"
        "   padding: 5px;"
        "   margin: 2px 0;"
        "   border-bottom: 1px solid #3A3A3A;" // Subtle separator between items
        "}"
        "QListWidget::item:alternate {"
        "   background-color: #2A2A2A;" // Slightly different background for alternating rows
        "}"
        "QListWidget::item:hover {"
        "   background-color: #383838;" // Hover effect for items
        "}"
        );


    // --- Connections ---
    connect(playButton, &QToolButton::clicked, mediaPlayer, &QMediaPlayer::play);
    connect(pauseButton, &QToolButton::clicked, mediaPlayer, &QMediaPlayer::pause);
    connect(stopButton, &QToolButton::clicked, mediaPlayer, &QMediaPlayer::stop);

    connect(nextButton, &QToolButton::clicked, this, &MediaPlayer::playNextSong);
    connect(previousButton, &QToolButton::clicked, this, &MediaPlayer::playPreviousSong);
    connect(shuffleButton, &QToolButton::clicked, this, &MediaPlayer::toggleShuffle);
    connect(repeatButton, &QToolButton::clicked, this, &MediaPlayer::toggleRepeat);
    connect(clearPlaylistButton, &QToolButton::clicked, this, &MediaPlayer::clearPlaylist);
    connect(loadAllMusicButton, &QToolButton::clicked, this, &MediaPlayer::loadAllMusicAutomatically);

    connect(likeButton, &QToolButton::clicked, this, &MediaPlayer::onLikeButtonClicked);
    connect(optionsButton, &QToolButton::clicked, this, &MediaPlayer::onOptionsButtonClicked);
    connect(addToPlaylistButton, &QToolButton::clicked, this, &MediaPlayer::onAddToPlaylistButtonClicked);

    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::updatePosition);
    connect(mediaPlayer, &QMediaPlayer::durationChanged, this, &MediaPlayer::updateDuration);
    connect(positionSlider, &QSlider::sliderMoved, mediaPlayer, &QMediaPlayer::setPosition);
    connect(volumeSlider, &QSlider::valueChanged, this, &MediaPlayer::setVolume);

    connect(mediaPlayer, &QMediaPlayer::playbackStateChanged, this, &MediaPlayer::updateButtonsState);
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, &MediaPlayer::handleMediaStatusChanged);

    connect(playlistWidget, &QListWidget::itemDoubleClicked, this, &MediaPlayer::playSelectedSong);

    // --- Layout ---
    mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(20, 20, 20, 20); // Add some margin around the whole player
    mainLayout->setSpacing(15); // Space between widgets/layouts

    // Top Row: Like, Options, Add to Playlist
    QHBoxLayout *topRowButtonsLayout = new QHBoxLayout();
    topRowButtonsLayout->addWidget(likeButton);
    topRowButtonsLayout->addStretch(); // Pushes Like button to left, others to right
    topRowButtonsLayout->addWidget(optionsButton);
    topRowButtonsLayout->addWidget(addToPlaylistButton);
    mainLayout->addLayout(topRowButtonsLayout);


    // Main Playback Controls
    QHBoxLayout *controlButtonsLayout = new QHBoxLayout();
    controlButtonsLayout->addStretch(); // Push all to center
    controlButtonsLayout->addWidget(previousButton);
    controlButtonsLayout->addWidget(playButton); // This is the large central button
    controlButtonsLayout->addWidget(pauseButton);
    controlButtonsLayout->addWidget(nextButton);
    controlButtonsLayout->addWidget(stopButton); // Assuming stop button is on the right
    controlButtonsLayout->addStretch();
    mainLayout->addLayout(controlButtonsLayout);

    // Sliders and Time Label
    mainLayout->addWidget(positionSlider);
    mainLayout->addWidget(timeLabel);

    QHBoxLayout *volumeLayout = new QHBoxLayout();
    volumeLayout->addWidget(new QLabel("Volume:", this));
    volumeLayout->addWidget(volumeSlider);
    mainLayout->addLayout(volumeLayout);

    // Mode Buttons and Load/Clear
    QHBoxLayout *modeButtonsLayout = new QHBoxLayout();
    modeButtonsLayout->addStretch(); // Push all to center
    modeButtonsLayout->addWidget(shuffleButton);
    modeButtonsLayout->addWidget(repeatButton);
    modeButtonsLayout->addSpacing(20); // More space between mode buttons and playlist controls
    modeButtonsLayout->addWidget(loadAllMusicButton);
    modeButtonsLayout->addWidget(clearPlaylistButton);
    modeButtonsLayout->addStretch();
    mainLayout->addLayout(modeButtonsLayout);

    mainLayout->addWidget(playlistWidget);

    setLayout(mainLayout);

    updateButtonsState(QMediaPlayer::StoppedState);
}

MediaPlayer::~MediaPlayer()
{
    // Destructor (no changes needed here related to the request)
}

void MediaPlayer::loadAllMusicAutomatically()
{
    QString musicLocation = QStandardPaths::writableLocation(QStandardPaths::MusicLocation);
    QDir musicDir(musicLocation);

    if (!musicDir.exists()) {
        QMessageBox::warning(this, "Error", "Music directory not found: " + musicLocation);
        return;
    }

    QStringList nameFilters;
    nameFilters << "*.mp3" << "*.wav" << "*.ogg" << "*.flac" << "*.m4a" << "*.wma"
                << "*.mp4" << "*.avi" << "*.mkv" << "*.mov";

    QStringList fileNames = musicDir.entryList(nameFilters, QDir::Files | QDir::NoDotAndDotDot);

    if (fileNames.isEmpty()) {
        QMessageBox::information(this, "Info", "No supported media files found in: " + musicLocation);
        return;
    }

    clearPlaylist(); // Clear current playlist before adding new files

    for (const QString &fileName : fileNames) {
        QString fullPath = musicLocation + QDir::separator() + fileName;
        QUrl url = QUrl::fromLocalFile(fullPath);
        playlist.append(url);
        playlistWidget->addItem(QFileInfo(fullPath).fileName());
    }

    if (!playlist.isEmpty()) {
        currentIndex = 0;
        playCurrentSong();
    }

    if (isShuffled) {
        toggleShuffle(); // Re-shuffle to apply to new playlist
        toggleShuffle();
    }
    updateButtonsState(mediaPlayer->playbackState());
    qDebug() << "Automatically loaded all supported music from: " << musicLocation;
}

void MediaPlayer::setVolume(int volume)
{
    audioOutput->setVolume(volume / 100.0); // QAudioOutput volume expects a value from 0.0 to 1.0
}

void MediaPlayer::updatePosition(qint64 position)
{
    positionSlider->setValue(static_cast<int>(position));
    updateTimeLabel(position, mediaPlayer->duration());
}

void MediaPlayer::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, static_cast<int>(duration));
    updateTimeLabel(mediaPlayer->position(), duration);
}

void MediaPlayer::updateTimeLabel(qint64 currentPos, qint64 totalDuration)
{
    qint64 currentSeconds = currentPos / 1000;
    qint64 totalSeconds = totalDuration / 1000;

    int currentMinutes = static_cast<int>(currentSeconds / 60);
    int currentSecs = static_cast<int>(currentSeconds % 60);
    int totalMinutes = static_cast<int>(totalSeconds / 60);
    int totalSecs = static_cast<int>(totalSeconds % 60);

    timeLabel->setText(QString("%1:%2 / %3:%4")
                           .arg(currentMinutes, 2, 10, QChar('0'))
                           .arg(currentSecs, 2, 10, QChar('0'))
                           .arg(totalMinutes, 2, 10, QChar('0'))
                           .arg(totalSecs, 2, 10, QChar('0')));
}

void MediaPlayer::updateButtonsState(QMediaPlayer::PlaybackState state)
{
    bool hasPlaylist = !playlist.isEmpty();

    playButton->setEnabled(state != QMediaPlayer::PlayingState && hasPlaylist);
    pauseButton->setEnabled(state == QMediaPlayer::PlayingState);
    stopButton->setEnabled(state != QMediaPlayer::StoppedState && hasPlaylist);

    nextButton->setEnabled(hasPlaylist);
    previousButton->setEnabled(hasPlaylist);
    shuffleButton->setEnabled(hasPlaylist);
    repeatButton->setEnabled(hasPlaylist);
    clearPlaylistButton->setEnabled(hasPlaylist);

    positionSlider->setEnabled(hasPlaylist);
    volumeSlider->setEnabled(true); // Volume slider should always be enabled

    loadAllMusicButton->setEnabled(true); // Always enabled
    likeButton->setEnabled(hasPlaylist);
    optionsButton->setEnabled(true); // Options might be generally available
    addToPlaylistButton->setEnabled(true); // Can add even if playlist is empty
}

void MediaPlayer::handleMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        qDebug() << "End of media reached. Playing next song.";
        playNextSong();
    } else if (status == QMediaPlayer::InvalidMedia) {
        qDebug() << "Invalid media source.";
        QMessageBox::warning(this, "Error", "Could not play media. Invalid format or corrupted file.");
        playNextSong(); // Try to play the next song if current one is invalid
    }
}

void MediaPlayer::playCurrentSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        qDebug() << "Playlist is empty. Cannot play song.";
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        updateButtonsState(QMediaPlayer::StoppedState);
        return;
    }

    if (currentIndex < 0 || currentIndex >= (isShuffled ? shuffledIndices.size() : playlist.size())) {
        qDebug() << "Current index out of bounds or invalid for current mode. Resetting to 0.";
        currentIndex = 0;
    }

    QUrl currentSource;
    int actualPlaylistIndex = currentIndex; // This will be the index in the original `playlist` vector

    if (isShuffled && !shuffledIndices.isEmpty()) {
        actualPlaylistIndex = shuffledIndices[currentIndex];
        currentSource = playlist[actualPlaylistIndex];
    } else {
        currentSource = playlist[actualPlaylistIndex];
    }

    mediaPlayer->setSource(currentSource);
    mediaPlayer->play();
    qDebug() << "Playing: " << currentSource.toLocalFile() << " (Playlist Index: " << actualPlaylistIndex << ", Current View Index: " << currentIndex << ")";
    updatePlaylistWidgetSelection();
    updateButtonsState(mediaPlayer->playbackState());
}

void MediaPlayer::playNextSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        updateButtonsState(QMediaPlayer::StoppedState);
        return;
    }

    int nextIndex = currentIndex;

    if (repeatMode == 2) { // Repeat One
        qDebug() << "Repeat One: Replaying current song.";
        // currentIndex remains the same
    } else {
        nextIndex++;
        int playlistSize = isShuffled ? shuffledIndices.size() : playlist.size();

        if (nextIndex >= playlistSize) {
            if (repeatMode == 1) { // Repeat All
                nextIndex = 0; // Wrap around to the beginning
                qDebug() << "Repeat All: Wrapping around to first song.";
            } else { // No Repeat
                mediaPlayer->stop();
                currentIndex = -1; // Indicate no song is currently selected
                updatePlaylistWidgetSelection();
                updateButtonsState(QMediaPlayer::StoppedState);
                qDebug() << "No Repeat: End of playlist reached.";
                return; // Stop and exit
            }
        }
    }
    currentIndex = nextIndex;
    playCurrentSong();
}

void MediaPlayer::playPreviousSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        updateButtonsState(QMediaPlayer::StoppedState);
        return;
    }

    if (repeatMode == 2) { // Repeat One (same as next, just replay current)
        qDebug() << "Repeat One: Replaying current song.";
        playCurrentSong();
        return;
    }

    int prevIndex = currentIndex;
    prevIndex--;

    if (prevIndex < 0) {
        if (repeatMode == 1) { // Repeat All
            prevIndex = (isShuffled ? shuffledIndices.size() : playlist.size()) - 1; // Wrap around to the end
            qDebug() << "Repeat All: Wrapping around to last song.";
        } else { // No Repeat
            // If already at the first song and no repeat, just stay on the first song
            prevIndex = 0; // Remain on the first song
            qDebug() << "Previous: Already at the first song (No Repeat).";
            // Do not stop, just re-play the first song if it was playing, or just highlight it
            if (mediaPlayer->playbackState() == QMediaPlayer::PlayingState) {
                // If it's playing, continue playing the first song
                currentIndex = prevIndex;
                playCurrentSong();
            } else {
                // If stopped, just highlight the first song
                currentIndex = prevIndex;
                updatePlaylistWidgetSelection();
                updateButtonsState(mediaPlayer->playbackState()); // Ensure buttons are updated
            }
            return;
        }
    }
    currentIndex = prevIndex;
    playCurrentSong();
}

void MediaPlayer::toggleShuffle()
{
    isShuffled = !isShuffled;
    if (isShuffled) {
        shuffleButton->setIcon(QIcon(":/icons/shuffle_on.png"));
        shuffledIndices.clear();
        for (int i = 0; i < playlist.size(); ++i) {
            shuffledIndices.append(i);
        }
        std::random_device rd;
        std::mt19937 g(rd());
        std::shuffle(shuffledIndices.begin(), shuffledIndices.end(), g);

        if (currentIndex != -1 && !playlist.isEmpty()) {
            int currentActualIndex = shuffledIndices.at(currentIndex); // Get actual index of currently playing song
            // Find the new position of this song in the newly shuffled list
            for (int i = 0; i < shuffledIndices.size(); ++i) {
                if (shuffledIndices[i] == currentActualIndex) {
                    currentIndex = i; // Update currentIndex to the new shuffled position
                    break;
                }
            }
        }
        qDebug() << "Shuffle On. Shuffled order: " << shuffledIndices;
    } else {
        shuffleButton->setIcon(QIcon(":/icons/shuffle_off.png"));
        if (currentIndex != -1 && !playlist.isEmpty()) {
            int currentActualIndex = shuffledIndices.at(currentIndex); // Get actual index of currently playing song
            currentIndex = currentActualIndex; // Reset current index to its original position
        }
        shuffledIndices.clear();
        qDebug() << "Shuffle Off.";
    }
    updatePlaylistWidgetSelection(); // Update selection to reflect changes
}

void MediaPlayer::toggleRepeat()
{
    repeatMode = (repeatMode + 1) % 3; // 0 -> 1 -> 2 -> 0 cycle
    switch (repeatMode) {
    case 0:
        repeatButton->setIcon(QIcon(":/icons/repeat_off.png"));
        qDebug() << "Repeat Off.";
        break;
    case 1:
        repeatButton->setIcon(QIcon(":/icons/repeat_all.png"));
        qDebug() << "Repeat All.";
        break;
    case 2:
        repeatButton->setIcon(QIcon(":/icons/repeat_one.png"));
        qDebug() << "Repeat One.";
        break;
    }
}

void MediaPlayer::addFilesToPlaylist()
{
    QStringList filePaths = QFileDialog::getOpenFileNames(this, "Add Media Files",
                                                          QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                          "Media Files (*.mp3 *.wav *.ogg *.flac *.m4a *.wma *.mp4 *.avi *.mkv *.mov)");

    if (!filePaths.isEmpty()) {
        bool wasPlaylistEmpty = playlist.isEmpty();
        for (const QString &filePath : filePaths) {
            QUrl url = QUrl::fromLocalFile(filePath);
            playlist.append(url);
            playlistWidget->addItem(QFileInfo(filePath).fileName());
        }

        if (wasPlaylistEmpty && !playlist.isEmpty()) {
            currentIndex = 0;
            playCurrentSong();
        } else if (isShuffled) {
            toggleShuffle(); // Re-shuffle to include new songs
            toggleShuffle();
        }
        updateButtonsState(mediaPlayer->playbackState());
    }
}

void MediaPlayer::playSelectedSong(QListWidgetItem *item)
{
    if (!item) return;

    int selectedIndexInWidget = playlistWidget->row(item);

    int newCurrentIndex = -1;
    if (isShuffled && !shuffledIndices.isEmpty()) {
        // Find the position of the selected *original* index within the shuffled list
        for (int i = 0; i < shuffledIndices.size(); ++i) {
            if (shuffledIndices[i] == selectedIndexInWidget) {
                newCurrentIndex = i; // This is the index in the shuffledIndices vector
                break;
            }
        }
    } else {
        newCurrentIndex = selectedIndexInWidget; // Direct index if not shuffled
    }

    if (newCurrentIndex != -1 && newCurrentIndex < playlist.size()) {
        currentIndex = newCurrentIndex;
        playCurrentSong();
    }
}

void MediaPlayer::clearPlaylist()
{
    mediaPlayer->stop();
    playlist.clear();
    shuffledIndices.clear();
    currentIndex = -1;
    playlistWidget->clear();
    qDebug() << "Playlist cleared.";
    updateButtonsState(QMediaPlayer::StoppedState);
    updateTimeLabel(0,0);
    positionSlider->setValue(0);
    positionSlider->setRange(0,0);
}

void MediaPlayer::updatePlaylistWidgetSelection()
{
    playlistWidget->clearSelection();

    if (currentIndex != -1 && !playlist.isEmpty()) {
        int actualSongIndexInPlaylistVector = currentIndex;
        if (isShuffled && !shuffledIndices.isEmpty() && currentIndex < shuffledIndices.size()) {
            actualSongIndexInPlaylistVector = shuffledIndices[currentIndex];
        }

        if (actualSongIndexInPlaylistVector >= 0 && actualSongIndexInPlaylistVector < playlistWidget->count()) {
            QListWidgetItem *item = playlistWidget->item(actualSongIndexInPlaylistVector);
            if (item) {
                item->setSelected(true);
                playlistWidget->scrollToItem(item); // Scroll to the selected item
            }
        }
    }
}

void MediaPlayer::onLikeButtonClicked()
{
    QMessageBox::information(this, "Action", "Like button clicked!");
    // Implement like functionality here
}

void MediaPlayer::onOptionsButtonClicked()
{
    QMessageBox::information(this, "Action", "Options button clicked!");
    // Implement options/menu functionality here
}

void MediaPlayer::onAddToPlaylistButtonClicked()
{
    // This could call addFilesToPlaylist() or open a more complex dialog
    QMessageBox::information(this, "Action", "Add to Playlist button clicked!");
    addFilesToPlaylist(); // Using the existing function to add files
}
