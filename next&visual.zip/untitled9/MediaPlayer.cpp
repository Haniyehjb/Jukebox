#include "MediaPlayer.h"
#include <QFileDialog>
#include <QUrl>
#include <QDebug>
#include <QGraphicsLinearLayout>
#include <QRandomGenerator>
#include <QMessageBox>
#include <QFile>

MediaPlayer::MediaPlayer(QWidget *parent)
    : QWidget(parent),
    mediaPlayer(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentIndex(-1),
    isShuffled(false),
    repeatMode(0) // 0: No Repeat
{
    mediaPlayer->setAudioOutput(audioOutput);
    audioOutput->setVolume(50);
    // Equalizer setup
    equalizerScene = new QGraphicsScene(this);
    equalizerView = new QGraphicsView(equalizerScene, this);
    equalizerView->setFixedHeight(120);
    equalizerView->setStyleSheet("background: transparent; border: 0;");
    equalizerScene->setBackgroundBrush(Qt::black);

    // Create 16 bars - positioned to grow downward from y=100
    for (int i = 0; i < 16; i++) {
        QGraphicsRectItem *bar = new QGraphicsRectItem(0, 100, 10, 2); // y=100 is the bottom position
        bar->setPos(i * 15, 0); // Position in the scene
        bar->setBrush(QColor::fromHsv(i * 15, 255, 200));
        equalizerBars.append(bar);
        equalizerScene->addItem(bar);
    }

    // Animation timer - set to faster interval (20ms)
    equalizerTimer = new QTimer(this);
    connect(equalizerTimer, &QTimer::timeout, this, &MediaPlayer::updateEqualizer);
    equalizerTimer->start(20); // Always running timer

    // UI setup
    openButton = new QPushButton("Open File", this);
    playButton = new QPushButton("Play", this);
    pauseButton = new QPushButton("Pause", this);
    stopButton = new QPushButton("Stop", this);
    nextButton = new QPushButton("Next", this);
    previousButton = new QPushButton("Previous", this);
    shuffleButton = new QPushButton("Shuffle (Off)", this);
    repeatButton = new QPushButton("Repeat (Off)", this);
    clearPlaylistButton = new QPushButton("Clear Playlist", this);
    positionSlider = new QSlider(Qt::Horizontal, this);
    volumeSlider = new QSlider(Qt::Horizontal, this);
    timeLabel = new QLabel("00:00 / 00:00", this);

    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(50);
    positionSlider->setRange(0, 0);

    playlistWidget = new QListWidget(this);

    QVBoxLayout *controlLayout = new QVBoxLayout();
    controlLayout->addWidget(openButton);
    controlLayout->addWidget(previousButton);
    controlLayout->addWidget(playButton);
    controlLayout->addWidget(pauseButton);
    controlLayout->addWidget(stopButton);
    controlLayout->addWidget(nextButton);
    controlLayout->addWidget(new QLabel("Volume:", this));
    controlLayout->addWidget(volumeSlider);
    controlLayout->addWidget(new QLabel("Position:", this));
    controlLayout->addWidget(positionSlider);
    controlLayout->addWidget(timeLabel);

    QHBoxLayout *modeButtonsLayout = new QHBoxLayout();
    modeButtonsLayout->addWidget(shuffleButton);
    modeButtonsLayout->addWidget(repeatButton);
    modeButtonsLayout->addWidget(clearPlaylistButton);

    mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(equalizerView);
    mainLayout->addLayout(controlLayout);
    mainLayout->addLayout(modeButtonsLayout);
    mainLayout->addWidget(positionSlider);
    mainLayout->addWidget(timeLabel);
    setLayout(mainLayout);

    // Connections
    connect(openButton, &QPushButton::clicked, this, &MediaPlayer::openFile);
    connect(playButton, &QPushButton::clicked, this, [this](){
        mediaPlayer->play();
    });
    connect(pauseButton, &QPushButton::clicked, this, [this](){
        mediaPlayer->pause();
    });
    connect(stopButton, &QPushButton::clicked, this, [this](){
        mediaPlayer->stop();
    });

    connect(nextButton, &QPushButton::clicked, this, &MediaPlayer::playNextSong);
    connect(previousButton, &QPushButton::clicked, this, &MediaPlayer::playPreviousSong);
    connect(shuffleButton, &QPushButton::clicked, this, &MediaPlayer::toggleShuffle);
    connect(repeatButton, &QPushButton::clicked, this, &MediaPlayer::toggleRepeat);
    connect(clearPlaylistButton, &QPushButton::clicked, this, &MediaPlayer::clearPlaylist);

    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, &MediaPlayer::handleMediaStatusChanged);

    connect(playlistWidget, &QListWidget::itemDoubleClicked, this, &MediaPlayer::playSelectedSong);


    connect(volumeSlider, &QSlider::valueChanged, this, &MediaPlayer::setVolume);
    connect(positionSlider, &QSlider::sliderMoved, mediaPlayer, &QMediaPlayer::setPosition);
    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::updatePosition);
    connect(mediaPlayer, &QMediaPlayer::durationChanged, this, &MediaPlayer::updateDuration);
    connect(mediaPlayer, &QMediaPlayer::playbackStateChanged, this, &MediaPlayer::updateButtonsState);

    QHBoxLayout *volumeLayout = new QHBoxLayout();
    volumeLayout->addWidget(new QLabel("Volume:", this));
    volumeLayout->addWidget(volumeSlider);
    mainLayout->addLayout(volumeLayout);

    mainLayout->addWidget(playlistWidget);

    setLayout(mainLayout);

    updateButtonsState(QMediaPlayer::StoppedState);
}

MediaPlayer::~MediaPlayer()
{
    equalizerTimer->stop();
    qDeleteAll(equalizerBars);
    delete mediaPlayer;
    delete audioOutput;
}

void MediaPlayer::updateEqualizer()
{
    qint64 time = QDateTime::currentMSecsSinceEpoch();
    float intensity = 1.0f;

    // Adjust intensity based on playback state
    if (mediaPlayer->playbackState() == QMediaPlayer::StoppedState) {
        intensity = 0.1f; // Minimal movement when stopped
    }
    else if (mediaPlayer->playbackState() == QMediaPlayer::PausedState) {
        intensity = 0.3f; // Reduced movement when paused
    }

    for (int i = 0; i < 16; i++) {
        // Smooth animation with intensity control
        float height = 2 + intensity * qAbs(60 * sin(time/80.0 + i*0.3) * cos(time/120.0 + i*0.2));
        equalizerBars[i]->setRect(0, 100-height, 10, height); // Bars grow downward
    }
}

void MediaPlayer::openFile()
{

    QString filePath = QFileDialog::getOpenFileName(this, "Open Media File",
                                                    QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                    "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");
    if (!filePath.isEmpty()) {
        playlist.clear();
        playlist.append(QUrl::fromLocalFile(filePath));
        currentIndex = 0;
        playlistWidget->clear();
        playlistWidget->addItem(QFileInfo(filePath).fileName());
        playCurrentSong();
    }
}

void MediaPlayer::setVolume(int volume) {
    audioOutput->setVolume(static_cast<qreal>(volume) / 100.0);
}

void MediaPlayer::updatePosition(qint64 position) {
    positionSlider->setValue(static_cast<int>(position));
    updateTimeLabel(position, mediaPlayer->duration());
}

void MediaPlayer::updateDuration(qint64 duration) {
    positionSlider->setRange(0, static_cast<int>(duration));
    updateTimeLabel(mediaPlayer->position(), duration);
}

void MediaPlayer::updateTimeLabel(qint64 currentPos, qint64 totalDuration) {
    qint64 currentSeconds = (currentPos / 1000) % 60;
    qint64 currentMinutes = (currentPos / 1000) / 60;
    qint64 totalSeconds = (totalDuration / 1000) % 60;
    qint64 totalMinutes = (totalDuration / 1000) / 60;

    timeLabel->setText(
        QString("%1:%2 / %3:%4")
            .arg(currentMinutes, 2, 10, QChar('0'))
            .arg(currentSeconds, 2, 10, QChar('0'))
            .arg(totalMinutes, 2, 10, QChar('0'))
            .arg(totalSeconds, 2, 10, QChar('0'))
        );
}

void MediaPlayer::updateButtonsState(QMediaPlayer::PlaybackState state) {
    bool isPlaying = (mediaPlayer->playbackState() == QMediaPlayer::PlayingState);
    bool isPaused = (mediaPlayer->playbackState() == QMediaPlayer::PausedState);

    playButton->setEnabled(!isPlaying);
    pauseButton->setEnabled(isPlaying);
    stopButton->setEnabled(isPlaying || isPaused);

    bool enablePlaylistControls = !playlist.isEmpty();
    nextButton->setEnabled(enablePlaylistControls);
    previousButton->setEnabled(enablePlaylistControls);
    shuffleButton->setEnabled(enablePlaylistControls);
    repeatButton->setEnabled(enablePlaylistControls);
    clearPlaylistButton->setEnabled(enablePlaylistControls);
}

void MediaPlayer::handleMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        qDebug() << "End of media reached. Playing next song.";
        playNextSong();
    } else if (status == QMediaPlayer::InvalidMedia) {
        qDebug() << "Invalid media source.";
        QMessageBox::warning(this, "Error", "Could not play media. Invalid format or corrupted file.");
        playNextSong();
    }
}

void MediaPlayer::playCurrentSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        qDebug() << "Playlist is empty. Cannot play song.";
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex < 0 || currentIndex >= playlist.size()) {
        qDebug() << "Current index out of bounds. Resetting to 0.";
        currentIndex = 0;
    }

    QUrl currentSource;
    if (isShuffled && !shuffledIndices.isEmpty()) {

        if (currentIndex < 0 || currentIndex >= shuffledIndices.size()) {
            qDebug() << "Shuffled index out of bounds. Resetting.";
            currentIndex = 0;
        }
        currentSource = playlist[shuffledIndices[currentIndex]];
    } else {

        currentSource = playlist[currentIndex];
    }

    mediaPlayer->setSource(currentSource);
    mediaPlayer->play();
    qDebug() << "Playing: " << currentSource.toLocalFile();
    updatePlaylistWidgetSelection();
}

void MediaPlayer::playNextSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    int nextIndex = currentIndex;

    if (repeatMode == 2) {

        qDebug() << "Repeat One: Replaying current song.";
    } else {
        nextIndex++;
        if (isShuffled) {
            if (nextIndex >= shuffledIndices.size()) {
                if (repeatMode == 1) {
                    nextIndex = 0;
                    qDebug() << "Repeat All (Shuffled): Wrapping around to first shuffled song.";
                } else {
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    qDebug() << "No Repeat (Shuffled): End of playlist reached.";
                    return;
                }
            }
        } else {
            if (nextIndex >= playlist.size()) {
                if (repeatMode == 1) {
                    nextIndex = 0;
                    qDebug() << "Repeat All: Wrapping around to first song.";
                } else {
                    mediaPlayer->stop();
                    currentIndex = -1;
                    updatePlaylistWidgetSelection();
                    qDebug() << "No Repeat: End of playlist reached.";
                    return;
                }
            }
        }
    }
    currentIndex = nextIndex;
    playCurrentSong();
}

void MediaPlayer::playPreviousSong()
{
    if (playlist.isEmpty()) {
        mediaPlayer->stop();
        currentIndex = -1;
        updatePlaylistWidgetSelection();
        return;
    }

    if (currentIndex <= 0) {

        if (repeatMode == 1) { // Repeat All
            currentIndex = (isShuffled ? shuffledIndices.size() : playlist.size()) - 1;
            qDebug() << "Repeat All: Wrapping around to last song.";
        } else {
            currentIndex = 0;
            qDebug() << "Previous: Already at the first song.";
        }
    } else {
        currentIndex--;
    }
    playCurrentSong();
}

void MediaPlayer::toggleShuffle()
{
    isShuffled = !isShuffled;
    if (isShuffled) {
        shuffleButton->setText("Shuffle (On)");
        shuffledIndices.clear();
        for (int i = 0; i < playlist.size(); ++i) {
            shuffledIndices.append(i);
        }

        std::random_shuffle(shuffledIndices.begin(), shuffledIndices.end());
        qDebug() << "Shuffle On. Shuffled order: " << shuffledIndices;
    } else {
        shuffleButton->setText("Shuffle (Off)");
        shuffledIndices.clear();
        qDebug() << "Shuffle Off.";
    }


}

void MediaPlayer::toggleRepeat()
{
    repeatMode = (repeatMode + 1) % 3; // 0 -> 1 -> 2 -> 0
    switch (repeatMode) {
    case 0:
        repeatButton->setText("Repeat (Off)");
        qDebug() << "Repeat Off.";
        break;
    case 1:
        repeatButton->setText("Repeat (All)");
        qDebug() << "Repeat All.";
        break;
    case 2:
        repeatButton->setText("Repeat (One)");
        qDebug() << "Repeat One.";
        break;
    }
}

void MediaPlayer::addFilesToPlaylist()
{
    QStringList filePaths = QFileDialog::getOpenFileNames(this, "Add Media Files",
                                                          QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
                                                          "Media Files (*.mp3 *.wav *.ogg *.flac *.mp4 *.avi *.mkv)");

    if (!filePaths.isEmpty()) {
        for (const QString &filePath : filePaths) {
            QUrl url = QUrl::fromLocalFile(filePath);
            playlist.append(url);
            playlistWidget->addItem(QFileInfo(filePath).fileName());
        }

        if (currentIndex == -1 && !playlist.isEmpty()) {
            currentIndex = 0;
            playCurrentSong();
        }


        if (isShuffled) {
            toggleShuffle();
            toggleShuffle();
        }
        updateButtonsState(mediaPlayer->playbackState());
    }
}

void MediaPlayer::playSelectedSong(QListWidgetItem *item)
{
    if (!item) return;

    int selectedIndexInWidget = playlistWidget->row(item);
    int actualIndex = -1;


    if (isShuffled && !shuffledIndices.isEmpty()) {

        actualIndex = selectedIndexInWidget;
    } else {
        actualIndex = selectedIndexInWidget;
    }


    if (actualIndex >= 0 && actualIndex < playlist.size()) {

        if (isShuffled && !shuffledIndices.isEmpty()) {

            for (int i = 0; i < shuffledIndices.size(); ++i) {
                if (shuffledIndices[i] == actualIndex) {
                    currentIndex = i;
                    break;
                }
            }
        } else {
            currentIndex = actualIndex;
        }

        playCurrentSong();
    }
}

void MediaPlayer::clearPlaylist()
{
    mediaPlayer->stop();
    playlist.clear();
    shuffledIndices.clear();
    currentIndex = -1;
    playlistWidget->clear();
    qDebug() << "Playlist cleared.";
    updateButtonsState(QMediaPlayer::StoppedState);
    updateTimeLabel(0,0);
}

void MediaPlayer::updatePlaylistWidgetSelection()
{
    playlistWidget->clearSelection();

    if (currentIndex != -1 && !playlist.isEmpty()) {
        int actualSongIndex = currentIndex;
        if (isShuffled && !shuffledIndices.isEmpty() && currentIndex < shuffledIndices.size()) {
            actualSongIndex = shuffledIndices[currentIndex];
        }

        if (actualSongIndex >= 0 && actualSongIndex < playlistWidget->count()) {
            QListWidgetItem *item = playlistWidget->item(actualSongIndex);
            if (item) {
                item->setSelected(true);
                playlistWidget->scrollToItem(item);
            }
        }
    }
}
