#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QListWidget>
#include <QSlider>
#include <QLabel>
#include <QPushButton> // Still needed if you keep any QPushButton, though QToolButton is used for icons
#include <QToolButton> // For icon-only buttons
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QUrl>
#include <QListWidgetItem> // For itemDoubleClicked signal
#include "User.h" // اضافه کن

class MediaPlayer : public QWidget
{
    Q_OBJECT

public:
    explicit MediaPlayer(User* user, QVector<User>* allUsers, QWidget *parent = nullptr);
    ~MediaPlayer();

private slots:


    void loadAllMusicAutomatically(); // بارگذاری خودکار موسیقی از پوشه پیش فرض
    void setVolume(int volume);
    void updatePosition(qint64 position);
    void updateDuration(qint64 duration);
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration);
    void updateButtonsState(QMediaPlayer::PlaybackState state);
    void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);

    void playCurrentSong();
    void playNextSong();
    void playPreviousSong();
    void toggleShuffle();
    void toggleRepeat();
    void clearPlaylist();
    void playSelectedSong(QListWidgetItem *item);
    void updatePlaylistWidgetSelection();

    // برای دکمه های بالا در سمت چپ و راست (Like, Options, Add to Playlist)
    void onLikeButtonClicked();
    void onOptionsButtonClicked();
    void onAddToPlaylistButtonClicked();

private:

    User* currentUser; // ⬅ یوزر لاگین‌شده ذخیره میشه
    QVector<User>* users;

    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;

    // UI Elements (mostly QToolButton now)
    QToolButton *playButton;
    QToolButton *pauseButton;
    QToolButton *stopButton;
    QToolButton *nextButton;
    QToolButton *previousButton;

    QToolButton *shuffleButton;
    QToolButton *repeatButton;
    QToolButton *clearPlaylistButton;
    QToolButton *loadAllMusicButton; // برای بارگذاری خودکار

    // دکمه های اضافی بر اساس تصویر
    QToolButton *likeButton;
    QToolButton *optionsButton; // دکمه منو یا گزینه ها
    QToolButton *addToPlaylistButton; // دکمه افزودن (علامت +)

    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;
    QListWidget *playlistWidget;

    QVBoxLayout *mainLayout;

    QVector<QUrl> playlist;
    QVector<int> shuffledIndices; // Store original indices for shuffled playback
    int currentIndex;
    bool isShuffled;
    int repeatMode; // 0: No Repeat, 1: Repeat All, 2: Repeat One

    void addFilesToPlaylist(); // این تابع داخلی نگه داشته شده اما به هیچ دکمه‌ای متصل نیست
};

#endif // MEDIAPLAYER_H
