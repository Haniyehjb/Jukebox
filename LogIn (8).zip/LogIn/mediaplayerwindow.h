#ifndef MEDIAPLAYERWINDOW_H
#define MEDIAPLAYERWINDOW_H

#include <QWidget>
#include <QListWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QVBoxLayout>
#include "UserManager.h"
#include <QLabel>

class MediaPlayerWindow : public QWidget
{
    Q_OBJECT
public:
    MediaPlayerWindow(User* currentUser, QWidget* parent = nullptr);

private slots:
    void addPlaylist();
    void addSongToPlaylist();
    void saveAndExit();

private:
    User* user;
    QListWidget *allSongsList;
    QListWidget *playlistsList;
    QListWidget *selectedPlaylistSongs;
    QLineEdit *newPlaylistNameEdit;
    QPushButton *addPlaylistButton;
    QPushButton *addSongButton;
    QPushButton *exitButton;

    void loadSongs();
    void updatePlaylistsView();
};

#endif // MEDIAPLAYERWINDOW_H
