#ifndef UTILS_H
#define UTILS_H

#include <QString>

QString encrypt(QString data, QString key = "mySecretKey");
QString decrypt(QString data, QString key = "mySecretKey");

#endif // UTILS_H
