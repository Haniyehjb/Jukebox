#ifndef SONGRECEIVER_H
#define SONGRECEIVER_H

#include <QTcpSocket>
#include <QFile>
#include <QObject>

class SongReceiver : public QObject
{
    Q_OBJECT

public:
    SongReceiver(QObject* parent = nullptr);
    void startReceiving(const QString& savePath, const QString& senderIP);

private slots:
    void readData();
    void finalizeReceiving();

private:
    QTcpSocket* socket;
    QFile file;
};

#endif // SONGRECEIVER_H
