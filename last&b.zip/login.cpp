// login.cpp
#include "login.h"
#include "mainwindow.h" // If you use a mainwindow, keep this. If not, remove.
#include <QFile>
#include <QTextStream>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QCryptographicHash>
#include <QDir>
#include <QTimer>
#include "UserManager.h"
#include "dashboardWindow.h" // این خط را اضافه کنید
#include "forgotpassword.h" // Make sure this is included if you have a forgot password feature

Login::Login(QWidget *parent)
    : QWidget(parent)
    , forgotPasswordWindow(nullptr) // Initialize pointer
{
    setFixedSize(600, 400);

    backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 400);
    backgroundLabel->setPixmap(QPixmap("1.jpg")); // Ensure "1.jpg" is in the correct path or add to qrc
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();
    setWindowTitle("Login");

    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(100, 100, 100, 100); // Add some margins
    layout->setSpacing(15); // Add spacing between widgets

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("Username");
    usernameEdit->setFixedHeight(35); // Set fixed height for input fields

    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("Password");
    passwordEdit->setEchoMode(QLineEdit::Password);
    passwordEdit->setFixedHeight(35); // Set fixed height for input fields

    loginButton = new QPushButton("Login", this);
    loginButton->setFixedHeight(40); // Set fixed height for buttons
    loginButton->setStyleSheet("QPushButton { background-color: #4CAF50; color: white; border-radius: 5px; }"
                               "QPushButton:hover { background-color: #45a049; }");

    messageLabel = new QLabel(this);
    messageLabel->setStyleSheet("color: red; font-weight: bold;");
    messageLabel->setAlignment(Qt::AlignCenter);

    forgotPasswordBtn = new QPushButton("Forgot Password?", this);
    forgotPasswordBtn->setStyleSheet("background-color: transparent; color: blue; text-decoration: underline; border: none;");


    layout->addWidget(usernameEdit);
    layout->addWidget(passwordEdit);
    layout->addWidget(loginButton);
    layout->addWidget(forgotPasswordBtn);
    layout->addWidget(messageLabel);

    setLayout(layout);


    connect(loginButton, &QPushButton::clicked, this, &Login::loginUser);
    connect(forgotPasswordBtn, &QPushButton::clicked, this, &Login::showForgotPassword);

    // Initial load of user data
    UserManager::getInstance()->loadFromFile("users.txt");
}


void Login::loginUser()
{
    QString username = usernameEdit->text().trimmed();
    QString password = passwordEdit->text();

    if (username.isEmpty() || password.isEmpty()) {
        messageLabel->setStyleSheet("color: red;");
        messageLabel->setText("Please enter both fields.");
        return;
    }

    QByteArray enteredHash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex();
    QString enteredHashHex = enteredHash;

    QVector<User>& users = UserManager::getInstance()->getUsers();
    bool success = false;

    for (User& user : users) {
        if (user.username == username && user.hashedPassword == enteredHashHex) {
            UserManager::getInstance()->setLoggedInUser(&user);
            success = true;
            break;
        }
    }

    if (success) {
        messageLabel->setStyleSheet("color: green;");
        messageLabel->setText("Login successful!");

        QTimer::singleShot(1500, [this]() {
            User* loggedUser = UserManager::getInstance()->getLoggedInUser();
            QVector<User>* allUsers = &UserManager::getInstance()->getUsers();

            // Correct MediaPlayer constructor call
            DashboardWindow *dashboardWindow = new DashboardWindow(loggedUser, allUsers, nullptr);
            dashboardWindow->show();

            this->close(); // Close the login form
        });
    }
    else {
        messageLabel->setStyleSheet("color: red;");
        messageLabel->setText("Invalid username or password.");
    }
}


void Login::showForgotPassword()
{
    if (!forgotPasswordWindow) {
        forgotPasswordWindow = new ForgotPassword();
    }
    forgotPasswordWindow->show();
}
