// DashboardWindow.cpp - Modified Section
#include "DashboardWindow.h"
#include "MediaPlayer.h"     // To open the offline media player
#include "onlinetestform.h"  // ADD THIS LINE: برای باز کردن OnlineTestForm
#include <QMessageBox>       // For temporary messages
#include <QPixmap>           // For background image

DashboardWindow::DashboardWindow(User* loggedUser, QVector<User>* allUsers, QWidget *parent)
    : QWidget(parent)
    , m_loggedUser(loggedUser)
    , m_allUsers(allUsers)
{
    setFixedSize(600, 400);
    setWindowTitle("Dashboard");

    QLabel *backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 400);
    backgroundLabel->setPixmap(QPixmap("1.jpg"));
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();

    mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(50, 80, 100, 80);
    mainLayout->setSpacing(20);
    mainLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    welcomeLabel = new QLabel(QString("Welcome, %1!").arg(m_loggedUser ? m_loggedUser->username : "Guest"), this);
    welcomeLabel->setStyleSheet("color: white; font-size: 24px; font-weight: bold;");
    welcomeLabel->setAlignment(Qt::AlignLeft);

    // Create buttons without custom stylesheets for color, using default Qt style
    // The width (180) and height (50) are taken from MainWindow's buttons.
    mediaPlayerButton = new QPushButton("Offline Music Player", this);
    mediaPlayerButton->setFixedSize(180, 50);

    onlineMusicPlayerButton = new QPushButton("Online Music Player", this);
    onlineMusicPlayerButton->setFixedSize(180, 50);

    videoPlayerButton = new QPushButton("Video Player", this);
    videoPlayerButton->setFixedSize(180, 50);

    mainLayout->addWidget(welcomeLabel);
    mainLayout->addSpacing(30);
    mainLayout->addWidget(mediaPlayerButton);
    mainLayout->addWidget(onlineMusicPlayerButton); // Keep this line as it adds the button to the layout
    mainLayout->addWidget(videoPlayerButton);
    mainLayout->addStretch(1);

    setLayout(mainLayout);

    connect(mediaPlayerButton, &QPushButton::clicked, this, &DashboardWindow::openMediaPlayer);
    // CONNECT THE ONLINE MUSIC PLAYER BUTTON TO ITS NEW SLOT
    connect(onlineMusicPlayerButton, &QPushButton::clicked, this, &DashboardWindow::openOnlineMusicPlayer); // ADD THIS LINE
    // connect(videoPlayerButton, &QPushButton::clicked, this, &DashboardWindow::openVideoPlayer); // This one remains commented unless you implement it
}

DashboardWindow::~DashboardWindow()
{
    // No explicit deletion needed for child widgets as they are managed by Qt's parent-child hierarchy.
}

void DashboardWindow::openMediaPlayer()
{
    MediaPlayer *playerWindow = new MediaPlayer(m_loggedUser, m_allUsers, nullptr);
    playerWindow->show();
    this->close(); // Close the dashboard window
}

// ADD THIS NEW SLOT FUNCTION
void DashboardWindow::openOnlineMusicPlayer()
{
    OnlineTestForm *onlinePlayerForm = new OnlineTestForm(this); // You might want to pass 'this' as parent
    // this->close();
    onlinePlayerForm->show();
    // this->hide(); // You can choose to hide the dashboard or close it. For now, let's keep it open.
    // If you want to close the dashboard: this->close();
}

// Ensure openVideoPlayer is defined, even if it's just a placeholder
void DashboardWindow::openVideoPlayer()
{
    QMessageBox::information(this, "Coming Soon", "Video Player functionality will be implemented here!");
}
