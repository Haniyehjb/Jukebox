#include "serverwindow.h"
#include <QDataStream> // برای سریالایز کردن داده ها
#include <QNetworkDatagram> // برای UDP
#include <QFileInfo>

const quint16 SERVER_PORT_TCP = 12345; // پورت برای TCP
const quint16 SERVER_PORT_UDP = 12346; // پورت برای UDP
const int MAX_CLIENTS = 5;

ServerWindow::ServerWindow(QWidget *parent)
    : QWidget(parent)
{
    startButton = new QPushButton("شروع سرور و پخش آنلاین");
    statusLabel = new QLabel("برای شروع سرور روی دکمه کلیک کنید.");
    ipAddressLabel = new QLabel("");

    mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(startButton);
    mainLayout->addWidget(statusLabel);
    mainLayout->addWidget(ipAddressLabel);

    tcpServer = new QTcpServer(this);
    udpSocket = new QUdpSocket(this);

    musicPlayerWindow = new MusicPlayerWindow();
    musicPlayerWindow->setAdminMode(true); // ادمین مود فعال
    mainLayout->addWidget(musicPlayerWindow); // اضافه کردن پلیر به لایوت

    connect(startButton, &QPushButton::clicked, this, &ServerWindow::startServer);
    connect(tcpServer, &QTcpServer::newConnection, this, &ServerWindow::newConnection);
    connect(udpSocket, &QUdpSocket::readyRead, this, &ServerWindow::readClientDataUdp); // برای دریافت پیام UDP از کلاینت

    // اتصال سیگنال های MusicPlayerWindow به اسلات های ServerWindow
    connect(musicPlayerWindow, &MusicPlayerWindow::songSelected, this, &ServerWindow::handleSongSelected);
    connect(musicPlayerWindow, &MusicPlayerWindow::playCommand, this, &ServerWindow::handlePlayCommand);
    connect(musicPlayerWindow, &MusicPlayerWindow::pauseCommand, this, &ServerWindow::handlePauseCommand);

    // برای ارسال فایل
    transferFile = nullptr;
    totalBytes = 0;
    bytesWritten = 0;
    currentFileTransferSocket = nullptr;

    setWindowTitle("سرور پخش موسیقی آنلاین");
    setFixedSize(450, 450); // بزرگتر کردن پنجره برای جا شدن پلیر
}

ServerWindow::~ServerWindow()
{
    if (tcpServer->isListening()) {
        tcpServer->close();
    }
    udpSocket->close();
    for (QTcpSocket *socket : clientSockets) {
        socket->close();
        socket->deleteLater();
    }
    if (transferFile && transferFile->isOpen()) {
        transferFile->close();
        delete transferFile;
    }
    musicPlayerWindow->deleteLater(); // حذف پنجره پلیر
}

void ServerWindow::startServer()
{
    if (!tcpServer->listen(QHostAddress::Any, SERVER_PORT_TCP)) {
        QMessageBox::critical(this, "خطا در شروع سرور",
                              "سرور TCP نتوانست شروع به گوش دادن کند: " + tcpServer->errorString());
        statusLabel->setText("خطا در شروع سرور TCP.");
        return;
    }

    if (!udpSocket->bind(QHostAddress::Any, SERVER_PORT_UDP)) {
        QMessageBox::critical(this, "خطا در شروع سرور",
                              "سرور UDP نتوانست شروع به گوش دادن کند: " + udpSocket->errorString());
        statusLabel->setText("خطا در شروع سرور UDP.");
        tcpServer->close();
        return;
    }

    startButton->setEnabled(false);
    statusLabel->setText(QString("سرور شروع شد. در انتظار اتصال کلاینت‌ها... (0/%1 کلاینت متصل)").arg(MAX_CLIENTS));
    displayServerInfo();

    QMessageBox::information(this, "سرور شروع شد",
                             "سرور موسیقی آنلاین با موفقیت شروع شد!\n"
                             "IP خود را به کلاینت‌ها برای اتصال اعلام کنید.");
}

void ServerWindow::newConnection()
{
    if (clientSockets.size() >= MAX_CLIENTS) {
        QTcpSocket *tempSocket = tcpServer->nextPendingConnection();
        if (tempSocket) {
            tempSocket->disconnectFromHost();
            tempSocket->deleteLater();
        }
        return;
    }

    QTcpSocket *clientSocket = tcpServer->nextPendingConnection();
    if (clientSocket) {
        clientSockets.append(clientSocket);

        connect(clientSocket, &QTcpSocket::disconnected, this, &ServerWindow::clientDisconnected);
        connect(clientSocket, &QTcpSocket::readyRead, this, &ServerWindow::readClientDataTcp);
        connect(clientSocket, &QTcpSocket::bytesWritten, this, &ServerWindow::updateFileTransferProgress);

        statusLabel->setText(QString("کلاینت جدید متصل شد: %1\nکلاینت‌های متصل: %2/%3")
                                 .arg(clientSocket->peerAddress().toString())
                                 .arg(clientSockets.size())
                                 .arg(MAX_CLIENTS));
        qDebug() << "New client connected (TCP) from:" << clientSocket->peerAddress().toString();
    }
}

void ServerWindow::clientDisconnected()
{
    QTcpSocket *disconnectedSocket = qobject_cast<QTcpSocket *>(sender());
    if (disconnectedSocket) {
        clientSockets.removeAll(disconnectedSocket);
        disconnectedSocket->deleteLater();
        statusLabel->setText(QString("کلاینت قطع شد. کلاینت‌های متصل: %1/%2")
                                 .arg(clientSockets.size())
                                 .arg(MAX_CLIENTS));
        qDebug() << "Client disconnected (TCP):" << disconnectedSocket->peerAddress().toString();
    }
}

void ServerWindow::readClientDataTcp()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket *>(sender());
    if (!clientSocket) return;

    QDataStream in(clientSocket);
    in.setVersion(QDataStream::Qt_6_0);

    // Loop to process potentially multiple messages in the buffer
    while(clientSocket->bytesAvailable() > 0) {
        // Start of a new message block
        if (clientSocket->bytesAvailable() < (qint64)sizeof(quint32)) {
            return; // Not enough data for the block size
        }

        quint32 blockSize;
        in >> blockSize;

        if (clientSocket->bytesAvailable() < blockSize) {
            // Full message not yet received, wait for more data
            // We need to rewind the stream to read the block size again next time
            // This is complex, a better way is to have a member variable for expected size.
            // For now, assuming messages arrive completely.
            return;
        }

        QString messageType;
        in >> messageType;

        if (messageType == "REQUEST_SONG_FILE") {
            QString songName;
            in >> songName;
            qDebug() << "Client requested song file:" << songName;

            QString requestedFilePath = musicPlayerWindow->getCurrentPlayingSongPath();
            if (!requestedFilePath.isEmpty() && QFileInfo(requestedFilePath).fileName() == songName) {
                sendFileToClient(clientSocket, requestedFilePath);
            } else {
                qDebug() << "Error: Admin does not have the requested file or path is incorrect.";
                // Optionally send an error message back to the client
            }
        }
    }
}


void ServerWindow::sendFileToClient(QTcpSocket *socket, const QString &filePath)
{
    if (transferFile && transferFile->isOpen()) {
        QMessageBox::warning(this, "خطا", "سرور در حال حاضر مشغول ارسال فایل دیگری است.");
        return;
    }

    transferFile = new QFile(filePath);
    if (!transferFile->open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "خطا", "فایل برای ارسال باز نشد: " + transferFile->errorString());
        delete transferFile;
        transferFile = nullptr;
        return;
    }

    currentFileTransferSocket = socket;
    totalBytes = transferFile->size();
    bytesWritten = 0;

    // 1. Send the header (file info)
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_0);

    out << (quint32)0; // Placeholder for block size
    out << QString("FILE_TRANSFER");
    out << QFileInfo(filePath).fileName();
    out << totalBytes;

    out.device()->seek(0);
    out << (quint32)(block.size() - sizeof(quint32));

    socket->write(block);

    statusLabel->setText(QString("در حال ارسال فایل %1... (0%%)").arg(QFileInfo(filePath).fileName()));
    qDebug() << "Starting file transfer of" << QFileInfo(filePath).fileName() << "to" << socket->peerAddress().toString();

    // 2. Start sending the file data in chunks
    updateFileTransferProgress(0); // Call directly to start the process
}


void ServerWindow::updateFileTransferProgress(qint64 numBytes)
{
    // This slot is connected to the bytesWritten signal, which indicates that the socket
    // has processed previous data and has buffer space available.

    if (transferFile == nullptr) {
        return; // No transfer in progress
    }

    // We can use numBytes to track progress accurately
    bytesWritten += numBytes;

    if (bytesWritten < totalBytes) {
        // If there's still more to send, write the next chunk
        if(currentFileTransferSocket->bytesToWrite() == 0) {
            QByteArray chunk = transferFile->read(64 * 1024); // 64KB chunk
            currentFileTransferSocket->write(chunk);
        }
    } else {
        // All bytes have been written to the socket buffer
        qDebug() << "File transfer complete:" << transferFile->fileName();
        statusLabel->setText(QString("فایل '%1' با موفقیت ارسال شد.").arg(transferFile->fileName()));
        transferFile->close();
        delete transferFile;
        transferFile = nullptr;
        currentFileTransferSocket = nullptr;
        bytesWritten = 0;
        totalBytes = 0;
    }

    // Update UI
    if(totalBytes > 0) {
        double progress = (double)bytesWritten * 100 / totalBytes;
        statusLabel->setText(QString("در حال ارسال فایل... (%1%)").arg(QString::number(progress, 'f', 1)));
    }
}


void ServerWindow::readClientDataUdp()
{
    while (udpSocket->hasPendingDatagrams()) {
        QNetworkDatagram datagram = udpSocket->receiveDatagram();
        QByteArray data = datagram.data();
        QString message = QString::fromUtf8(data);
        qDebug() << "UDP data received from" << datagram.senderAddress().toString() << ":" << message;
        // Currently, clients do not send UDP messages to the server, but this is here for future expansion.
    }
}

void ServerWindow::handleSongSelected(const QString &fileName, const QByteArray &fileHash)
{
    Q_UNUSED(fileHash);
    qDebug() << "Server: Song selected signal received. Broadcasting to clients.";
    sendUdpCommand("SONG_SELECTED", fileName);
}

void ServerWindow::handlePlayCommand(qint64 currentPositionMs)
{
    qDebug() << "Server: Play command received. Broadcasting to clients. Pos:" << currentPositionMs;
    sendUdpCommand("PLAY", musicPlayerWindow->getCurrentPlayingSongName(), currentPositionMs);
}

void ServerWindow::handlePauseCommand(qint64 currentPositionMs)
{
    qDebug() << "Server: Pause command received. Broadcasting to clients. Pos:" << currentPositionMs;
    sendUdpCommand("PAUSE", musicPlayerWindow->getCurrentPlayingSongName(), currentPositionMs);
}

void ServerWindow::sendUdpCommand(const QString &commandType, const QString &songName, qint64 positionMs)
{
    QString message = QString("%1|%2|%3").arg(commandType).arg(songName).arg(positionMs);
    QByteArray datagram = message.toUtf8();

    for (QTcpSocket *clientSocket : clientSockets) {
        udpSocket->writeDatagram(datagram, clientSocket->peerAddress(), SERVER_PORT_UDP);
    }
    qDebug() << "Broadcasted UDP command:" << message;
}

void ServerWindow::displayServerInfo()
{
    QString ipAddress;
    const QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    for (const QHostAddress &entry : ipAddressesList) {
        if (entry != QHostAddress::LocalHost && entry.toIPv4Address()) {
            ipAddress = entry.toString();
            break;
        }
    }
    if (ipAddress.isEmpty())
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();

    ipAddressLabel->setText(QString("Server IP: %1\nTCP Port: %2\nUDP Port: %3")
                                .arg(ipAddress)
                                .arg(SERVER_PORT_TCP)
                                .arg(SERVER_PORT_UDP));
    ipAddressLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
}
