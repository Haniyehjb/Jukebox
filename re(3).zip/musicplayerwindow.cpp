#include "musicplayerwindow.h"
#include <QDebug>
#include <QMessageBox>

MusicPlayerWindow::MusicPlayerWindow(QWidget *parent)
    : QWidget(parent)
{
    player = new QMediaPlayer(this);
    audioOutput = new QAudioOutput(this); // برای Qt6 ضروری است
    player->setAudioOutput(audioOutput); // اتصال QAudioOutput به QMediaPlayer

    openButton = new QPushButton("انتخاب آهنگ (ادمین)");
    playPauseButton = new QPushButton("پلی");
    playPauseButton->setEnabled(false); // در ابتدا غیرفعال است
    positionSlider = new QSlider(Qt::Horizontal);
    positionSlider->setRange(0, 0); // در ابتدا بدون محدوده
    statusLabel = new QLabel("آهنگی انتخاب نشده.");
    timeLabel = new QLabel("00:00 / 00:00");

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(statusLabel);
    layout->addWidget(openButton);
    layout->addWidget(playPauseButton);
    layout->addWidget(positionSlider);
    layout->addWidget(timeLabel);

    // سیگنال ها و اسلات های QMediaPlayer
    connect(player, &QMediaPlayer::playbackStateChanged, this, &MusicPlayerWindow::updatePlayButtonText);
    connect(player, &QMediaPlayer::positionChanged, this, &MusicPlayerWindow::updatePosition);
    connect(player, &QMediaPlayer::durationChanged, this, &MusicPlayerWindow::updateDuration);
    connect(player, &QMediaPlayer::mediaStatusChanged, this, &MusicPlayerWindow::mediaStatusChanged);

    // سیگنال ها و اسلات های UI
    connect(openButton, &QPushButton::clicked, this, &MusicPlayerWindow::openFile);
    connect(playPauseButton, &QPushButton::clicked, this, &MusicPlayerWindow::togglePlayPause);
    connect(positionSlider, &QSlider::sliderMoved, this, &MusicPlayerWindow::setPosition);

    setWindowTitle("پخش کننده موسیقی");
    setFixedSize(400, 250);
}

MusicPlayerWindow::~MusicPlayerWindow()
{
    if (player->playbackState() == QMediaPlayer::PlayingState) {
        player->stop();
    }
    player->deleteLater();
    audioOutput->deleteLater();
}

void MusicPlayerWindow::setAdminMode(bool isAdmin)
{
    isAdminMode = isAdmin;
    openButton->setVisible(isAdmin); // دکمه انتخاب آهنگ فقط برای ادمین
}

void MusicPlayerWindow::openFile()
{
    QString filePath = QFileDialog::getOpenFileName(this, "انتخاب فایل موسیقی", "", "Music Files (*.mp3 *.wav *.ogg)");
    if (!filePath.isEmpty()) {
        currentPlayingSongPath = filePath;
        QFileInfo fileInfo(filePath);
        currentPlayingSongName = fileInfo.fileName();
        statusLabel->setText(QString("آهنگ انتخاب شد: %1").arg(currentPlayingSongName));
        playPauseButton->setEnabled(true);
        player->setSource(QUrl::fromLocalFile(filePath));
        player->pause(); // در ابتدا در حالت پاز باشد
        updatePlayButtonText(player->playbackState());
        positionSlider->setValue(0); // اسلایدر را به اول بیاور

        // اینجا باید یک هش از فایل ایجاد و ارسال کنی
        // فعلا فقط نام فایل را میفرستیم
        QByteArray fileHash; // TODO: Implement file hashing (e.g., MD5/SHA1)
        emit songSelected(currentPlayingSongName, fileHash);
        qDebug() << "Admin selected song:" << currentPlayingSongName;
    }
}

void MusicPlayerWindow::togglePlayPause()
{
    if (player->mediaStatus() == QMediaPlayer::NoMedia || currentPlayingSongPath.isEmpty()) {
        QMessageBox::warning(this, "خطا", "لطفاً ابتدا یک آهنگ انتخاب کنید.");
        return;
    }

    if (player->playbackState() == QMediaPlayer::PlayingState) {
        player->pause();
        emit pauseCommand(player->position()); // ارسال فرمان پاز با ثانیه فعلی
        qDebug() << "Player Paused. Position:" << player->position();
    } else {
        player->play();
        emit playCommand(player->position()); // ارسال فرمان پلی با ثانیه فعلی
        qDebug() << "Player Playing. Position:" << player->position();
    }
}

void MusicPlayerWindow::playMusic(const QString &fileName, qint64 positionMs)
{
    QFileInfo fileInfo(fileName);
    currentPlayingSongName = fileInfo.fileName(); // فقط نام فایل
    statusLabel->setText(QString("در حال پخش: %1").arg(currentPlayingSongName));

    // اگر مسیر فایل محلی را نداریم (برای کلاینتی که فایل را از طریق TCP دریافت کرده)
    // باید QMediaPlayer را با QIODevice که از QByteArray می آید، تغذیه کنیم.
    // فعلاً فرض می کنیم فایل با این نام در جایی در دسترس است.
    // در سناریو واقعی، باید مسیر کامل یا یک QBuffer از داده های آهنگ را بدهید.

    // اگر فایل روی سیستم کلاینت موجود باشد
    // TODO: implement local file search for client
    // For now, let's just set the source with the received name (assuming client has it)
    player->setSource(QUrl::fromLocalFile(QDir::homePath() + "/Music/" + currentPlayingSongName)); // example path
    // اگر فایل رو نداشتی باید سیگنال درخواست فایل رو بفرستی
    //emit requestSongFile(currentPlayingSongName); // این سیگنال از ClientWindow ارسال میشه

    player->setPosition(positionMs);
    player->play();
    playPauseButton->setEnabled(true); // فعال کردن دکمه بعد از انتخاب/دریافت آهنگ
    qDebug() << "MusicPlayerWindow: playMusic called for" << currentPlayingSongName << "at position" << positionMs;
}

void MusicPlayerWindow::pauseMusic()
{
    player->pause();
    qDebug() << "MusicPlayerWindow: pauseMusic called.";
}

void MusicPlayerWindow::resumeMusic(qint64 positionMs)
{
    player->setPosition(positionMs);
    player->play();
    qDebug() << "MusicPlayerWindow: resumeMusic called at position" << positionMs;
}

void MusicPlayerWindow::stopMusic()
{
    player->stop();
    statusLabel->setText("پخش متوقف شد.");
    qDebug() << "MusicPlayerWindow: stopMusic called.";
}

void MusicPlayerWindow::updatePlayButtonText(QMediaPlayer::PlaybackState state)
{
    if (state == QMediaPlayer::PlayingState) {
        playPauseButton->setText("پاز");
    } else {
        playPauseButton->setText("پلی");
    }
}

void MusicPlayerWindow::updatePosition(qint64 position)
{
    positionSlider->setValue(position);
    timeLabel->setText(QString("%1 / %2")
                           .arg(formatTime(position))
                           .arg(formatTime(player->duration())));
}

void MusicPlayerWindow::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, duration);
    timeLabel->setText(QString("%1 / %2")
                           .arg(formatTime(player->position()))
                           .arg(formatTime(duration)));
}

void MusicPlayerWindow::setPosition(int position)
{
    player->setPosition(position);
    // وقتی کاربر اسلایدر رو تغییر میده، می‌تونی این رو به بقیه کلاینت‌ها هم اطلاع بدی.
    // ولی برای سادگی فعلاً این کار رو نمی‌کنیم، چون قرار شد فقط Play/Pause همگام‌سازی بشه.
}

void MusicPlayerWindow::mediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::BufferedMedia || status == QMediaPlayer::LoadedMedia) {
        // آهنگ آماده پخش است
        qDebug() << "Media ready.";
    } else if (status == QMediaPlayer::InvalidMedia) {
        QMessageBox::critical(this, "خطای پخش", "فایل موسیقی معتبر نیست یا یافت نشد.");
        statusLabel->setText("خطا: فایل نامعتبر.");
        playPauseButton->setEnabled(false);
    }
}

QString MusicPlayerWindow::formatTime(qint64 milliseconds)
{
    qint64 seconds = milliseconds / 1000;
    qint64 minutes = seconds / 60;
    seconds %= 60;
    return QString("%1:%2").arg(minutes, 2, 10, QChar('0')).arg(seconds, 2, 10, QChar('0'));
}
