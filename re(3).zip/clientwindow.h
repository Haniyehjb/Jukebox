#ifndef CLIENTWINDOW_H
#define CLIENTWINDOW_H

#include <QWidget>
#include <QTcpSocket>
#include <QUdpSocket> // برای دریافت دستورات UDP
#include <QPushButton>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QFile> // برای ذخیره فایل دریافتی
#include <QDir> // برای مسیر دهی
#include <QCryptographicHash> // برای هش فایل (اختیاری)
#include "musicplayerwindow.h" // شامل کلاس پنجره پخش کننده موسیقی

class ClientWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ClientWindow(QWidget *parent = nullptr);
    ~ClientWindow();

private slots:
    void connectToServer();
    void connected();
    void disconnected();
    void errorOccurred(QTcpSocket::SocketError socketError);
    void readServerDataTcp(); // خواندن داده از سرور (TCP)
    void readServerDataUdp(); // خواندن داده از سرور (UDP)

    // اسلات برای دریافت سیگنال از MusicPlayerWindow
    void handleRequestSongFile(const QString &fileName); // اگر آهنگ رو نداشته باشیم

    void updateFileReadProgress(qint64 numBytes); // برای نمایش پیشرفت دریافت فایل

private:
    QTcpSocket *tcpSocket;
    QUdpSocket *udpSocket; // برای دریافت دستورات

    QLineEdit *ipLineEdit;
    QPushButton *connectButton;
    QLabel *statusLabel;
    QVBoxLayout *mainLayout;

    MusicPlayerWindow *musicPlayerWindow; // پنجره پخش کننده موسیقی

    // برای دریافت فایل
    QFile *receivingFile;
    qint64 bytesReceived;
    qint64 totalBytesToReceive;
    QString currentReceivingFileName;
    QByteArray fileBuffer; // برای ذخیره داده های فایل تا کامل شدن

    bool checkIfSongExistsLocally(const QString &songName); // بررسی وجود آهنگ به صورت محلی
    void sendTcpRequest(const QString &requestType, const QString &payload); // تابع کمکی برای ارسال درخواست TCP
};

#endif // CLIENTWINDOW_H
