#ifndef SERVERWINDOW_H
#define SERVERWINDOW_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QUdpSocket> // برای ارتباط UDP
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QHostAddress>
#include <QNetworkInterface>
#include <QFile> // برای ارسال فایل
#include "musicplayerwindow.h" // شامل کلاس پنجره پخش کننده موسیقی

// ... بقیه include ها

class ServerWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ServerWindow(QWidget *parent = nullptr);
    ~ServerWindow();

private slots:
    void startServer();
    void newConnection();
    void clientDisconnected();
    void readClientDataTcp(); // برای خواندن داده از کلاینت (TCP)
    void readClientDataUdp(); // برای خواندن داده از کلاینت (UDP)

    // اسلات ها برای دریافت سیگنال از MusicPlayerWindow
    void handleSongSelected(const QString &fileName, const QByteArray &fileHash);
    void handlePlayCommand(qint64 currentPositionMs);
    void handlePauseCommand(qint64 currentPositionMs);

private:
    QTcpServer *tcpServer;
    QList<QTcpSocket *> clientSockets; // برای ارتباط TCP با کلاینت‌ها
    QUdpSocket *udpSocket;             // برای ارتباط UDP

    QPushButton *startButton;
    QLabel *statusLabel;
    QLabel *ipAddressLabel;
    QVBoxLayout *mainLayout;

    MusicPlayerWindow *musicPlayerWindow; // پنجره پخش کننده موسیقی

    void displayServerInfo();
    void sendUdpCommand(const QString &commandType, const QString &songName = "", qint64 positionMs = 0);

    // برای ارسال فایل
    QFile *transferFile;
    qint64 bytesToWrite;
    qint64 totalBytes;
    qint64 bytesWritten;
    QTcpSocket *currentFileTransferSocket; // سوکت کلاینتی که در حال دریافت فایل است

    void sendFileToClient(QTcpSocket *socket, const QString &filePath); // تابع برای ارسال فایل
    void updateFileTransferProgress(qint64 numBytes); // آپدیت پیشرفت ارسال فایل
};

#endif // SERVERWINDOW_H
