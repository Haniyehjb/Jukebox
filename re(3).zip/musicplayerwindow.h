#ifndef MUSICPLAYERWINDOW_H
#define MUSICPLAYERWINDOW_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput> // در Qt6 QMediaPlayer به QAudioOutput نیاز دارد
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QFileDialog> // برای باز کردن فایل
#include <QTimer>      // برای ارسال منظم زمان پخش
#include <QSlider>     // برای نمایش پیشرفت آهنگ

class MusicPlayerWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MusicPlayerWindow(QWidget *parent = nullptr);
    ~MusicPlayerWindow();

    void setAdminMode(bool isAdmin); // برای تعیین حالت ادمین/کلاینت

    // توابع برای کنترل پخش از بیرون (توسط سرور/کلاینت)
    void playMusic(const QString &fileName, qint64 positionMs = 0);
    void pauseMusic();
    void resumeMusic(qint64 positionMs = 0); // ادامه پخش از یک زمان مشخص
    void stopMusic();

    QString getCurrentPlayingSongName() const { return currentPlayingSongName; }
    QString getCurrentPlayingSongPath() const { return currentPlayingSongPath; } // New getter method

signals:
    // سیگنال برای اطلاع‌رسانی به سرور/کلاینت درباره تغییر وضعیت پخش
    void playCommand(qint64 currentPositionMs);
    void pauseCommand(qint64 currentPositionMs);
    void stopCommand();
    void songSelected(const QString &fileName, const QByteArray &fileHash); // سیگنال برای ادمین که آهنگی انتخاب شد
    void requestSongFile(const QString &fileName); // سیگنال برای کلاینت که آهنگ رو ندارم

private slots:
    void openFile();             // برای انتخاب فایل موسیقی (فقط ادمین)
    void togglePlayPause();      // دکمه پلی/پاز
    void updatePlayButtonText(QMediaPlayer::PlaybackState state); // تغییر متن دکمه پلی/پاز
    void updatePosition(qint64 position); // آپدیت اسلایدر و زمان پخش
    void updateDuration(qint64 duration); // آپدیت حداکثر مقدار اسلایدر
    void setPosition(int position); // تغییر موقعیت پخش با اسلایدر

    void mediaStatusChanged(QMediaPlayer::MediaStatus status); // وضعیت لود شدن آهنگ

private:
    QMediaPlayer *player;
    QAudioOutput *audioOutput; // در Qt6 ضروری است
    QPushButton *openButton;
    QPushButton *playPauseButton;
    QSlider *positionSlider;
    QLabel *statusLabel;
    QLabel *timeLabel;

    bool isAdminMode = false;
    QString currentPlayingSongPath;
    QString currentPlayingSongName;

    QString formatTime(qint64 milliseconds);
};

#endif // MUSICPLAYERWINDOW_H
