#include "clientwindow.h"
#include <QDataStream>
#include <QNetworkDatagram>

const quint16 SERVER_PORT_TCP = 12345;
const quint16 SERVER_PORT_UDP = 12346;

ClientWindow::ClientWindow(QWidget *parent)
    : QWidget(parent)
{
    ipLineEdit = new QLineEdit();
    ipLineEdit->setPlaceholderText("IP آدرس ادمین را وارد کنید (مثلاً 192.168.1.100)");
    connectButton = new QPushButton("اتصال به دورهمی موسیقی");
    statusLabel = new QLabel("برای اتصال، IP ادمین را وارد کرده و دکمه را بزنید.");

    mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(ipLineEdit);
    mainLayout->addWidget(connectButton);
    mainLayout->addWidget(statusLabel);

    tcpSocket = new QTcpSocket(this);
    udpSocket = new QUdpSocket(this);

    musicPlayerWindow = new MusicPlayerWindow();
    musicPlayerWindow->setAdminMode(false); // کلاینت مود
    mainLayout->addWidget(musicPlayerWindow);

    connect(connectButton, &QPushButton::clicked, this, &ClientWindow::connectToServer);
    connect(tcpSocket, &QTcpSocket::connected, this, &ClientWindow::connected);
    connect(tcpSocket, &QTcpSocket::disconnected, this, &ClientWindow::disconnected);
    connect(tcpSocket, QOverload<QTcpSocket::SocketError>::of(&QTcpSocket::errorOccurred),
            this, &ClientWindow::errorOccurred);
    connect(tcpSocket, &QTcpSocket::readyRead, this, &ClientWindow::readServerDataTcp);

    // The signals below were causing the linker error. Their slots are now defined.
    connect(musicPlayerWindow, &MusicPlayerWindow::requestSongFile, this, &ClientWindow::handleRequestSongFile);
    connect(tcpSocket, &QTcpSocket::bytesWritten, this, &ClientWindow::updateFileReadProgress);

    connect(udpSocket, &QUdpSocket::readyRead, this, &ClientWindow::readServerDataUdp);

    receivingFile = nullptr;
    bytesReceived = 0;
    totalBytesToReceive = 0;

    setWindowTitle("کلاینت پخش موسیقی آنلاین");
    setFixedSize(450, 450);
}

ClientWindow::~ClientWindow()
{
    if (receivingFile) {
        if (receivingFile->isOpen()) {
            receivingFile->close();
        }
        delete receivingFile;
    }
}

void ClientWindow::connectToServer()
{
    QString ipAddress = ipLineEdit->text().trimmed();
    if (ipAddress.isEmpty()) {
        QMessageBox::warning(this, "خطا", "لطفاً IP آدرس ادمین را وارد کنید.");
        return;
    }

    if (tcpSocket->state() != QAbstractSocket::UnconnectedState) {
        tcpSocket->abort();
    }

    statusLabel->setText(QString("در حال اتصال به %1:%2 (TCP) ...").arg(ipAddress).arg(SERVER_PORT_TCP));
    connectButton->setEnabled(false);
    ipLineEdit->setEnabled(false);

    tcpSocket->connectToHost(ipAddress, SERVER_PORT_TCP);
}

void ClientWindow::connected()
{
    statusLabel->setText(QString("با موفقیت به ادمین متصل شدید: %1:%2")
                             .arg(tcpSocket->peerAddress().toString())
                             .arg(tcpSocket->peerPort()));
    connectButton->setText("متصل شد");
    qDebug() << "Client: Successfully connected to server (TCP).";

    if (!udpSocket->bind(QHostAddress::Any, SERVER_PORT_UDP)) {
        qDebug() << "Client: UDP socket failed to bind:" << udpSocket->errorString();
        QMessageBox::critical(this, "خطا", "UDP socket failed to bind: " + udpSocket->errorString());
        return;
    }
    qDebug() << "Client: UDP socket bound successfully to port" << SERVER_PORT_UDP;
}

void ClientWindow::disconnected()
{
    statusLabel->setText("از ادمین قطع شدید. لطفاً مجدداً تلاش کنید.");
    connectButton->setEnabled(true);
    ipLineEdit->setEnabled(true);
    connectButton->setText("اتصال به دورهمی موسیقی");
    qDebug() << "Client: Disconnected from server (TCP).";
    udpSocket->close();
    musicPlayerWindow->stopMusic();
}

void ClientWindow::errorOccurred(QTcpSocket::SocketError socketError)
{
    Q_UNUSED(socketError);
    statusLabel->setText("خطا در اتصال: " + tcpSocket->errorString());
    connectButton->setEnabled(true);
    ipLineEdit->setEnabled(true);
    connectButton->setText("اتصال به دورهمی موسیقی");
    qDebug() << "Client: Socket error:" << tcpSocket->errorString();
}

void ClientWindow::readServerDataTcp()
{
    QDataStream in(tcpSocket);
    in.setVersion(QDataStream::Qt_6_0);

    for (;;) {
        if (receivingFile == nullptr) {
            if (tcpSocket->bytesAvailable() < (qint64)sizeof(quint32)) return;

            quint32 blockSize;
            in >> blockSize;

            if (tcpSocket->bytesAvailable() < blockSize) return;

            QString messageType;
            in >> messageType;

            if (messageType == "FILE_TRANSFER") {
                in >> currentReceivingFileName;
                in >> totalBytesToReceive;

                QString savePath = QDir::homePath() + "/Music/" + currentReceivingFileName;
                QDir().mkpath(QDir::homePath() + "/Music/");

                receivingFile = new QFile(savePath);
                if (!receivingFile->open(QIODevice::WriteOnly)) {
                    QMessageBox::critical(this, "خطا", "نمی توان فایل را برای ذخیره باز کرد: " + receivingFile->errorString());
                    delete receivingFile;
                    receivingFile = nullptr;
                    return;
                }
                bytesReceived = 0;
                statusLabel->setText(QString("در حال دریافت فایل: %1 (0%)").arg(currentReceivingFileName));
                qDebug() << "Client: Starting to receive file:" << currentReceivingFileName << "size:" << totalBytesToReceive;
            } else {
                qDebug() << "Client: Unknown TCP message type:" << messageType;
                QByteArray unknownData;
                unknownData.resize(blockSize - messageType.size());
                in >> unknownData;
            }
        }

        if (receivingFile && receivingFile->isOpen()) {
            qint64 availableData = tcpSocket->bytesAvailable();
            if (availableData > 0) {
                QByteArray chunk = tcpSocket->read(availableData);
                receivingFile->write(chunk);
                bytesReceived += chunk.size();

                double progress = (totalBytesToReceive > 0) ? ((double)bytesReceived * 100 / totalBytesToReceive) : 100.0;
                statusLabel->setText(QString("در حال دریافت فایل: %1 (%2%)")
                                         .arg(currentReceivingFileName)
                                         .arg(QString::number(progress, 'f', 1)));
            }

            if (bytesReceived >= totalBytesToReceive) {
                qDebug() << "Client: File received completely:" << currentReceivingFileName;
                QString finalPath = receivingFile->fileName();
                receivingFile->close();
                delete receivingFile;
                receivingFile = nullptr;

                QMessageBox::information(this, "دریافت فایل", QString("فایل '%1' با موفقیت دریافت شد.").arg(currentReceivingFileName));
                statusLabel->setText(QString("فایل '%1' دریافت شد. آماده پخش.").arg(currentReceivingFileName));
                musicPlayerWindow->playMusic(finalPath, 0);
            }
        }
        if(tcpSocket->bytesAvailable() == 0) break;
    }
}


void ClientWindow::readServerDataUdp()
{
    while (udpSocket->hasPendingDatagrams()) {
        QNetworkDatagram datagram = udpSocket->receiveDatagram();
        QByteArray data = datagram.data();
        QString message = QString::fromUtf8(data);
        qDebug() << "Client: UDP data received:" << message;

        QStringList parts = message.split('|');
        if (parts.size() < 2) continue;

        QString commandType = parts.at(0);
        QString songName = parts.at(1);
        qint64 positionMs = (parts.size() > 2) ? parts.at(2).toLongLong() : 0;

        if (commandType == "SONG_SELECTED") {
            statusLabel->setText(QString("ادمین آهنگ '%1' را انتخاب کرده است.").arg(songName));
            if (checkIfSongExistsLocally(songName)) {
                QMessageBox::information(this, "پخش محلی", "شما این آهنگ را دارید. پخش از فایل محلی.");
                QString localPath = QDir::homePath() + "/Music/" + songName;
                musicPlayerWindow->playMusic(localPath, 0);
            } else {
                QMessageBox::StandardButton reply;
                reply = QMessageBox::question(this, "درخواست فایل",
                                              QString("آهنگ '%1' را ندارید. آیا می‌خواهید آن را از ادمین دریافت کنید؟").arg(songName),
                                              QMessageBox::Yes | QMessageBox::No);
                if (reply == QMessageBox::Yes) {
                    sendTcpRequest("REQUEST_SONG_FILE", songName);
                    statusLabel->setText(QString("در حال درخواست فایل '%1' از سرور...").arg(songName));
                } else {
                    statusLabel->setText(QString("شما آهنگ '%1' را برای پخش ندارید.").arg(songName));
                }
            }
        } else if (commandType == "PLAY") {
            musicPlayerWindow->resumeMusic(positionMs);
        } else if (commandType == "PAUSE") {
            musicPlayerWindow->pauseMusic();
        }
    }
}

// =======================================================================
// vv MISSING FUNCTIONS ADDED BACK IN HERE vv
// =======================================================================

void ClientWindow::handleRequestSongFile(const QString &fileName)
{
    // This slot is declared but the logic to request a file is now handled
    // directly within readServerDataUdp after the user confirms via QMessageBox.
    // We keep the function body to prevent linker errors.
    Q_UNUSED(fileName);
    qDebug() << "handleRequestSongFile slot called, but logic is handled elsewhere.";
}


void ClientWindow::updateFileReadProgress(qint64 numBytes)
{
    // This function is for tracking file *sending* progress (like on the server).
    // The client *receives* files, and its progress is tracked inside readServerDataTcp.
    // This empty implementation is here to prevent linker errors.
    Q_UNUSED(numBytes);
}

// =======================================================================
// ^^ MISSING FUNCTIONS ADDED BACK IN HERE ^^
// =======================================================================

bool ClientWindow::checkIfSongExistsLocally(const QString &songName)
{
    QString localPath = QDir::homePath() + "/Music/" + songName;
    return QFile::exists(localPath);
}

void ClientWindow::sendTcpRequest(const QString &requestType, const QString &payload)
{
    if(tcpSocket->state() != QAbstractSocket::ConnectedState) return;

    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_0);

    out << (quint32)0;
    out << requestType;
    out << payload;

    out.device()->seek(0);
    out << (quint32)(block.size() - sizeof(quint32));

    tcpSocket->write(block);
    qDebug() << "Client: Sent TCP request:" << requestType << "with payload:" << payload;
}
