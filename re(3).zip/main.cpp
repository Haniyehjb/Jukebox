#include <QApplication>
#include <QMessageBox>
#include <QPushButton> // برای دسترسی به QPushButton از QAbstractButton
#include "serverwindow.h" // شامل کلاس پنجره سرور
#include "clientwindow.h" // شامل کلاس پنجره کلاینت

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QMessageBox msgBox;
    msgBox.setText("آیا می‌خواهید ادمین (هاست) باشید یا کلاینت (مهمان)؟");

    // دکمه‌ها را ایجاد کرده و به آنها اشاره‌گر می‌دهیم
    QPushButton *adminButton = msgBox.addButton("ادمین", QMessageBox::YesRole);
    QPushButton *clientButton = msgBox.addButton("کلاینت", QMessageBox::NoRole);

    msgBox.setDefaultButton(adminButton); // دکمه پیش فرض را تنظیم کنید (اختیاری)

    // exec() را اجرا کنید و دکمه‌ای که فشرده شده را برمی‌گرداند
    msgBox.exec();
    QAbstractButton *clickedButton = msgBox.clickedButton(); // دکمه‌ای که کاربر کلیک کرده

    QWidget *window = nullptr;

    // مقایسه دکمه فشرده شده با دکمه‌های ایجاد شده
    if (clickedButton == adminButton) {
        window = new ServerWindow();
    } else if (clickedButton == clientButton) { // اگر دکمه کلاینت فشرده شد
        window = new ClientWindow();
    } else {
        // این حالت ممکن است زمانی رخ دهد که کاربر پیام باکس را بسته باشد
        // می‌توانید اینجا یک پیام خطا نمایش دهید یا برنامه را ببندید
        qDebug() << "No valid option selected. Exiting.";
        return 0; // برنامه را ببند
    }

    if (window) {
        window->show();
    }

    return a.exec();
}
