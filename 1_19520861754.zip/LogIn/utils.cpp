#include "utils.h"
#include <QByteArray>

QString encrypt(QString data, QString key) {
    QByteArray result;
    QByteArray baData = data.toUtf8();
    QByteArray baKey = key.toUtf8();

    for (int i = 0; i < baData.size(); ++i)
        result.append(baData[i] ^ baKey[i % baKey.size()]);

    return result.toBase64();
}

QString decrypt(QString data, QString key) {
    QByteArray decoded = QByteArray::fromBase64(data.toUtf8());
    QByteArray result;

    QByteArray baKey = key.toUtf8();
    for (int i = 0; i < decoded.size(); ++i)
        result.append(decoded[i] ^ baKey[i % baKey.size()]);

    return QString::fromUtf8(result);
}
