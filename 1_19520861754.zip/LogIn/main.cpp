#include <QApplication>
#include "login.h"
#include "UserManager.h"
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // بارگذاری کاربران از فایل
    UserManager::getInstance()->loadFromFile("users.txt");

    // نمایش فرم لاگین
    MainWindow Window;
    Window.show();

    int result = app.exec();

    // ذخیره کاربران پس از پایان برنامه
    UserManager::getInstance()->saveToFile("users.txt");

    return result;
}
