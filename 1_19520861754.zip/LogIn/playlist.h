// Playlist.h
#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QString>
#include <QVector>

class Playlist {
public:
    QString name;
    QVector<QString> songs; // حالا QVector ای از رشته‌هاست

    Playlist(QString n = "") : name(n) {}

    void addSong(const QString& songName) { // تابع addSong نیز تغییر می‌کند
        songs.append(songName);
    }
};

#endif // PLAYLIST_H
