#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <QTimer>
#include <QDateTime>
#include <QHBoxLayout>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QFileDialog>
#include <QStandardPaths>
#include <QRandomGenerator>
#include <QVector>
#include <QUrl>
#include <QMediaMetaData>

enum VisualizerMode {
    DEFAULT,
    RAINBOW,
    RANDOM,
    WAVE,
    GRAVITY
};

class MediaPlayer : public QWidget
{
    Q_OBJECT

public:
    explicit MediaPlayer(QWidget *parent = nullptr);
    ~MediaPlayer();

private slots:
    void openFile();
    void setVolume(int volume);
    void updatePosition(qint64 position);
    void updateDuration(qint64 duration);
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration);
    void updateButtonsState(QMediaPlayer::PlaybackState state);
    void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);
    void updateEqualizer();
    void playNextSong();
    void playPreviousSong();
    void toggleShuffle();
    void toggleRepeat();
    void addFilesToPlaylist();
    void playSelectedSong(QListWidgetItem *item);
    void clearPlaylist();


private:
    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;
    QVector<QUrl> playlist;
    int currentIndex;
    QVector<int> shuffledIndices;
    bool isShuffled;
    QPushButton *openButton;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QPushButton *stopButton;
    QPushButton *nextButton;
    QPushButton *previousButton;
    QPushButton *shuffleButton;
    QPushButton *repeatButton;
    QPushButton *clearPlaylistButton;
    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;
    QListWidget *playlistWidget;
    QVBoxLayout *mainLayout;

    // Equalizer members
    QGraphicsScene *equalizerScene;
    QGraphicsView *equalizerView;
    QList<QGraphicsRectItem*> rainbowBars;
    QList<QGraphicsRectItem*> randomBars;
    int m_randomUpdateCounter = 0;
    const int RANDOM_SKIP_FRAMES = 2; // Update every 3rd frame (0,1,2)
    QList<QGraphicsLineItem*> waveLines;
    QList<QPainterPath> wavePaths;
    QList<QGraphicsPathItem*> waveItems;
    QList<float> waveTimers; // Individual wave timers
    float m_waveSpeedMultiplier = 1.0f;
    QRandomGenerator randomGenerator;
    QGraphicsPixmapItem* coverArtItem;
    QGraphicsPolygonItem* playSymbolItem;
    void updateDefaultVisualizer();
    QVector<QGraphicsRectItem*> equalizerBars;
    QTimer *equalizerTimer;
    // Gravity Visualizer Variables
    struct BarState {
        float currentHeight = 2.0f;       // Current height (starts at minimum)
        float targetHeight = 2.0f;        // Target height to reach
        float velocity = 0.0f;            // Current movement speed
        float smoothTarget = 2.0f;        // For smoother transitions
        bool isPopping = false;           // Track popping state
    };
    QVector<BarState> gravityBarStates;
    QTime lastGravityRandomizeTime;

    int repeatMode; // 0: No Repeat, 1: Repeat All, 2: Repeat One

    void playCurrentSong();
    void updatePlaylistWidgetSelection();
    void toggleVisualizer();

    VisualizerMode currentVisualizer;
    QPushButton* visualizerButton;
};

#endif // MEDIAPLAYER_H
