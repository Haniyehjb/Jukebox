// user.h
#ifndef USER_H
#define USER_H

#include "Playlist.h" // Make sure Playlist.h is included
#include <QString>
#include <QVector>

class User {
public:
    QString username;
    QString hashedPassword;
    QString fullName;
    QString email;
    QString question;
    QString answer;

    QVector<Playlist> playlists;

    User(QString u = "", QString h = "", QString n = "", QString e = "", QString q = "", QString a = "")
        : username(u), hashedPassword(h), fullName(n), email(e), question(q), answer(a) {}

    void addPlaylist(const Playlist& p) {
        playlists.append(p);
    }
};

#endif // USER_H
