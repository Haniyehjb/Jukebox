#ifndef FORGOTPASSWORD_H
#define FORGOTPASSWORD_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QComboBox>

class ForgotPassword : public QWidget
{
    Q_OBJECT
public:
    explicit ForgotPassword(QWidget *parent = nullptr);

private slots:
    void verifyUser();
    void resetPassword();

private:
    QLabel *backgroundLabel;
    QLineEdit *usernameEdit;
    QLineEdit *newPasswordEdit;
    QPushButton *verifyButton;
    QPushButton *resetButton;
    QLabel *messageLabel;
    QComboBox *questionCombo;
    QLineEdit *securityAnswerEdit;

    bool userVerified = false;  // وضعیت تایید هویت کاربر
};

#endif // FORGOTPASSWORD_H
