// #ifndef MEDIAPLAYER_H
// #define MEDIAPLAYER_H

// #include <QWidget>
// #include <QMediaPlayer>
// #include <QAudioOutput>
// #include <QPushButton>
// #include <QSlider>
// #include <QLabel>
// #include <QListWidget>
// #include <QVBoxLayout>
// #include <QHBoxLayout>
// #include <QUrl>
// #include <QVector>
// #include <QStandardPaths> // For music location
// #include <QFileInfo>      // For file info in playlist

// class MediaPlayer : public QWidget
// {
//     Q_OBJECT

// public:
//     explicit MediaPlayer(QWidget *parent = nullptr);
//     ~MediaPlayer();

// private slots:
//     // removed openFile() and openMusicDirectory() as per request
//     void loadAllMusicAutomatically(); // This method now handles loading all supported music

//     void setVolume(int volume);
//     void updatePosition(qint64 position);
//     void updateDuration(qint64 duration);
//     void updateTimeLabel(qint64 currentPos, qint64 totalDuration);
//     void updateButtonsState(QMediaPlayer::PlaybackState state);
//     void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);

//     void playCurrentSong();
//     void playNextSong();
//     void playPreviousSong();
//     void toggleShuffle();
//     void toggleRepeat();
//     // addFilesToPlaylist() is no longer directly exposed via a button, but logic might still be useful internally
//     void playSelectedSong(QListWidgetItem *item);
//     void clearPlaylist();
//     void updatePlaylistWidgetSelection();
//     void addFilesToPlaylist();


// private:
//     QMediaPlayer *mediaPlayer;
//     QAudioOutput *audioOutput;

//     // openButton is removed
//     QPushButton *playButton;
//     QPushButton *pauseButton;
//     QPushButton *stopButton;
//     QPushButton *nextButton;
//     QPushButton *previousButton;

//     QPushButton *shuffleButton;
//     QPushButton *repeatButton;
//     QPushButton *clearPlaylistButton;
//     QPushButton *loadAllMusicButton; // The button for automatic loading

//     QSlider *positionSlider;
//     QSlider *volumeSlider;
//     QLabel *timeLabel;
//     QListWidget *playlistWidget;

//     QVBoxLayout *mainLayout;

//     QVector<QUrl> playlist;
//     int currentIndex;
//     bool isShuffled;
//     QVector<int> shuffledIndices; // Stores the shuffled order of indices
//     int repeatMode; // 0: No Repeat, 1: Repeat All, 2: Repeat One
// };

// #endif // MEDIAPLAYER_H
#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QListWidget>
#include <QSlider>
#include <QLabel>
#include <QPushButton> // Still needed if you keep any QPushButton, though QToolButton is used for icons
#include <QToolButton> // For icon-only buttons
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QUrl>
#include <QListWidgetItem> // For itemDoubleClicked signal

class MediaPlayer : public QWidget
{
    Q_OBJECT

public:
    explicit MediaPlayer(QWidget *parent = nullptr);
    ~MediaPlayer();

private slots:
    void loadAllMusicAutomatically(); // بارگذاری خودکار موسیقی از پوشه پیش فرض
    void setVolume(int volume);
    void updatePosition(qint64 position);
    void updateDuration(qint64 duration);
    void updateTimeLabel(qint64 currentPos, qint64 totalDuration);
    void updateButtonsState(QMediaPlayer::PlaybackState state);
    void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);

    void playCurrentSong();
    void playNextSong();
    void playPreviousSong();
    void toggleShuffle();
    void toggleRepeat();
    void clearPlaylist();
    void playSelectedSong(QListWidgetItem *item);
    void updatePlaylistWidgetSelection();

    // برای دکمه های بالا در سمت چپ و راست (Like, Options, Add to Playlist)
    void onLikeButtonClicked();
    void onOptionsButtonClicked();
    void onAddToPlaylistButtonClicked();

private:
    QMediaPlayer *mediaPlayer;
    QAudioOutput *audioOutput;

    // UI Elements (mostly QToolButton now)
    QToolButton *playButton;
    QToolButton *pauseButton;
    QToolButton *stopButton;
    QToolButton *nextButton;
    QToolButton *previousButton;

    QToolButton *shuffleButton;
    QToolButton *repeatButton;
    QToolButton *clearPlaylistButton;
    QToolButton *loadAllMusicButton; // برای بارگذاری خودکار

    // دکمه های اضافی بر اساس تصویر
    QToolButton *likeButton;
    QToolButton *optionsButton; // دکمه منو یا گزینه ها
    QToolButton *addToPlaylistButton; // دکمه افزودن (علامت +)

    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *timeLabel;
    QListWidget *playlistWidget;

    QVBoxLayout *mainLayout;

    QVector<QUrl> playlist;
    QVector<int> shuffledIndices; // Store original indices for shuffled playback
    int currentIndex;
    bool isShuffled;
    int repeatMode; // 0: No Repeat, 1: Repeat All, 2: Repeat One

    void addFilesToPlaylist(); // این تابع داخلی نگه داشته شده اما به هیچ دکمه‌ای متصل نیست
};

#endif // MEDIAPLAYER_H
