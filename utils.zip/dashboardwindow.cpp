// DashboardWindow.cpp
#include "DashboardWindow.h"
#include "MediaPlayer.h" // To open the media player
#include <QMessageBox>   // For temporary messages
#include <QPixmap>       // For background image
#include <QPalette>      // To set button palette if needed, but style sheet is generally preferred for consistency.

DashboardWindow::DashboardWindow(User* loggedUser, QVector<User>* allUsers, QWidget *parent)
    : QWidget(parent)
    , m_loggedUser(loggedUser)
    , m_allUsers(allUsers)
{
    setFixedSize(600, 400);
    setWindowTitle("Dashboard");

    // Background image (Ensure "1.jpg" is in the correct path or added to qrc)
    QLabel *backgroundLabel = new QLabel(this);
    backgroundLabel->setGeometry(0, 0, 600, 400);
    backgroundLabel->setPixmap(QPixmap("1.jpg"));
    backgroundLabel->setScaledContents(true);
    backgroundLabel->lower();

    mainLayout = new QVBoxLayout(this);
    // Adjusted left margin to move buttons to the left
    // Margins: Left, Top, Right, Bottom
    mainLayout->setContentsMargins(50, 80, 100, 80);
    mainLayout->setSpacing(20);
    // Align items to the top-left within the layout, not the entire layout centrally
    mainLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    welcomeLabel = new QLabel(QString("Welcome, %1!").arg(m_loggedUser ? m_loggedUser->username : "Guest"), this);
    welcomeLabel->setStyleSheet("color: white; font-size: 24px; font-weight: bold;");
    // Align welcome message to the left as well
    welcomeLabel->setAlignment(Qt::AlignLeft);

    // Create buttons without custom stylesheets for color, using default Qt style
    // The width (180) and height (50) are taken from MainWindow's buttons.
    mediaPlayerButton = new QPushButton("Offline Music Player", this);
    mediaPlayerButton->setFixedSize(180, 50); // Set fixed size like in MainWindow

    onlineMusicPlayerButton = new QPushButton("Online Music Player", this);
    onlineMusicPlayerButton->setFixedSize(180, 50);

    videoPlayerButton = new QPushButton("Video Player", this);
    videoPlayerButton->setFixedSize(180, 50);

    mainLayout->addWidget(welcomeLabel);
    mainLayout->addSpacing(30);
    mainLayout->addWidget(mediaPlayerButton);
    mainLayout->addWidget(onlineMusicPlayerButton);
    mainLayout->addWidget(videoPlayerButton);
    mainLayout->addStretch(1); // Pushes widgets to the top-left

    setLayout(mainLayout);

    connect(mediaPlayerButton, &QPushButton::clicked, this, &DashboardWindow::openMediaPlayer);
    // Other buttons are not connected to slots for now, you can add them later
    // connect(onlineMusicPlayerButton, &QPushButton::clicked, this, &DashboardWindow::openOnlineMusicPlayer);
    // connect(videoPlayerButton, &QPushButton::clicked, this, &DashboardWindow::openVideoPlayer);
}

DashboardWindow::~DashboardWindow()
{
    // No explicit deletion needed for child widgets as they are managed by Qt's parent-child hierarchy.
}

void DashboardWindow::openMediaPlayer()
{
    MediaPlayer *playerWindow = new MediaPlayer(m_loggedUser, m_allUsers, nullptr);
    playerWindow->show();
    this->close(); // Close the dashboard window
}
