// DashboardWindow.h
#ifndef DASHBOARDWINDOW_H
#define DASHBOARDWINDOW_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include "user.h" // برای انتقال User و QVector<User>

class DashboardWindow : public QWidget
{
    Q_OBJECT

public:
    explicit DashboardWindow(User* loggedUser, QVector<User>* allUsers, QWidget *parent = nullptr);
    ~DashboardWindow();

private slots:
    void openMediaPlayer(); // فقط یک اسلات برای مدیا پلیر
    // دکمه‌های دیگر در اینجا فقط نمایش داده می‌شوند و فعلاً کاری نمی‌کنند

private:
    User* m_loggedUser;
    QVector<User>* m_allUsers;

    QLabel *welcomeLabel;
    QPushButton *mediaPlayerButton;
    QPushButton *onlineMusicPlayerButton; // دکمه دوم
    QPushButton *videoPlayerButton;       // دکمه سوم

    QVBoxLayout *mainLayout;
};

#endif // DASHBOARDWINDOW_H
